"""Fill a recognized enterprise login form on the selected region's official site."""
from urllib.parse import urlsplit

from official_links import _PROVINCES


def allowed_login_origin(url, region):
    try:
        parts = urlsplit(url)
        code = _PROVINCES.get(region)
        return bool(code and parts.scheme == 'https' and parts.username is None
                    and parts.password is None and parts.port in (None, 443, 8443)
                    and parts.hostname in {f'{prefix}.{code}.chinatax.gov.cn'
                                           for prefix in ('etax', 'tpass')})
    except ValueError:
        return False


SELECTORS = (
    'input[placeholder*="统一社会信用代码"], input[placeholder*="纳税人识别号"], input[aria-label*="纳税人识别号"]',
    'input[placeholder*="居民身份证号码"], input[placeholder*="手机号码"], input[placeholder*="用户名"]',
    'input[type="password"][placeholder*="密码"], input[type="password"][aria-label*="密码"]',
)


def fill_enterprise_form(page, region, values):
    """Return True after filling; leave unfamiliar or ambiguous forms alone."""
    if not all(values) or not allowed_login_origin(page.url, region):
        return False
    for frame in page.frames:
        if not allowed_login_origin(frame.url, region):
            continue
        fields = []
        for selector in SELECTORS:
            controls = frame.locator(', '.join(s + ':visible:enabled:not([readonly])'
                                               for s in selector.split(', ')))
            if controls.count() != 1:
                break
            fields.append(controls.element_handle(timeout=800))
        if len(fields) != len(values):
            continue
        current = [field.input_value(timeout=800) for field in fields]
        if any(old and old != new for old, new in zip(current, values)):
            continue
        for field, old, new in zip(fields, current, values):
            if not allowed_login_origin(page.url, region) or not allowed_login_origin(frame.url, region):
                return False
            if not old:
                field.fill(new, timeout=1400)
        return True
    return False
