"""00XE Jiangsu pilot: read visible query tables only, never submit or pay."""
from datetime import datetime
import re
from urllib.parse import urlparse, urlunparse

NOTICE = '仅同步已打开查询页的可见结果，不代表已查询全部税种或分页；未读取到不等于未申报或未缴费。'


def pilot_company(company):
    return company.get('internal_code') == '00XE' and company.get('region') == '江苏'


def clean(value): return re.sub(r'\s+', '', str(value))


def parse_tables(tables, source):
    records = []
    for table in tables:
        headers = [clean(x) for x in table.get('headers', [])]
        def find(*names): return next((i for i,h in enumerate(headers) if h in names), None)
        tax = find('税种','税种名称','征收项目','税费种','税费种名称')
        declaration = find('申报状态','申报情况')
        payment = find('缴款状态','缴费状态','缴纳状态','扣款状态')
        period = find('税款所属期','所属期','所属期间','税费所属期')
        start, end = find('税款所属期起','所属期起'), find('税款所属期止','所属期止')
        if tax is None or (declaration is None and payment is None): continue
        for cells in table.get('rows', []):
            def value(index): return str(cells[index]).strip() if index is not None and index<len(cells) else ''
            if not value(tax) or value(tax) in ('合计','总计'): continue
            label = value(period) or (value(start)+' 至 '+value(end) if value(start) and value(end) else '')
            records.append(dict(tax=value(tax),period=label or '所属期待核对',
                                declaration=value(declaration) or '未读取', payment=value(payment) or '未读取',
                                payable=value(find('应缴金额','应纳税额','应补退税额','应补(退)税额')) or '未读取',
                                paid=value(find('已缴金额','实缴金额','实缴税额','缴款金额')) or '未读取',
                                outstanding=value(find('待缴金额','未缴金额','未缴税额','欠税金额')) or '未读取',
                                source=source,raw=dict(zip(headers,cells))))
    return records


def capture_context(context, company):
    if not pilot_company(company): raise ValueError('本期仅适配00XE江苏试点，其他企业尚未开放。')
    tax_id, name = clean(company.get('tax_id','')), clean(company.get('name',''))
    if not tax_id or not name: raise ValueError('企业名称或税号不完整，不能核验当前登录身份。')
    identity = False
    snapshots = []
    denied = False
    script = '''() => {
      const tables=[];
      const roots=[...document.querySelectorAll('.el-table,.ant-table-wrapper,table')];
      for(const root of roots){
        if(root.tagName==='TABLE' && root.closest('.el-table,.ant-table-wrapper'))continue;
        const headers=[...root.querySelectorAll('thead th')].map(x=>x.innerText.trim());
        if(!headers.length)continue;
        const rows=[...root.querySelectorAll('tbody tr')].filter(x=>x.getClientRects().length)
          .slice(0,1000).map(r=>[...r.querySelectorAll('td')].map(c=>c.innerText.trim()));
        tables.push({headers,rows});
      }
      return {text:(document.body?.innerText||'').slice(0,500000),tables};
    }'''
    for page in context.pages:
        if page.is_closed(): continue
        parsed = urlparse(page.url)
        if not ((parsed.hostname or '').endswith('.jiangsu.chinatax.gov.cn')): continue
        source = urlunparse((parsed.scheme,parsed.netloc,parsed.path,'','',''))
        page_tables = []
        page_matches = False
        for frame in page.frames:
            frame_host = urlparse(frame.url).hostname or ''
            if not frame_host.endswith('.jiangsu.chinatax.gov.cn'): continue
            try: snapshot = frame.evaluate(script)
            except Exception: continue
            text = clean(snapshot['text'])
            page_matches = page_matches or name in text
            identity = identity or (tax_id in text and name in text)
            denied = denied or any(x in text for x in ('您不是用票试点纳税人','无权操作税务数字账户','没有权限'))
            page_tables.extend(snapshot['tables'])
        # A matching old homepage must not authorize reading a different
        # company's query tab after the user manually switches identity.
        if page_matches: snapshots.append((page_tables,source))
    if not identity: raise ValueError('未同时核对到00XE企业名称和税号；请保留已登录的江苏首页，确认企业身份后再同步。')
    records = [r for tables,source in snapshots for r in parse_tables(tables,source)]
    if not records:
        raise ValueError(('税局页面提示权限受限；请核对企业身份和人员授权。' if denied else '') +
                         '尚未识别到申报／缴款状态表，请手动打开相应查询页并执行查询；此页版式可能仍需适配。')
    unique = {str(sorted(x.items())):x for x in records}
    return {'company':company.get('internal_code'), 'tax_id':tax_id, 'company_name':company['name'],
            'synced_at':datetime.now().isoformat(timespec='seconds'), 'coverage':'仅可见查询结果',
            'notice':NOTICE, 'records':list(unique.values())}
