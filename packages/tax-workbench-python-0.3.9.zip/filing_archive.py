"""Local, versioned filing records. No passwords, browser state or cloud upload."""
from datetime import datetime
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import shutil
import uuid
import zipfile

ALLOWED = {'.xls','.xlsx','.csv','.pdf','.zip','.png','.jpg','.jpeg','.doc','.docx','.txt','.json'}


class Archive:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root / 'files').mkdir(exist_ok=True)
        self.index = self.root/'records.json'

    @contextmanager
    def writer(self):
        lock = self.root/'write.lock'
        try: descriptor = os.open(lock, os.O_CREAT|os.O_EXCL|os.O_WRONLY)
        except FileExistsError: raise ValueError('另一个档案任务正在写入；如软件异常退出留下write.lock，请先联系维护人员，不要删除原始资料。')
        try: yield
        finally: os.close(descriptor);lock.unlink(missing_ok=True)

    def add_file(self, path, company, period, tax, category):
        source = Path(path)
        if source.suffix.lower() not in ALLOWED: raise ValueError('不支持此文件类型，不备份程序、密码或会话文件。')
        if not company or not period or not tax: raise ValueError('请选择企业，并填写所属期和税种／资料事项。')
        if source.stat().st_size > 250 * 1024 * 1024: raise ValueError('单个资料不能超过250MB。')
        digest = hashlib.sha256()
        with source.open('rb') as stream:
            for part in iter(lambda: stream.read(1024 * 1024), b''): digest.update(part)
        sha = digest.hexdigest()
        blob = sha + source.suffix.lower()
        target = self.root / 'files' / blob
        if target.exists() and hashlib.sha256(target.read_bytes()).hexdigest() != sha:
            raise ValueError('已有备份文件校验失败，请保留现场并联系维护人员；未覆盖原文件。')
        if not target.exists():
            temporary = target.with_name(uuid.uuid4().hex + '.tmp')
            try:
                shutil.copyfile(source, temporary)
                if hashlib.sha256(temporary.read_bytes()).hexdigest() != sha:
                    raise ValueError('复制期间源文件发生变化，请重新备份。')
                temporary.replace(target)
            finally:
                temporary.unlink(missing_ok=True)
        with self.writer():
            records = self.records()
            matching = [r['version'] for r in records if
                        (r['company'],r['period'],r['tax'],r['category'],r['filename']) ==
                        (company,period,tax,category,source.name)]
            record = dict(id=uuid.uuid4().hex,company=company,period=period,tax=tax,category=category,
                          filename=source.name,sha256=sha,blob=blob,version=max(matching,default=0)+1,
                          saved_at=datetime.now().isoformat(timespec='seconds'))
            temporary=self.index.with_name(uuid.uuid4().hex+'.tmp')
            try:
                temporary.write_text(json.dumps(records+[record],ensure_ascii=False,indent=2),encoding='utf-8')
                temporary.replace(self.index)
            finally:temporary.unlink(missing_ok=True)
        return record['id']

    def records(self, company=None):
        records=json.loads(self.index.read_text(encoding='utf-8')) if self.index.exists() else []
        if not isinstance(records,list):raise ValueError('档案索引损坏，未修改原文件。')
        return sorted((r for r in records if not company or r['company']==company),
                      key=lambda r:(r['saved_at'],r['version']),reverse=True)

    def export(self, destination, ids):
        selected = [x for x in self.records() if x['id'] in set(ids)]
        if not selected: raise ValueError('请先选择需要导出的资料。')
        destination = Path(destination).resolve()
        if destination in (self.index,self.root/'write.lock') or (self.root/'files') in destination.parents:
            raise ValueError('不能覆盖档案数据库或原始备份文件。')
        temporary = destination.with_name(destination.name + '.' + uuid.uuid4().hex + '.tmp')
        try:
            with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED) as out:
                manifest = []
                for item in selected:
                    source = (self.root/'files'/item['blob']).resolve()
                    if source.parent != self.root/'files': raise ValueError('档案路径异常。')
                    if hashlib.sha256(source.read_bytes()).hexdigest() != item['sha256']:
                        raise ValueError('资料校验失败：'+item['filename'])
                    safe_name = item['id'] + Path(item['filename']).suffix.lower()
                    out.write(source, 'files/'+safe_name)
                    manifest.append({**item, 'export_file':'files/'+safe_name})
                out.writestr('资料清单.json', json.dumps(manifest, ensure_ascii=False, indent=2))
            temporary.replace(destination)
        finally:
            temporary.unlink(missing_ok=True)
        return len(selected)
