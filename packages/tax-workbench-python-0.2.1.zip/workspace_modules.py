import json
import os
import uuid
import webbrowser
import threading
import urllib.request
import urllib.error
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
import tkinter as tk
from urllib.parse import quote_plus

from finance_mapper import validate_financial_report
from apple_widgets import AppleButton
from apple_theme import C, apply_typography


APP_DIR = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "ShenzhenTaxLoginManager"
APP_DIR.mkdir(parents=True, exist_ok=True)
REPORTS = APP_DIR / "report_tasks.json"
CASES = APP_DIR / "case_library.json"
PRACTICE = APP_DIR / "practice_library.json"
REGION_URLS = APP_DIR / "region_urls_registry.json"
REGIONS = ("国家税务总局", "北京", "天津", "河北", "山西", "内蒙古", "辽宁", "吉林", "黑龙江", "上海",
           "江苏", "浙江", "安徽", "福建", "江西", "山东", "河南", "湖北", "湖南", "广东", "深圳", "广西",
           "海南", "重庆", "四川", "贵州", "云南", "西藏", "陕西", "甘肃", "青海", "宁夏", "新疆")

KNOWN_ETAX_URLS = {
    "北京": "https://etax.beijing.chinatax.gov.cn/",
    "天津": "https://etax.tianjin.chinatax.gov.cn/",
    "吉林": "https://etax.jilin.chinatax.gov.cn/",
    "江苏": "https://etax.jiangsu.chinatax.gov.cn:8443/",
    "福建": "https://etax.fujian.chinatax.gov.cn/",
    "河南": "https://etax.henan.chinatax.gov.cn/",
    "广东": "https://etax.guangdong.chinatax.gov.cn:8443/",
    "深圳": "https://etax.shenzhen.chinatax.gov.cn:8443/",
    "重庆": "https://etax.chongqing.chinatax.gov.cn:8443/",
    "四川": "https://etax.sichuan.chinatax.gov.cn/",
    "陕西": "https://etax.shaanxi.chinatax.gov.cn/",
}


def _read(path):
    try:
        value = json.loads(path.read_text(encoding="utf-8")) if path.exists() else []
        return value if isinstance(value, list) else []
    except (OSError, json.JSONDecodeError):
        return []


def _write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def _window(parent, title, subtitle, size="1040x700"):
    # Keep one business workspace per parent.  This prevents several large
    # tool windows from stacking over the dashboard and confusing the user.
    previous = getattr(parent, "_business_workspace_window", None)
    try:
        if previous is not None and previous.winfo_exists():
            previous.destroy()
    except tk.TclError:
        pass
    win = tk.Toplevel(parent)
    parent._business_workspace_window = win
    win.title(title)
    win.geometry(size)
    win.minsize(820, 580)
    win.resizable(True, True)
    win.after_idle(lambda: apply_typography(win) if win.winfo_exists() else None)
    win.configure(bg=C('parchment'))
    # Do not make this a transient window: Windows otherwise removes the
    # minimize/maximize controls and leaves only the Close button.
    def close_window():
        try:
            if getattr(parent, "_business_workspace_window", None) is win:
                parent._business_workspace_window = None
        finally:
            win.destroy()
    win.protocol("WM_DELETE_WINDOW", close_window)
    head = tk.Frame(win, bg=C('white'), height=104,
                    highlightbackground=C('hairline'), highlightthickness=1)
    head.pack(fill="x"); head.pack_propagate(False)
    tk.Label(head, text=title, bg=C('white'), fg=C('ink'),
             font=("Microsoft YaHei UI", 19, "bold")).pack(anchor="w", padx=30, pady=(16, 8))
    tk.Label(head, text=subtitle, bg=C('white'), fg=C('muted'),
             font=("Microsoft YaHei UI", 9)).pack(anchor="w", padx=30)
    return win


def open_region_url_manager(parent, companies=None, save_companies_callback=None):
    win = _window(parent, "地区税务局网址管理", "同一地区统一配置；未核验地区保持为空，禁止跨地区套用网址", "1120x720")
    saved = _read(REGION_URLS)
    saved_map = {item.get("region"): item for item in saved}
    all_regions = tuple(r for r in REGIONS if r != "国家税务总局") + ("大连", "宁波", "厦门", "青岛")
    records = []
    for region in all_regions:
        item = dict(saved_map.get(region, {}))
        item.setdefault("region", region)
        item.setdefault("home_url", KNOWN_ETAX_URLS.get(region, ""))
        item.setdefault("login_url", item.get("home_url", ""))
        item.setdefault("status", "待检测" if item.get("home_url") else "待核验")
        item.setdefault("checked_at", "—")
        item.setdefault("note", "")
        records.append(item)

    toolbar = tk.Frame(win, bg="white", highlightbackground=C('hairline'), highlightthickness=1)
    toolbar.pack(fill="x", padx=28, pady=(22, 12))
    tk.Label(toolbar, text="全国省级及计划单列市", bg="white", fg=C('ink'),
             font=("Microsoft YaHei UI", 11, "bold")).pack(side="left", padx=18, pady=16)
    status = tk.StringVar(value="请选择地区进行检测或编辑")
    tk.Label(toolbar, textvariable=status, bg="white", fg=C('muted'),
             font=("Microsoft YaHei UI", 8)).pack(side="left", padx=12)
    table = tk.Frame(win, bg="white", highlightbackground=C('hairline'), highlightthickness=1)
    table.pack(fill="both", expand=True, padx=28, pady=(0, 12))
    cols = ("region", "home", "login", "status", "checked", "note")
    tree = ttk.Treeview(table, columns=cols, show="headings", selectmode="browse")
    specs = (("region", "地区", 90), ("home", "电子税务局首页", 270), ("login", "登录入口", 270),
             ("status", "状态", 90), ("checked", "最近检测", 135), ("note", "备注", 170))
    for key, label, width in specs:
        tree.heading(key, text=label); tree.column(key, width=width, minwidth=70, stretch=key in ("home", "login", "note"))
    tree.grid(row=0, column=0, sticky="nsew")
    ybar = ttk.Scrollbar(table, orient="vertical", command=tree.yview); ybar.grid(row=0, column=1, sticky="ns")
    xbar = ttk.Scrollbar(table, orient="horizontal", command=tree.xview); xbar.grid(row=1, column=0, sticky="ew")
    table.rowconfigure(0, weight=1); table.columnconfigure(0, weight=1)
    tree.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)

    def persist():
        _write(REGION_URLS, records)

    def refresh():
        tree.delete(*tree.get_children())
        for item in records:
            tree.insert("", "end", iid=item["region"], values=(item["region"], item.get("home_url", ""),
                        item.get("login_url", ""), item.get("status", ""), item.get("checked_at", "—"), item.get("note", "")))

    def edit_selected():
        if not tree.selection(): return
        item = next(x for x in records if x["region"] == tree.selection()[0])
        edit = _window(win, f"编辑地区网址｜{item['region']}", "仅填写国家税务总局及省市税务局官方域名", "760x470")
        box = tk.Frame(edit, bg="white"); box.pack(fill="both", expand=True, padx=28, pady=22)
        home = tk.StringVar(value=item.get("home_url", "")); login = tk.StringVar(value=item.get("login_url", "")); note = tk.StringVar(value=item.get("note", ""))
        for row, (label, value) in enumerate((("电子税务局首页", home), ("实际登录入口", login), ("备注", note))):
            tk.Label(box, text=label, bg="white", fg=C('secondary'), font=("Microsoft YaHei UI", 9, "bold")).pack(anchor="w", pady=(8, 5))
            tk.Entry(box, textvariable=value, bg=C('white'), relief="flat", highlightbackground=C('hairline'),
                     highlightthickness=1, font=("Microsoft YaHei UI", 9)).pack(fill="x", ipady=8)
        def save():
            for value in (home.get().strip(), login.get().strip()):
                if value and (not value.startswith("https://") or ".chinatax.gov.cn" not in value):
                    messagebox.showwarning("网址不符合要求", "网址必须使用 https，并属于 chinatax.gov.cn 官方域名。", parent=edit); return
            item.update({"home_url": home.get().strip(), "login_url": login.get().strip(), "note": note.get().strip(),
                         "status": "待检测" if home.get().strip() else "待核验", "checked_at": "—"})
            if companies is not None:
                for company in companies:
                    if company.get("region") == item["region"]:
                        company["tax_url"] = item["home_url"]
                if save_companies_callback:
                    save_companies_callback(companies)
            persist(); refresh(); edit.destroy()
        AppleButton(box, text="保存配置", command=save, bg=C('primary'), fg="white", relief="flat", padx=22, pady=10,
                  font=("Microsoft YaHei UI", 9, "bold")).pack(anchor="e", pady=(20, 0))

    def check_one(item):
        url = item.get("home_url") or item.get("login_url")
        if not url:
            return "待核验", "未配置官方入口"
        try:
            request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(request, timeout=12) as response:
                final_url = response.geturl()
                if ".chinatax.gov.cn" not in final_url:
                    return "异常", "跳转到非税务局域名"
                code = getattr(response, "status", 200)
                return ("有效" if 200 <= code < 400 else "异常"), f"HTTP {code}"
        except Exception as error:
            if isinstance(error, urllib.error.HTTPError) and error.code in (401, 403, 412, 418, 429):
                return "需浏览器验证", f"网站拒绝自动检测（HTTP {error.code}），请用浏览器人工核验"
            return "不可用", str(error)[:80]

    def check_records(targets):
        def worker():
            for index, item in enumerate(targets, 1):
                win.after(0, lambda i=index, n=len(targets), r=item["region"]: status.set(f"正在检测 {r}（{i}/{n}）…"))
                result, note = check_one(item)
                item["status"] = result; item["checked_at"] = datetime.now().strftime("%Y-%m-%d %H:%M")
                if result != "有效": item["note"] = note
                win.after(0, refresh)
            persist(); win.after(0, lambda: status.set("检测完成；不可用或待核验地区可双击修改"))
        threading.Thread(target=worker, daemon=True).start()

    def check_selected():
        if tree.selection(): check_records([next(x for x in records if x["region"] == tree.selection()[0])])

    AppleButton(toolbar, text="检测全部已配置网址", command=lambda: check_records([x for x in records if x.get("home_url")]),
              bg=C('primary'), fg="white", relief="flat", padx=16, pady=8).pack(side="right", padx=(0, 14))
    AppleButton(toolbar, text="检测选中地区", command=check_selected, bg=C('pearl'), fg=C('ink'), relief="flat",
              padx=15, pady=8).pack(side="right", padx=(0, 9))
    tree.bind("<Double-1>", lambda _e: edit_selected())
    refresh()


def open_report_center(parent, companies, selected=None, login_callback=None):
    win = _window(parent, "报表与申报中心", "导入—校验—登录—预览—人工确认，未经确认不会正式申报")
    card = tk.Frame(win, bg="white", highlightbackground=C('hairline'), highlightthickness=1)
    card.pack(fill="x", padx=28, pady=(22, 12))
    card.columnconfigure(0, weight=1); card.columnconfigure(1, weight=1)
    company_list = [f"{c.get('internal_code', '')}｜{c.get('name', '')}" for c in companies]
    company = tk.StringVar(value=company_list[0] if company_list else "")
    if selected:
        preferred = f"{selected.get('internal_code', '')}｜{selected.get('name', '')}"
        if preferred in company_list:
            company.set(preferred)
    period = tk.StringVar(value=f"{datetime.now().year}年第3季度")
    path_value = tk.StringVar(value="尚未选择财务报表")

    def label(text, row, col):
        tk.Label(card, text=text, bg="white", fg=C('secondary'),
                 font=("Microsoft YaHei UI", 9, "bold")).grid(row=row, column=col, sticky="w", padx=22, pady=(17, 6))

    label("申报企业", 0, 0); label("申报期间", 0, 1)
    company_box = ttk.Combobox(card, textvariable=company, values=company_list, state="normal")
    company_box.grid(row=1, column=0, sticky="ew", padx=22)
    def filter_companies(_event=None):
        typed = company.get().strip().lower()
        if not typed:
            company_box.configure(values=company_list)
            return
        matches = []
        for item, data in zip(company_list, companies):
            haystack = " ".join((item, str(data.get("tax_id", "")), str(data.get("username", "")))).lower()
            if typed in haystack:
                matches.append(item)
        company_box.configure(values=matches)
        if matches:
            company_box.event_generate("<Down>")
    company_box.bind("<KeyRelease>", filter_companies)
    periods = tuple(f"{y}年第{q}季度" for y in range(datetime.now().year - 2, datetime.now().year + 1) for q in range(1, 5))
    ttk.Combobox(card, textvariable=period, values=periods, state="readonly").grid(row=1, column=1, sticky="ew", padx=22)
    label("财务报表文件（xls / xlsx / csv）", 2, 0)
    file_row = tk.Frame(card, bg="white"); file_row.grid(row=3, column=0, columnspan=2, sticky="ew", padx=22, pady=(0, 18))
    file_row.columnconfigure(0, weight=1)
    tk.Label(file_row, textvariable=path_value, bg=C('white'), fg=C('muted'), anchor="w", padx=12, pady=10,
             highlightbackground=C('hairline'), highlightthickness=1).grid(row=0, column=0, sticky="ew", padx=(0, 10))
    def choose():
        value = filedialog.askopenfilename(parent=win, filetypes=(("财务报表", "*.xls *.xlsx *.csv"), ("所有文件", "*.*")))
        if value: path_value.set(value)
    AppleButton(file_row, text="选择文件", command=choose, bg=C('pearl'), fg=C('ink'), relief="flat",
              font=("Microsoft YaHei UI", 9, "bold"), padx=16, pady=9).grid(row=0, column=1)

    steps = tk.Frame(win, bg=C('parchment')); steps.pack(fill="x", padx=34, pady=(4, 12))
    for i, text in enumerate(("导入报表", "自动校验", "登录税务局", "提交前复核", "人工确认"), 1):
        box = tk.Frame(steps, bg=C('parchment')); box.pack(side="left", expand=True)
        tk.Label(box, text=str(i), bg=C('primary') if i == 1 else C('hairline'), fg="white" if i == 1 else C('muted'),
                 width=3, pady=4, font=("Segoe UI", 9, "bold")).pack()
        tk.Label(box, text=text, bg=C('parchment'), fg=C('secondary'), font=("Microsoft YaHei UI", 8)).pack(pady=(5, 0))
    validation_status = tk.StringVar(value="尚未校验")
    status_banner = tk.Label(
        win, textvariable=validation_status, anchor="w", padx=16, pady=10,
        bg=C('parchment'), fg=C('ink'), font=("Microsoft YaHei UI", 9, "bold"),
        highlightbackground=C('hairline'), highlightthickness=1,
    )
    status_banner.pack(fill="x", padx=28, pady=(0, 10))
    result = tk.Text(win, bg="white", fg=C('secondary'), relief="flat", padx=18, pady=16,
                     font=("Microsoft YaHei UI", 9))
    result.insert("1.0", "等待导入报表。系统将核对企业身份、申报期间、资产负债表平衡、利润表勾稽关系和必填报表。")
    result.configure(state="disabled")
    selected_record = {"company": None}
    def stage():
        validation_status.set("正在执行基础检查……")
        status_banner.configure(bg=C('parchment'), fg=C('ink'), highlightbackground=C('hairline'))
        login_button.configure(state="disabled", bg=C('chip'), cursor="arrow")
        selected_record["company"] = None
        path = Path(path_value.get())
        if not path.is_file():
            validation_status.set("检查失败：未选择有效的财务报表文件")
            status_banner.configure(bg=C('parchment'), fg=C('ink'), highlightbackground=C('hairline'))
            messagebox.showwarning("请选择文件", "请先选择财务报表。", parent=win); return
        entered = company.get().strip().lower()
        candidates = [data for item, data in zip(company_list, companies)
                      if entered == item.lower() or entered in item.lower()
                      or entered == str(data.get("internal_code", "")).lower()
                      or entered == str(data.get("tax_id", "")).lower()]
        if len(candidates) != 1:
            validation_status.set("检查失败：未能确定唯一的申报企业")
            status_banner.configure(bg=C('parchment'), fg=C('ink'), highlightbackground=C('hairline'))
            messagebox.showwarning("请选择唯一企业", "请输入内部代码、公司名称或税号，并从匹配结果中选择一家企业。", parent=win)
            return
        chosen_company = candidates[0]
        normalized = f"{chosen_company.get('internal_code', '')}｜{chosen_company.get('name', '')}"
        company.set(normalized)
        selected_record["company"] = chosen_company
        code = chosen_company.get("internal_code", "")
        basic_warnings = []
        if path.suffix.lower() not in (".xls", ".xlsx", ".csv"): basic_warnings.append("文件格式不受支持")
        if code and code.lower() not in path.name.lower(): basic_warnings.append(f"文件名未包含企业内部代码 {code}")
        validation = validate_financial_report(path, chosen_company, period.get()) if not basic_warnings else {
            "errors": basic_warnings, "warnings": [], "checks": [], "summary": []
        }
        errors = validation.get("errors", [])
        warnings = validation.get("warnings", [])
        tasks = _read(REPORTS)
        tasks.append({"id": str(uuid.uuid4()), "company_id": chosen_company.get("id", ""),
                      "company": company.get(), "period": period.get(), "file": str(path),
                      "status": "校验失败" if errors else ("校验通过（有提示）" if warnings else "深度校验通过"),
                      "created_at": datetime.now().isoformat(timespec="seconds")})
        _write(REPORTS, tasks)
        lines = ["已建立本地报表任务，尚未向税务局发送数据。", "", f"企业：{company.get()}", f"期间：{period.get()}",
                 f"文件：{path.name}", f"文件大小：{path.stat().st_size:,} 字节", ""]
        if validation.get("summary"):
            lines += ["字段映射："] + ["• " + item for item in validation["summary"]] + [""]
        if validation.get("checks"):
            lines += ["已通过的检查："] + ["✓ " + item for item in validation["checks"]] + [""]
        if errors:
            lines += ["阻断问题："] + ["✗ " + item for item in errors]
        elif warnings:
            lines += ["深度校验通过，但需人工复核："] + ["! " + item for item in warnings]
        else:
            lines += ["深度校验通过：未发现阻断问题。", "进入税务局后仍需核对税局预览，最终提交必须人工确认。"]
        result.configure(state="normal"); result.delete("1.0", "end"); result.insert("1.0", "\n".join(lines)); result.configure(state="disabled")
        if not errors and login_callback:
            login_button.configure(state="normal", bg=C('primary'), cursor="hand2")
            if warnings:
                validation_status.set(f"深度校验通过｜有 {len(warnings)} 项需要人工复核")
                status_banner.configure(bg=C('parchment'), fg=C('ink'), highlightbackground=C('hairline'))
            else:
                validation_status.set("深度校验通过｜可以进入税务局预览申报数据")
                status_banner.configure(bg=C('parchment'), fg=C('ink'), highlightbackground=C('hairline'))
            messagebox.showinfo(
                "深度校验完成",
                f"企业、期间、报表结构和主要勾稽关系已检查。\n"
                f"通过 {len(validation.get('checks', []))} 项，人工复核 {len(warnings)} 项。\n\n"
                "现在可以进入税务局预览。最终提交前仍需人工核对。",
                parent=win,
            )
        elif errors:
            validation_status.set(f"深度校验失败｜发现 {len(errors)} 项阻断问题")
            status_banner.configure(bg=C('parchment'), fg=C('ink'), highlightbackground=C('hairline'))
            messagebox.showwarning(
                "深度校验未通过",
                "发现以下阻断问题：\n\n" + "\n".join("• " + item for item in errors) + "\n\n请修改后重新检查。",
                parent=win,
            )

    def start_tax_login():
        chosen_company = selected_record.get("company")
        if not chosen_company or not login_callback:
            messagebox.showwarning("尚未完成校验", "请先导入报表并完成基础校验。", parent=win)
            return
        login_callback(chosen_company)
        result.configure(state="normal")
        result.insert("end", "\n\n已启动税务局登录窗口。完成验证码和短信验证后，程序将继续识别财务报表申报入口。")
        result.configure(state="disabled")
    foot = tk.Frame(win, bg=C('parchment')); foot.pack(side="bottom", fill="x", padx=28, pady=(0, 20))
    login_button = AppleButton(foot, text="进入税务局查看申报入口", command=start_tax_login, state="disabled",
              bg=C('chip'), fg="white", disabledforeground=C('muted'), relief="flat",
              font=("Microsoft YaHei UI", 10, "bold"), padx=20, pady=10)
    login_button.pack(side="right", padx=(10, 0))
    AppleButton(foot, text="导入并执行深度校验", command=stage, bg=C('primary'), fg="white", relief="flat",
              font=("Microsoft YaHei UI", 10, "bold"), padx=22, pady=10).pack(side="right")
    tk.Label(foot, text="不会直接向税务局提交", bg=C('parchment'), fg=C('muted'),
             font=("Microsoft YaHei UI", 8)).pack(side="left", pady=10)
    result.pack(fill="both", expand=True, padx=28, pady=(0, 12))


def open_policy_library(parent):
    win = _window(parent, "国家税务总局政策库", "实时检索国家税务总局政策法规库，仅显示官方来源", "820x520")
    card = tk.Frame(win, bg="white", highlightbackground=C('hairline'), highlightthickness=1)
    card.pack(fill="both", expand=True, padx=28, pady=24)
    tk.Label(card, text="政策关键词、文号或年份", bg="white", fg=C('secondary'),
             font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w", padx=24, pady=(24, 8))
    value = tk.StringVar()
    entry = tk.Entry(card, textvariable=value, bg=C('white'), relief="flat", highlightbackground=C('hairline'),
                     highlightthickness=1, font=("Microsoft YaHei UI", 11))
    entry.pack(fill="x", padx=24, ipady=10); entry.focus_set()
    hot = tk.Frame(card, bg="white"); hot.pack(fill="x", padx=24, pady=15)
    for word in ("财务报表报送", "企业所得税", "增值税", "数电发票", "小微企业"):
        AppleButton(hot, text=word, command=lambda w=word: value.set(w), bg=C('parchment'), fg=C('ink'), relief="flat",
                  font=("Microsoft YaHei UI", 8), padx=9, pady=5).pack(side="left", padx=(0, 7))
    tk.Label(card, text="检索范围：fgk.chinatax.gov.cn\n使用时请核对文件时效、文号、适用税种和地区。",
             justify="left", bg=C('white'), fg=C('ink'), padx=16, pady=14).pack(fill="both", expand=True, padx=24, pady=(0, 16))
    def search():
        keyword = value.get().strip()
        if not keyword: messagebox.showwarning("请输入关键词", "请输入政策关键词或文号。", parent=win); return
        webbrowser.open_new_tab("https://www.bing.com/search?q=" + quote_plus(f"site:fgk.chinatax.gov.cn {keyword}"))
    bar = tk.Frame(card, bg="white"); bar.pack(fill="x", padx=24, pady=(0, 22))
    AppleButton(bar, text="搜索官方政策", command=search, bg=C('primary'), fg="white", relief="flat",
              font=("Microsoft YaHei UI", 10, "bold"), padx=22, pady=10).pack(side="right")
    AppleButton(bar, text="打开总局政策法规库", command=lambda: webbrowser.open_new_tab("https://fgk.chinatax.gov.cn/"),
              bg=C('pearl'), fg=C('ink'), relief="flat", padx=18, pady=10).pack(side="right", padx=(0, 10))
    entry.bind("<Return>", lambda _e: search())


def open_case_library(parent):
    _open_library(parent, "case")


def open_practice_library(parent):
    _open_library(parent, "practice")


def _open_library(parent, kind):
    is_case = kind == "case"
    path = CASES if is_case else PRACTICE
    title = "税务案例库" if is_case else "申报实操库"
    subtitle = "归集总局及各省市12366咨询、发票和申报案例" if is_case else "沉淀申报流程、操作清单、图文指引和培训视频"
    items = _read(path)
    win = _window(parent, title, subtitle)
    tools = tk.Frame(win, bg="white", highlightbackground=C('hairline'), highlightthickness=1)
    tools.pack(fill="x", padx=28, pady=(22, 12))
    query = tk.StringVar(); region = tk.StringVar(value="全部地区")
    tk.Label(tools, text="检索", bg="white", fg=C('secondary'), font=("Microsoft YaHei UI", 10, "bold")).pack(side="left", padx=(18, 9), pady=15)
    tk.Entry(tools, textvariable=query, bg=C('white'), relief="flat", highlightbackground=C('hairline'),
             highlightthickness=1, width=28).pack(side="left", ipady=7, padx=(0, 10))
    region_box = ttk.Combobox(tools, textvariable=region, values=("全部地区",) + REGIONS, state="readonly", width=11)
    region_box.pack(side="left")
    table = tk.Frame(win, bg="white", highlightbackground=C('hairline'), highlightthickness=1)
    table.pack(fill="both", expand=True, padx=28, pady=(0, 12))
    columns = ("title", "region", "category", "source", "date")
    tree = ttk.Treeview(table, columns=columns, show="headings", selectmode="browse")
    for key, label, width in (("title", "标题", 380), ("region", "地区", 100), ("category", "分类/形式", 120),
                              ("source", "来源", 170), ("date", "更新日期", 100)):
        tree.heading(key, text=label); tree.column(key, width=width, minwidth=80, stretch=key in ("title", "source"))
    tree.grid(row=0, column=0, sticky="nsew")
    scroll = ttk.Scrollbar(table, orient="vertical", command=tree.yview); scroll.grid(row=0, column=1, sticky="ns")
    table.rowconfigure(0, weight=1); table.columnconfigure(0, weight=1); tree.configure(yscrollcommand=scroll.set)
    def refresh(*_):
        tree.delete(*tree.get_children()); q = query.get().lower(); r = region.get()
        for item in items:
            hay = " ".join(str(item.get(k, "")) for k in ("title", "category", "notes", "source_name")).lower()
            if q and q not in hay: continue
            if r != "全部地区" and item.get("region") != r: continue
            tree.insert("", "end", iid=item["id"], values=(item.get("title"), item.get("region"), item.get("category"), item.get("source_name"), item.get("date")))
    def open_item(_e=None):
        if not tree.selection(): return
        item = next((x for x in items if x.get("id") == tree.selection()[0]), None)
        if not item: return
        resource = item.get("resource", "")
        if resource.startswith(("http://", "https://")): webbrowser.open_new_tab(resource)
        elif resource and Path(resource).exists(): os.startfile(resource)
        else: messagebox.showinfo("资料摘要", item.get("notes") or "尚未关联原文或附件。", parent=win)
    def add():
        edit = _window(win, "新增案例" if is_case else "新增实操资料", "保存官方原文、内部经验或培训材料", "720x600")
        form = tk.Frame(edit, bg="white"); form.pack(fill="both", expand=True, padx=28, pady=20)
        form.columnconfigure(0, weight=1); form.columnconfigure(1, weight=1)
        vals = {"title": tk.StringVar(), "region": tk.StringVar(value="国家税务总局" if is_case else "江苏"),
                "category": tk.StringVar(value="发票案例" if is_case else "图文指引"), "source_name": tk.StringVar(value="国家税务总局" if is_case else "内部实操资料"),
                "resource": tk.StringVar(), "date": tk.StringVar(value=datetime.now().strftime("%Y-%m-%d"))}
        specs = (("标题 *", "title", None), ("地区", "region", REGIONS), ("分类/形式", "category", ("12366咨询", "发票案例", "申报案例", "风险案例", "政策问答") if is_case else ("图文指引", "操作清单", "培训视频", "流程图", "模板附件")),
                 ("来源名称", "source_name", None), ("官方链接/本地文件", "resource", None), ("更新日期", "date", None))
        for i, (label, key, options) in enumerate(specs):
            row, col = divmod(i, 2)
            tk.Label(form, text=label, bg="white", fg=C('secondary'), font=("Microsoft YaHei UI", 9, "bold")).grid(row=row*2, column=col, sticky="w", padx=8, pady=(4, 5))
            widget = ttk.Combobox(form, textvariable=vals[key], values=options, state="readonly") if options else tk.Entry(form, textvariable=vals[key], bg=C('white'), relief="flat", highlightbackground=C('hairline'), highlightthickness=1)
            widget.grid(row=row*2+1, column=col, sticky="ew", padx=8, pady=(0, 10), ipady=6 if not options else 0)
        if not is_case:
            def browse():
                value = filedialog.askopenfilename(parent=edit)
                if value: vals["resource"].set(value)
            AppleButton(form, text="选择本地附件", command=browse, bg=C('pearl'), fg=C('ink'), relief="flat").grid(row=6, column=1, sticky="e", padx=8)
        tk.Label(form, text="摘要、适用条件或操作要点", bg="white", fg=C('secondary'), font=("Microsoft YaHei UI", 9, "bold")).grid(row=6, column=0, columnspan=2, sticky="w", padx=8, pady=(14, 5))
        notes = tk.Text(form, height=8, bg=C('white'), relief="flat", highlightbackground=C('hairline'), highlightthickness=1)
        notes.grid(row=7, column=0, columnspan=2, sticky="nsew", padx=8); form.rowconfigure(7, weight=1)
        def save():
            if not vals["title"].get().strip(): messagebox.showwarning("缺少标题", "请填写标题。", parent=edit); return
            item = {k: v.get().strip() for k, v in vals.items()}; item.update({"id": str(uuid.uuid4()), "notes": notes.get("1.0", "end").strip()})
            items.append(item); _write(path, items); edit.destroy(); refresh()
        bar = tk.Frame(edit, bg=C('parchment')); bar.pack(fill="x", padx=28, pady=(0, 20))
        AppleButton(bar, text="保存资料", command=save, bg=C('primary'), fg="white", relief="flat", padx=20, pady=9).pack(side="right")
    def official():
        keyword = query.get().strip() or ("12366 发票 案例" if is_case else "纳税人学堂 申报 操作 视频")
        webbrowser.open_new_tab("https://www.bing.com/search?q=" + quote_plus(f"site:chinatax.gov.cn {keyword}"))
    AppleButton(tools, text="＋ 新增资料", command=add, bg=C('primary'), fg="white", relief="flat", padx=15, pady=8).pack(side="right", padx=(0, 14))
    AppleButton(tools, text="搜索税务机关官网", command=official, bg=C('pearl'), fg=C('ink'), relief="flat", padx=14, pady=8).pack(side="right", padx=(0, 9))
    foot = tk.Frame(win, bg=C('parchment')); foot.pack(fill="x", padx=28, pady=(0, 18))
    tk.Label(foot, text="双击条目打开官方原文、视频或本地附件", bg=C('parchment'), fg=C('muted')).pack(side="left")
    tree.bind("<Double-1>", open_item); query.trace_add("write", refresh); region_box.bind("<<ComboboxSelected>>", refresh); refresh()
