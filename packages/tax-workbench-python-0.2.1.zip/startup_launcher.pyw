"""Stable launcher: probe a pending version, then fall back on startup failure."""
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
os.environ['TAX_WORKBENCH_HOME']=str(ROOT)
sys.path.insert(0,str(ROOT))
import update_core as core

def run_child(directory,pending=None):
    env=os.environ.copy()
    env['TAX_WORKBENCH_CHILD']='1'
    env['TAX_WORKBENCH_VERSION_DIR']=str(directory)
    env.pop('TAX_WORKBENCH_PENDING',None)
    if pending:env['TAX_WORKBENCH_PENDING']=pending
    child=subprocess.Popen([sys.executable,str(__file__),'--child',str(directory)],env=env,
                           creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    if pending:
        deadline=time.monotonic()+40
        while time.monotonic()<deadline and child.poll() is None:
            if core.state().get('current')==pending:
                return 0
            time.sleep(.2)
        if child.poll() is None:
            child.terminate();child.wait(timeout=10)
        return 1
    return child.wait()

def main():
    if len(sys.argv)>2 and sys.argv[1]=='--child':
        folder=Path(sys.argv[2]).resolve()
        if folder!=ROOT and ROOT/'update_store'/'versions' not in folder.parents:
            raise ValueError('无效的应用路径')
        sys.path.insert(0,str(folder))
        runpy.run_path(str(folder/core.ENTRY),run_name='__main__')
        return
    saved=core.state()
    pending=saved.get('pending')
    if pending:
        core.version_tuple(pending)
        candidate=core.STORE/'versions'/pending
        if candidate.is_dir() and run_child(candidate,pending)==0:return
        # A failed initialization never overwrites the prior working version.
        saved=core.state()
        if saved.get('pending')==pending:
            saved.update(pending=None,last_failure=pending)
            core.atomic_json(core.STORE/'state.json',saved)
    saved=core.state()
    current=saved.get('current')
    folder=ROOT
    if current:
        core.version_tuple(current)
        candidate=core.STORE/'versions'/current
        if candidate.is_dir():folder=candidate
    result=run_child(folder)
    if result:
        import tkinter as tk
        from tkinter import messagebox
        window=tk.Tk();window.withdraw()
        messagebox.showerror('启动失败','应用启动失败，请联系维护人员。公司资料仍保存在原本的本地资料目录。',parent=window)
        window.destroy()

if __name__=='__main__':main()
