"""Monthly local invoice-quota register with explicit read-only page import."""
from datetime import datetime
import json
from pathlib import Path
import queue
import tkinter as tk
from tkinter import ttk,filedialog,messagebox

from apple_theme import C
from apple_widgets import AppleButton,SearchSelect
from browser_sessions import request_quota
from filing_ui import table
from invoice_quota import FIELDS,load_quota,save_quota,month_value,quota_warning
from tax_status import status_company


def open_quota(parent,companies,login_callback):
    from workspace_modules import _window
    win=_window(parent,'开票额度管理','按企业／自然月记录 · 金额单位：元（不含增值税） · 不申请调额、不开票','1180x800')
    companies=[c for c in companies if status_company(c)]
    if not companies:
        tk.Label(win,text='请先在企业档案补全企业名称、地区和税号。').pack(pady=30);return win
    labels=[f"{c.get('internal_code','')}｜{c['name']}（{c['region']}）" for c in companies]
    chosen=tk.StringVar(win,value=labels[0]);month=tk.StringVar(win,value=datetime.now().strftime('%Y-%m'))
    amounts={k:tk.StringVar(win) for k in FIELDS};note=tk.StringVar(win)
    feedback=tk.StringVar(win);source=tk.StringVar(win,value='人工录入')
    imported=[None];rows=[[]];busy=[False];generation=[0];loading=[False]
    box=tk.Frame(win,bg=C('white'));box.pack(fill='x',padx=24,pady=8)
    box.columnconfigure(0,weight=3);box.columnconfigure(1,weight=1)
    tk.Label(box,text='企业（代码／名称／税号搜索）',bg=C('white')).grid(row=0,column=0,sticky='w',padx=8)
    tk.Label(box,text='月份 YYYY-MM',bg=C('white')).grid(row=0,column=1,sticky='w',padx=8)
    SearchSelect(box,chosen,[(label,label+' '+c['tax_id']) for label,c in zip(labels,companies)]).grid(row=1,column=0,sticky='ew',padx=8,pady=4)
    ttk.Entry(box,textvariable=month,width=14).grid(row=1,column=1,sticky='ew',padx=8)
    fields=tk.Frame(win,bg=C('white'));fields.pack(fill='x',padx=24)
    for index,(key,label) in enumerate(zip(FIELDS,('总额度（元）','已使用额度（元）','剩余可用额度（元）'))):
        fields.columnconfigure(index,weight=1)
        tk.Label(fields,text=label,bg=C('white')).grid(row=0,column=index,sticky='w',padx=8,pady=4)
        ttk.Entry(fields,textvariable=amounts[key]).grid(row=1,column=index,sticky='ew',padx=8,pady=4)
    notes=tk.Frame(win,bg=C('white'));notes.pack(fill='x',padx=24,pady=4)
    tk.Label(notes,text='备注',bg=C('white')).pack(side='left',padx=8)
    ttk.Entry(notes,textvariable=note).pack(side='left',fill='x',expand=True,padx=8)
    tk.Label(notes,textvariable=source,bg=C('white'),fg=C('muted')).pack(side='right',padx=8)
    actions=tk.Frame(win,bg=C('parchment'));actions.pack(fill='x',padx=24,pady=6)
    tk.Label(win,text='空白＝未读取，不按零处理；不根据本地开票预览扣额度，不将“总额－已用”冒充税局当前可用额度。低余额提醒阈值：剩余≤总额20%。',
             bg=C('parchment'),fg=C('muted'),wraplength=1050,anchor='w',justify='left').pack(fill='x',padx=24)
    status=tk.Label(win,textvariable=feedback,bg=C('white'),fg=C('ink'),wraplength=1050,anchor='w',justify='left',padx=8,pady=6)
    status.pack(fill='x',padx=24,pady=4)
    columns=(('internal_code','企业代码',90),('name','企业名称',220),('month','月份',85),('total','总额度（元）',125),('used','已用（元）',125),
             ('remaining','剩余（元）',125),('warning','提醒',160),('source','来源',100),('saved_at','记录时间',165))
    tree=table(win,columns)
    history_mode=tk.BooleanVar(win,value=False)

    def company():return next((c for label,c in zip(labels,companies) if label==chosen.get()),None)

    def paint():
        tree.delete(*tree.get_children());rows[0]=[]
        try:
            selected_month=month_value(month.get())
            selected=company()
            if history_mode.get() and selected:
                records=load_quota(selected,selected_month)
            else:
                records=[]
                for c in companies:
                    found=load_quota(c,selected_month)
                    records.append(found[0] if found else {**{k:c.get(k,'') for k in ('region','internal_code','tax_id','name')},'month':selected_month,
                                   'saved_at':'未记录','source':'未记录',**dict.fromkeys(FIELDS)})
            rows[0]=records
            for i,row in enumerate(records):
                view={**row,'warning':quota_warning(row) if row.get('source')!='未记录' else '未记录'}
                tree.insert('','end',iid=str(i),values=[view.get(key) if view.get(key) is not None else '未读取' for key,_,_ in columns])
        except (OSError,ValueError) as error:feedback.set(str(error))

    def selected(*_):
        generation[0]+=1;busy[0]=False;imported[0]=None
        loading[0]=True
        for v in amounts.values():v.set('')
        note.set('');source.set('人工录入')
        current=company()
        for button in (save_button,read_button,login_button):button.configure(state='normal' if current else 'disabled')
        feedback.set('请从候选列表确认企业。' if not current else '可人工录入；税局读取需已打开的页面明确展示企业身份、月份、额度和单位。')
        try:
            if current:
                found=load_quota(current,month_value(month.get()))
                if found:
                    latest=found[0]
                    for key,v in amounts.items():v.set(latest.get(key) or '')
                    note.set(latest.get('note',''))
                    feedback.set('最近记录：'+latest['saved_at']+'，来源：'+latest['source']+'。'+quota_warning(latest)+'；历史数据不代表税局实时额度。')
        except (OSError,ValueError) as error:feedback.set(str(error))
        finally:loading[0]=False
        paint()

    def edited(*_):
        if not loading[0]:
            generation[0]+=1;busy[0]=False
            if company():read_button.configure(state='normal')
            imported[0]=None;source.set('人工录入')

    def save():
        current=company()
        if not current:return
        try:
            origin=imported[0]
            memo=note.get()
            if origin:memo+='\n页面：'+origin['url']+'；读取时间：'+origin['observed_at']
            saved=save_quota(current,month_value(month.get()),{k:v.get() for k,v in amounts.items()},
                             '税局页面读取' if origin else '人工录入',memo)
            feedback.set('已保存独立历史版本。'+quota_warning(saved)+'。仅本机记录，不修改税局额度。')
            paint()
        except (OSError,ValueError) as error:messagebox.showwarning('未保存',str(error),parent=win)

    def read():
        current=company()
        if busy[0] or not current:return
        try:response=request_quota(current,month_value(month.get()))
        except Exception as error:feedback.set(str(error));return
        token=generation[0];busy[0]=True;read_button.configure(state='disabled')
        deadline=datetime.now().timestamp()+25
        feedback.set('正在只读识别已打开的税局额度页，不点击页面、不申请调额…')
        def poll():
            if not win.winfo_exists() or token!=generation[0]:return
            try:value=response.get_nowait()
            except queue.Empty:
                if datetime.now().timestamp()<deadline:win.after(200,poll);return
                value={'error':'读取超时。旧记录未改变，可先人工录入。'}
            busy[0]=False;read_button.configure(state='normal')
            if value.get('error'):feedback.set(value['error']);return
            loading[0]=True
            for k,v in amounts.items():v.set(value.get(k) or '')
            loading[0]=False;imported[0]=value;source.set('税局读取（待核对保存）')
            feedback.set('已识别，尚未保存。请核对金额和月份后点击“保存额度记录”；缺失字段保持空白。')
        poll()

    def export():
        if not rows[0]:return
        destination=filedialog.asksaveasfilename(parent=win,defaultextension='.json',initialfile='开票额度-'+month.get()+'.json')
        if destination:
            try:
                Path(destination).write_text(json.dumps({'notice':'本机观察／人工录入，非税局实时证明','records':rows[0]},ensure_ascii=False,indent=2),encoding='utf-8')
                feedback.set('已导出当前列表（含来源和记录时间），未上传到GitHub。')
            except OSError as error:messagebox.showerror('导出失败',str(error),parent=win)

    def pick(_=None):
        if not tree.selection():return
        row=rows[0][int(tree.selection()[0])]
        if history_mode.get():
            messagebox.showinfo('历史额度记录',json.dumps(row,ensure_ascii=False,indent=2),parent=win);return
        match=next((label for label,c in zip(labels,companies) if all(c.get(k)==row.get(k) for k in ('region','internal_code','tax_id','name'))),None)
        if match:chosen.set(match)

    save_button=AppleButton(actions,text='保存额度记录',command=save,bg=C('primary'),fg='white');save_button.pack(side='right',padx=4)
    read_button=AppleButton(actions,text='读取税局额度页',command=read);read_button.pack(side='right',padx=4)
    login_button=AppleButton(actions,text='登录所选企业',command=lambda:login_callback(company()) if company() else None);login_button.pack(side='right',padx=4)
    AppleButton(actions,text='导出列表',command=export).pack(side='left')
    ttk.Checkbutton(actions,text='所选企业历史',variable=history_mode,command=paint).pack(side='left',padx=8)
    tree.bind('<Double-1>',pick)
    traces=[(chosen,chosen.trace_add('write',selected)),(month,month.trace_add('write',selected))]
    traces.extend((v,v.trace_add('write',edited)) for v in amounts.values())
    def cleanup(event):
        if event.widget is not win:return
        generation[0]+=1
        for variable,token in traces:
            try:variable.trace_remove('write',token)
            except tk.TclError:pass
        traces.clear()
    win.bind('<Destroy>',cleanup,add='+')
    def fit(_=None):
        width=max(200,win.winfo_width()-80)
        status.configure(wraplength=width)
        for widget in win.winfo_children():
            if isinstance(widget,tk.Label):widget.configure(wraplength=width)
    win.bind('<Configure>',fit,add='+')
    selected()
    return win
