"""Local identity/month-bound quota observations. Never changes a tax quota."""
from datetime import datetime
from decimal import Decimal, InvalidOperation
import hashlib
import json
import os
from pathlib import Path
import re
import threading
import uuid
from urllib.parse import urlparse,urlunparse

from tax_status import clean,regional_site,status_company

_lock=threading.RLock()
FIELDS=('total','used','remaining')
LABELS={'total':('发票总额度','开具金额总额度','总开票额度'),
        'used':('已使用额度','已用额度','已使用发票额度'),
        'remaining':('剩余可用发票额度','剩余可用额度','剩余开票额度')}

def month_value(value):
    text=str(value).strip()
    if not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])',text):raise ValueError('月份请填写YYYY-MM，例如2026-10。')
    return text

def money(value):
    if value is None or str(value).strip() in ('','未读取'):return None
    text=str(value).strip()
    if not re.fullmatch(r'(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d{1,2})?',text):
        raise ValueError('金额仅支持非负数字，最多两位小数；单位为元。空白代表未读取。')
    try:amount=Decimal(text.replace(',',''))
    except InvalidOperation:raise ValueError('金额格式不正确。') from None
    if amount>Decimal('999999999999999.99'):raise ValueError('金额超出支持范围。')
    return format(amount.quantize(Decimal('.01')),'f')

def quota_path(company,month,directory=None):
    if not status_company(company):raise ValueError('请先补全企业名称、税号和地区。')
    identity='|'.join(clean(company.get(k,'')) for k in ('region','internal_code','tax_id'))
    key=hashlib.sha256(identity.encode()).hexdigest()
    base=Path(directory) if directory else Path(os.environ.get('LOCALAPPDATA',Path.home()))/'ShenzhenTaxLoginManager'
    return base/'invoice-quotas'/key/(month_value(month)+'.json')

def load_quota(company,month,directory=None):
    path=quota_path(company,month,directory)
    with _lock:
        if not path.exists():return []
        try:
            rows=json.loads(path.read_text(encoding='utf-8'))
            if not isinstance(rows,list):raise ValueError()
            for row in rows:
                if any(row.get(k)!=company.get(k) for k in ('region','internal_code','tax_id','name')) or row.get('month')!=month:
                    raise ValueError()
                for field in FIELDS:money(row.get(field))
            return rows
        except (ValueError,TypeError,AttributeError):
            raise ValueError('额度档案损坏或企业身份不一致，未覆盖原记录。') from None

def save_quota(company,month,values,source='人工录入',note='',directory=None):
    month=month_value(month)
    amounts={key:money(values.get(key)) for key in FIELDS}
    if not any(value is not None for value in amounts.values()):raise ValueError('请至少填写一项额度，空白不会当作零。')
    if source not in ('人工录入','税局页面读取'):raise ValueError('不支持此数据来源。')
    row={**{k:company.get(k,'') for k in ('region','internal_code','tax_id','name')},'month':month,
         **amounts,'source':source,'note':str(note)[:1000],'basis':'元，不含增值税；以税局口径为准',
         'saved_at':datetime.now().isoformat(timespec='seconds'),'id':uuid.uuid4().hex}
    path=quota_path(company,month,directory)
    with _lock:
        previous=load_quota(company,month,directory)
        path.parent.mkdir(parents=True,exist_ok=True)
        temp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
        try:
            temp.write_text(json.dumps([row]+previous,ensure_ascii=False,indent=2),encoding='utf-8')
            os.replace(temp,path)
        finally:
            if temp.exists():temp.unlink()
    return row

def quota_warning(row,threshold='20'):
    if not row:return '未记录'
    remaining=money(row.get('remaining'));total=money(row.get('total'))
    if remaining is None:return '剩余额度未读取'
    if Decimal(remaining)==0:return '剩余额度为零（请核对税局）'
    if total is None or Decimal(total)==0:return '总额度未知，请核对'
    if Decimal(remaining)>Decimal(total):return '剩余大于总额，请核对来源'
    if Decimal(remaining)/Decimal(total)*100<=Decimal(threshold):return '低余额提醒'
    return '已记录（非实时）'

def parse_quota_text(text,month):
    month_value(month)
    dates={f'{int(y):04d}-{int(m):02d}' for y,m in re.findall(r'(20\d{2})[年/-](0?[1-9]|1[0-2])(?=月|[-/\s]|$)',text)}
    if dates!={month}:raise ValueError('页面月份缺失、与所选月份不符或包含多个月份，请人工核对录入。')
    result={}
    for field,labels in LABELS.items():
        found=set()
        pattern=r'(?:'+ '|'.join(map(re.escape,labels))+r')\s*(?:[（(]\s*(元|万元)\s*[）)])?\s*[:：]?\s*[¥￥]?\s*((?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d{1,2})?)(?![\d.,A-Za-z])\s*(万元|元)?'
        for match in re.finditer(pattern,text):
            before,number,after=match.groups()
            # Never guess a unit absent from a clearly labeled field.
            unit=after or before
            if not unit or before and after and before!=after:continue
            value=Decimal(number.replace(',',''))*(10000 if unit=='万元' else 1)
            found.add(money(format(value,'f')))
        if len(found)>1:raise ValueError('页面同一额度有多个不同数值，请人工核对录入。')
        result[field]=next(iter(found),None)
    if not any(v is not None for v in result.values()):raise ValueError('未识别到明确单位的额度字段。此版式需适配，可先人工录入。')
    return result

def capture_quota(context,company,month):
    if not status_company(company):raise ValueError('企业身份信息不完整。')
    results=[]
    for page in context.pages:
        if page.is_closed() or not regional_site(page.url,company):continue
        texts=[]
        for frame in page.frames:
            if not regional_site(frame.url,company):continue
            try:texts.append(frame.locator('body').inner_text(timeout=1000)[:500000])
            except Exception:continue
        text='\n'.join(texts);normalized=clean(text);name=clean(company['name']);tax_id=clean(company['tax_id'])
        matched=name in normalized or any(name[:n]+mark in normalized for n in range(8,len(name)) for mark in ('...','…'))
        if not matched or tax_id not in normalized:continue
        try:values=parse_quota_text(text,month)
        except ValueError:continue
        parsed=urlparse(page.url)
        source=urlunparse((parsed.scheme,parsed.netloc,parsed.path,'','',''))
        results.append({**values,'month':month,'url':source,'observed_at':datetime.now().isoformat(timespec='seconds')})
    if not results:raise ValueError('未找到同时匹配企业身份、月份和明确额度单位的官方页面。请在同一会话打开额度页面；不自动跳转或申请调额，可先人工录入。')
    if len({tuple(r[k] for k in FIELDS) for r in results})>1:raise ValueError('多个已打开页面的额度不同，请核对并关闭过期页面后重读。')
    return results[0]
