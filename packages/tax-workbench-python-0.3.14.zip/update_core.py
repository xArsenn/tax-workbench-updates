"""Signed, side-by-side application updates. No company data is packaged."""
import base64
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import sys
import tempfile
import urllib.request
from urllib.parse import urlparse
import uuid
import zipfile

HOME = Path(os.environ.get('TAX_WORKBENCH_HOME', Path(__file__).resolve().parent)).resolve()
STORE = HOME / 'update_store'
MAX_PACKAGE = 512 * 1024 * 1024
MAX_EXPANDED = 1024 * 1024 * 1024
ENTRY = '税务登录助手_开发版.pyw'

def read_json(path, default=None):
    return json.loads(Path(path).read_text(encoding='utf-8')) if Path(path).is_file() else default

def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary = path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    temporary.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(temporary,path)

def version_tuple(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d+\.\d+\.\d+',value):
        raise ValueError('版本号必须是三段数字，例如 0.2.1')
    return tuple(map(int,value.split('.')))

def current_version():
    path=Path(os.environ.get('TAX_WORKBENCH_VERSION_DIR',HOME))/'version.json'
    return read_json(path,{'version':'0.2.0'})['version']

def state():
    return read_json(STORE/'state.json',{'current':None,'previous':None,'pending':None})

def canonical(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')

def rsa_verify(payload, signature, key):
    """RSA PKCS#1 v1.5 SHA256, using a pinned public key outside the package."""
    n=int(key['n'],16);e=int(key['e'])
    if n.bit_length()<2048 or e != 65537:
        raise ValueError('更新公钥无效（需要至少2048位RSA）')
    signature=base64.b64decode(signature,validate=True)
    size=(n.bit_length()+7)//8
    if len(signature)!=size or int.from_bytes(signature,'big')>=n:
        raise ValueError('更新签名无效')
    decoded=pow(int.from_bytes(signature,'big'),e,n).to_bytes(size,'big')
    digest_info=bytes.fromhex('3031300d060960864801650304020105000420')+hashlib.sha256(canonical(payload)).digest()
    expected=b'\x00\x01'+b'\xff'*(size-len(digest_info)-3)+b'\x00'+digest_info
    import hmac
    if not hmac.compare_digest(expected,decoded):
        raise ValueError('更新签名验证失败，请勿安装')

def verify_manifest(envelope, key, running=None, channel='stable'):
    payload=envelope['payload']
    rsa_verify(payload,envelope['signature'],key)
    if payload.get('app_id')!='tax-workbench' or payload.get('channel')!=channel:
        raise ValueError('此更新不属于当前应用或发布通道')
    if version_tuple(payload['version'])<=version_tuple(running or current_version()):
        return None
    minimum=payload.get('min_python','3.10')
    if not isinstance(minimum,str) or not re.fullmatch(r'\d+\.\d+',minimum):
        raise ValueError('更新清单中的Python版本要求无效')
    if sys.version_info[:2]<tuple(map(int,minimum.split('.'))):
        raise ValueError('此更新需要Python '+minimum+'或以上版本，请先升级运行环境')
    if not re.fullmatch(r'[0-9a-f]{64}',payload.get('sha256','')):
        raise ValueError('更新清单缺少合法校验值')
    if not isinstance(payload.get('size'),int) or not 0<payload['size']<=MAX_PACKAGE:
        raise ValueError('更新包大小无效')
    urls=payload.get('urls')
    if not isinstance(urls,list) or not urls or len(urls)>5:
        raise ValueError('更新清单下载地址无效')
    for url in urls:
        require_https(url)
    return payload

def require_https(url):
    parsed=urlparse(url)
    if parsed.scheme!='https' or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError('更新地址必须使用HTTPS且不能包含账号密码')

class HttpsOnly(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        require_https(newurl)
        return super().redirect_request(req,fp,code,msg,headers,newurl)

def response(url):
    require_https(url)
    opener=urllib.request.build_opener(HttpsOnly)
    result=opener.open(urllib.request.Request(url,headers={'User-Agent':'TaxWorkbench-Updater/1','Cache-Control':'no-cache'}),timeout=20)
    require_https(result.url)
    return result

def content_bytes(url, limit):
    """Accept ordinary assets or GitHub Contents JSON without embedding a token."""
    with response(url) as stream:
        wrapper = urlparse(url).hostname=='api.github.com' and '/contents/' in urlparse(url).path
        raw=stream.read((limit*2+1024 if wrapper else limit)+1)
    if wrapper:
        value=json.loads(raw)
        if value.get('encoding')!='base64':
            raise ValueError('GitHub未返回文件内容，请改用备用下载地址')
        raw=base64.b64decode(value['content'])
    if len(raw)>limit:raise ValueError('下载内容超过允许大小')
    return raw

def check_update():
    settings=read_json(HOME/'update_settings.json',{})
    url=settings.get('manifest_url','').strip()
    if not url:
        raise ValueError('尚未配置更新源。请在更新设置中填写正式发布清单地址。')
    key=read_json(HOME/'update_public_key.json')
    if not key:
        raise ValueError('尚未配置发布公钥，暂不能验证更新来源。请联系发布者。')
    urls=settings.get('manifest_urls') or [url]
    if not isinstance(urls,list) or not urls or len(urls)>5:
        raise ValueError('更新源配置无效')
    failures=[];verified=False;newest=None
    for source in urls:
        try:
            fresh=source+('&' if '?' in source else '?')+'_tax_check='+uuid.uuid4().hex
            raw=content_bytes(fresh,1024*1024)
        except Exception as error:
            failures.append(str(error));continue
        # A retrieved but invalid signature is a security error, not a network
        # outage. Never mask it by accepting a different mirror silently.
        candidate=verify_manifest(json.loads(raw),key,channel=settings.get('channel','stable'))
        verified=True
        if candidate and (not newest or version_tuple(candidate['version'])>version_tuple(newest['version'])):
            newest=candidate
    if verified:return newest
    raise ValueError('无法连接更新源，当前版本和公司资料均未更改。请稍后重试。\n'+'；'.join(failures))

def download(payload, progress=None):
    STORE.mkdir(exist_ok=True)
    target=STORE/('download-'+uuid.uuid4().hex+'.zip')
    failures=[]
    for url in payload['urls']:
        try:
            digest=hashlib.sha256();count=0
            if urlparse(url).hostname=='api.github.com' and '/contents/' in urlparse(url).path:
                raw=content_bytes(url,payload['size'])
                target.write_bytes(raw);digest.update(raw);count=len(raw)
                if progress:progress(count,payload['size'])
            else:
                with response(url) as stream, target.open('wb') as out:
                    while True:
                        chunk=stream.read(128*1024)
                        if not chunk:break
                        count+=len(chunk)
                        if count>payload['size']:raise ValueError('更新包超过清单大小')
                        out.write(chunk);digest.update(chunk)
                        if progress:progress(count,payload['size'])
            if count!=payload['size'] or digest.hexdigest()!=payload['sha256']:
                raise ValueError('下载文件不完整或校验失败')
            return target
        except Exception as error:
            failures.append(str(error))
    target.unlink(missing_ok=True)
    raise ValueError('全部下载地址均失败：'+'；'.join(failures))

def stage_package(package, payload, store=None):
    """Verify ZIP layout and place a complete version beside existing releases."""
    store=Path(store or STORE)
    version_tuple(payload['version'])
    package=Path(package)
    if package.stat().st_size!=payload['size'] or hashlib.sha256(package.read_bytes()).hexdigest()!=payload['sha256']:
        raise ValueError('更新包校验失败')
    versions=store/'versions';versions.mkdir(parents=True,exist_ok=True)
    final=versions/payload['version']
    temporary=Path(tempfile.mkdtemp(prefix='staging-',dir=versions))
    try:
        with zipfile.ZipFile(package) as archive:
            names=set();total=0
            for item in archive.infolist():
                p=PurePosixPath(item.filename)
                reserved=any(part.rstrip(' .')!=part or part.split('.')[0].upper() in
                             ('CON','PRN','AUX','NUL',*(f'COM{i}' for i in range(1,10)),*(f'LPT{i}' for i in range(1,10))) for part in p.parts)
                if ('\\' in item.filename or ':' in item.filename or p.is_absolute() or '..' in p.parts or reserved
                    or not p.parts or len(p.parts)>12 or (item.external_attr>>16)&0o170000==0o120000):
                    raise ValueError('更新包包含不安全路径')
                normalized=str(p).casefold()
                if normalized in names:raise ValueError('更新包存在重名路径')
                names.add(normalized);total+=item.file_size
                if total>MAX_EXPANDED or len(names)>10000:raise ValueError('解压内容过大')
                if not item.is_dir():
                    destination=temporary.joinpath(*p.parts)
                    destination.parent.mkdir(parents=True,exist_ok=True)
                    with archive.open(item) as src,destination.open('wb') as dst:
                        shutil.copyfileobj(src,dst)
        if not (temporary/ENTRY).is_file() or read_json(temporary/'version.json',{}).get('version')!=payload['version']:
            raise ValueError('更新包缺少主程序或版本不匹配')
        saved=read_json(store/'state.json',{'current':None,'previous':None,'pending':None})
        if saved.get('pending') and version_tuple(saved['pending'])>version_tuple(payload['version']):
            raise ValueError('已有更高版本等待更新，不会改回较旧版本')
        # Never overwrite an active version. Existing inactive complete packages
        # can be rearmed after a failed state write or interrupted restart.
        if final.is_symlink() or getattr(final,'is_junction',lambda:False)():
            raise ValueError('版本目录是链接，不能安全恢复，请联系维护人员')
        if final.exists():
            if final.resolve().parent!=versions.resolve():raise ValueError('版本目录超出更新存储位置')
            if any(p.is_symlink() or getattr(p,'is_junction',lambda:False)() for p in final.rglob('*')):
                raise ValueError('已有版本含链接，不能安全恢复，请联系维护人员')
            expected={p.relative_to(temporary) for p in temporary.rglob('*') if p.is_file()}
            actual={p.relative_to(final) for p in final.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
            reusable=actual==expected and all(not (final/p).is_symlink() and
                      hashlib.sha256((final/p).read_bytes()).digest()==hashlib.sha256((temporary/p).read_bytes()).digest()
                      for p in expected)
            if saved.get('current')==payload['version']:
                raise ValueError('该版本正在使用，不会覆盖或重新准备；请检查更新获取更新版本')
            if reusable:
                saved['pending']=payload['version'];atomic_json(store/'state.json',saved)
                return final
            # Preserve broken/incomplete inactive contents rather than delete.
            recovery=store/'recovered';recovery.mkdir(exist_ok=True)
            if recovery.is_symlink() or getattr(recovery,'is_junction',lambda:False)() or recovery.resolve().parent!=store.resolve():
                raise ValueError('恢复备份目录不安全，未移动任何版本文件')
            backup=recovery/(payload['version']+'-'+uuid.uuid4().hex)
            if backup.resolve().parent!=recovery.resolve():raise ValueError('恢复备份路径无效')
            os.replace(final,backup)
            try:os.replace(temporary,final)
            except Exception:
                if not final.exists():os.replace(backup,final)
                raise
            saved['recovered_version_path']=str(backup)
        else:os.replace(temporary,final)
        saved['pending']=payload['version']
        atomic_json(store/'state.json',saved)
        return final
    finally:
        # Only remove this function's newly-created staging directory.
        if temporary.exists():shutil.rmtree(temporary)

def startup_ready():
    """Commit only after the application has built and reached its event loop."""
    atomic_json(HOME/'runtime_health.json',{'pid':os.getpid(),'version':current_version(),
                'updater_module':str(Path(__file__).resolve()),
                'version_directory':os.environ.get('TAX_WORKBENCH_VERSION_DIR',str(HOME)),
                'workspace_module':getattr(sys.modules.get('workspace_modules'),'__file__',None)})
    running=os.environ.get('TAX_WORKBENCH_PENDING')
    if running:
        saved=state()
        if saved.get('pending')==running:
            saved.update(previous=saved.get('current'),current=running,pending=None)
            atomic_json(STORE/'state.json',saved)
