"""Filing archive and explicit, read-only status pilot native workspaces."""
from datetime import datetime
import json
from pathlib import Path
import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from apple_theme import C
from apple_widgets import AppleButton, SearchSelect
from browser_sessions import request_snapshot, auto_sync_state, set_auto_sync
from filing_archive import Archive
from tax_status import NOTICE, status_company
from status_store import load_status


def archive_root():
    from workspace_modules import APP_DIR
    path = APP_DIR/'archive_settings.json'
    try: return Path(json.loads(path.read_text(encoding='utf-8'))['root'])
    except (OSError,ValueError,KeyError): return APP_DIR/'filing-archive'


def table(parent, columns):
    frame=tk.Frame(parent,bg=C('white'));frame.pack(fill='both',expand=True,padx=24,pady=12)
    tree=ttk.Treeview(frame,columns=[x[0] for x in columns],show='headings',selectmode='extended')
    for key,label,width in columns:tree.heading(key,text=label);tree.column(key,width=width,minwidth=70)
    tree.grid(row=0,column=0,sticky='nsew')
    y=ttk.Scrollbar(frame,command=tree.yview);y.grid(row=0,column=1,sticky='ns')
    x=ttk.Scrollbar(frame,orient='horizontal',command=tree.xview);x.grid(row=1,column=0,sticky='ew')
    tree.configure(yscrollcommand=y.set,xscrollcommand=x.set)
    frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1)
    return tree


def open_archive(parent, companies):
    from workspace_modules import _window, APP_DIR
    win=_window(parent,'申报资料档案','本机备份 · 企业／所属期／税种归档 · 历史版本保留 · 不上传GitHub','1160x780')
    root=tk.StringVar(win,value=str(archive_root()))
    company=tk.StringVar(win);period=tk.StringVar(win,value=f'{datetime.now().year}年')
    tax=tk.StringVar(win,value='财务报表');category=tk.StringVar(win,value='原始报表')
    summary=tk.StringVar(win,value='选择企业后导入资料；可按住Ctrl多选导出。请勿导入密码、验证码或会话文件。')
    pathbar=tk.Frame(win,bg=C('white'));pathbar.pack(fill='x',padx=24,pady=12)
    tk.Label(pathbar,textvariable=root,bg=C('white'),anchor='w').pack(side='left',fill='x',expand=True,padx=10)
    fields=tk.Frame(win,bg=C('white'));fields.pack(fill='x',padx=24)
    for i,label in enumerate(('企业','所属期（如2026年第3季度）','税种／事项','资料类型')):
        tk.Label(fields,text=label,bg=C('white')).grid(row=0,column=i,sticky='w',padx=8,pady=8)
        fields.columnconfigure(i,weight=1)
    labels=[f"{x.get('internal_code','')}｜{x.get('name','')}" for x in companies]
    SearchSelect(fields,company,[(label,label+' '+str(data.get('tax_id',''))) for label,data in zip(labels,companies)]).grid(row=1,column=0,sticky='ew',padx=8,pady=8)
    ttk.Entry(fields,textvariable=period).grid(row=1,column=1,sticky='ew',padx=8)
    ttk.Combobox(fields,textvariable=tax,values=('财务报表','增值税及附加税费','企业所得税','印花税','其他')).grid(row=1,column=2,sticky='ew',padx=8)
    ttk.Combobox(fields,textvariable=category,state='readonly',values=('原始报表','转换后报表','申报表','申报回执','缴款凭证','其他资料')).grid(row=1,column=3,sticky='ew',padx=8)
    tree=table(win,(('company','企业',130),('period','所属期',150),('tax','税种／事项',150),('category','资料类型',100),('filename','文件',220),('version','版本',65),('saved_at','归档时间',170)))
    def selected_company():
        return next((x.get('internal_code') or x.get('tax_id') for x,label in zip(companies,labels) if label==company.get()),None)
    def refresh(*_):
        try:
            repo=Archive(root.get());tree.delete(*tree.get_children())
            for x in repo.records(selected_company()):
                tree.insert('', 'end',iid=x['id'],values=[x[k] for k in ('company','period','tax','category','filename','version','saved_at')])
        except Exception as e:summary.set('档案读取失败：'+str(e))
    def choose_root():
        chosen=filedialog.askdirectory(parent=win,title='选择档案保存位置（已有档案不会自动搬迁）')
        if chosen:
            root.set(chosen);(APP_DIR/'archive_settings.json').write_text(json.dumps({'root':chosen},ensure_ascii=False),encoding='utf-8');refresh()
            summary.set('保存位置已切换；旧位置资料仍保留，没有删除或自动搬迁。')
    AppleButton(pathbar,text='选择备份位置',command=choose_root).pack(side='right')
    footer=tk.Frame(win,bg=C('parchment'));footer.pack(fill='x',padx=24,pady=10)
    busy=[False]
    def job(work):
        if busy[0]:return
        busy[0]=True;summary.set('正在处理资料，请勿关闭此窗口…');events=queue.Queue()
        def worker():
            try:events.put((True,work()))
            except Exception as e:events.put((False,str(e)))
        threading.Thread(target=worker,daemon=True).start()
        def poll():
            if not win.winfo_exists():return
            try:ok,message=events.get_nowait()
            except queue.Empty:win.after(100,poll);return
            busy[0]=False;summary.set(message);refresh()
            if not ok:messagebox.showerror('资料处理失败',message,parent=win)
        poll()
    def add():
        code=selected_company()
        if not code:messagebox.showwarning('请选择企业','请从候选列表确认企业。',parent=win);return
        paths=filedialog.askopenfilenames(parent=win,title='导入申报资料（不会修改源文件）')
        if not paths:return
        values=(root.get(),code,period.get().strip(),tax.get().strip(),category.get())
        def work():
            repo=Archive(values[0]);count=0
            try:
                for path in paths:repo.add_file(path,*values[1:]);count+=1
            except Exception as e:raise ValueError(f'已归档{count}份，其余未完成：{e}')
            return f'已归档{count}份资料，源文件未修改；重复文件保留版本记录。'
        job(work)
    def export():
        ids=tree.selection()
        if not ids:return
        destination=filedialog.asksaveasfilename(parent=win,defaultextension='.zip',initialfile='申报资料备份.zip',filetypes=[('ZIP备份','*.zip')])
        if destination:
            selected_root=root.get()
            job(lambda:f'已导出{Archive(selected_root).export(destination,ids)}份资料（含SHA256清单）。')
    AppleButton(footer,text='导入资料并备份',command=add,bg=C('primary'),fg='white').pack(side='right')
    AppleButton(footer,text='导出选中资料',command=export).pack(side='right',padx=8)
    tk.Label(win,textvariable=summary,bg=C('parchment'),fg=C('muted'),wraplength=1050,anchor='w').pack(fill='x',padx=24,pady=(0,14))
    company.trace_add('write',refresh);refresh()


def open_status(parent, companies, login_callback):
    from workspace_modules import _window
    win=_window(parent,'申报与缴费状态','多企业独立读取 · 仅采集已打开页 · 不自动申报、不扣款','1180x800')
    companies=[x for x in companies if status_company(x)]
    if not companies:
        tk.Label(win,text='请先在企业档案中补全企业名称、税号和地区。').pack(pady=30);return win
    company=companies[0]
    generation=[0]
    labels=[f"{x.get('internal_code','')}｜{x['name']}（{x['region']}）" for x in companies]
    chosen=tk.StringVar(win,value=labels[0])
    summary=tk.StringVar(win,value=NOTICE)
    auto_label=tk.StringVar(win)
    snapshot=[None];busy=[False]
    bar=tk.Frame(win,bg=C('white'));bar.pack(fill='x',padx=24,pady=10)
    SearchSelect(bar,chosen,[(label,label+' '+str(data.get('tax_id',''))) for label,data in zip(labels,companies)]).pack(fill='x',padx=12,pady=4)
    actions=tk.Frame(bar,bg=C('white'));actions.pack(fill='x',padx=6,pady=4)
    enabled=tk.BooleanVar(win,value=auto_sync_state(company)['enabled'])
    ttk.Checkbutton(bar,text='会话有效期间每30秒自动采集（只读取页面，不刷新税局查询）',
                    variable=enabled,command=lambda:set_auto_sync(enabled.get(),company) if company else None).pack(anchor='w',padx=12,pady=4)
    tk.Label(bar,textvariable=auto_label,bg=C('white'),fg=C('muted'),anchor='w',wraplength=1050).pack(fill='x',padx=12,pady=(0,6))
    feedback=tk.Label(win,textvariable=summary,bg=C('white'),fg=C('ink'),wraplength=1050,anchor='w',justify='left',padx=12,pady=10)
    feedback.pack(fill='x',padx=24,pady=(0,8))
    tk.Label(win,text='首页不含缴费金额。请在同一登录会话打开缴款查询并执行查询，随后自动采集。不同来源、所属期不强行合并或累加。双击记录可看税局原文。',bg=C('parchment'),fg=C('muted'),wraplength=1080,anchor='w',justify='left').pack(fill='x',padx=24,pady=6)
    columns=(('tax','税种／事项',170),('period','所属期（税局原文）',175),('declaration','申报状态',100),('payment','缴费状态',100),('paid','已缴金额',105),('outstanding','待缴金额',105),('payable','应缴金额',105),('payment_amount','页面缴款金额¹',120),('kind','记录来源',100),('observed_at','读取时间',175))
    tree=table(win,columns)
    def details(_=None):
        if snapshot[0] and tree.selection():
            row=snapshot[0]['records'][int(tree.selection()[0])]
            text='来源：'+row.get('source','')+'\n读取时间：'+row.get('observed_at',snapshot[0].get('synced_at',''))+'\n\n'+json.dumps(row.get('raw',{}),ensure_ascii=False,indent=2)
            messagebox.showinfo('税局页面原文',text+'\n\n¹页面缴款金额不等于已缴金额；缺少成功状态时不推断已缴。',parent=win)
    tree.bind('<Double-1>',details)
    def display(value):
        snapshot[0]=value;tree.delete(*tree.get_children())
        for index,row in enumerate(value['records']):
            tree.insert('','end',iid=str(index),values=[row.get(key,'未读取') for key,_,_ in columns])
        summary.set(f"本机保留{len(value['records'])}条观察，最近成功读取："+value['synced_at']+'。每条读取时间独立；关闭税局后为历史，不代表实时。'+NOTICE)
        export_button.configure(state='normal')
    def sync():
        if busy[0] or not company:return
        token=generation[0]
        try:response=request_snapshot(company)
        except Exception as error:messagebox.showinfo('请先登录所选企业',str(error),parent=win);return
        busy[0]=True;sync_button.configure(state='disabled')
        summary.set('正在读取当前税局页面，请稍候…不会修改申报或缴款。')
        deadline=datetime.now().timestamp()+20
        def poll():
            if not win.winfo_exists():return
            if token!=generation[0]:return
            try:value=response.get_nowait()
            except queue.Empty:
                if datetime.now().timestamp()<deadline:win.after(200,poll);return
                value={'error':'浏览器20秒内未响应；旧记录未更新。请确认登录会话来自工作台。'}
            busy[0]=False;sync_button.configure(state='normal')
            if value.get('error'):
                summary.set(value['error']);messagebox.showwarning('读取未完成',value['error'],parent=win);return
            display(value)
        poll()
    def export():
        if not snapshot[0]:
            messagebox.showinfo('暂无状态记录','请先选择企业，等待自动采集或点击立即读取。',parent=win);return
        import re
        code=re.sub(r'[^\w-]','_',str(company.get('internal_code') or '企业'))[:60]
        destination=filedialog.asksaveasfilename(parent=win,defaultextension='.json',initialfile=code+'状态快照.json')
        if destination:
            try:
                Path(destination).write_text(json.dumps(snapshot[0],ensure_ascii=False,indent=2),encoding='utf-8')
                summary.set('已导出本机状态快照，可在“申报资料档案”中导入保存。')
            except OSError as error:messagebox.showerror('导出失败',str(error),parent=win)
    login_button=AppleButton(actions,text='登录所选企业',command=lambda:login_callback(company) if company else None)
    login_button.pack(side='right',padx=6)
    sync_button=AppleButton(actions,text='立即读取',command=sync,bg=C('primary'),fg='white')
    sync_button.pack(side='right',padx=6)
    export_button=AppleButton(actions,text='导出状态快照',command=export,state='disabled')
    export_button.pack(side='right',padx=6)
    def fit_labels(_=None):
        width=max(200,win.winfo_width()-80)
        for widget in (feedback,*[x for x in bar.winfo_children() if isinstance(x,tk.Label)],
                       *[x for x in win.winfo_children() if isinstance(x,tk.Label)]):
            widget.configure(wraplength=width)
    win.bind('<Configure>',fit_labels,add='+')
    def select_company(*_):
        nonlocal company
        generation[0]+=1;busy[0]=False
        company=next((data for label,data in zip(labels,companies) if label==chosen.get()),None)
        snapshot[0]=None;tree.delete(*tree.get_children())
        export_button.configure(state='disabled')
        for button in (sync_button,login_button):button.configure(state='normal' if company else 'disabled')
        auto_label.set('各地区页面版式需分别适配；未识别结果不会推断为未申报或零缴款。')
        summary.set('请从候选列表确认企业。' if not company else '尚无该企业的本机记录。'+NOTICE)
        if company:
            enabled.set(auto_sync_state(company)['enabled'])
            value=load_status(company)
            if value:display(value)
    chosen.trace_add('write',select_company)
    select_company()
    def observe():
        if not win.winfo_exists():return
        if not company:win.after(2000,observe);return
        state=auto_sync_state(company)
        if not state['enabled']:message='自动采集已暂停；可点击立即读取。'
        elif not state['active']:message='未连接所选企业的工作台登录会话，当前仅展示本机历史。登录失效需要您完成验证，不会自动重复登录。'
        elif state['error']:message=state['phase']+'：'+state['error']
        else:message=state['phase']+'；仅观察已打开查询页，不代替税局实时查询。'
        auto_label.set(message)
        if not busy[0]:
            value=load_status(company)
            if value and value!=snapshot[0]:display(value)
        win.after(2000,observe)
    observe()
    return win
