"""Identity-bound visible tax tables across configured regional official sites."""
from datetime import datetime
import hashlib
import re
from urllib.parse import urlparse, urlunparse

NOTICE = '仅同步已打开查询页的可见结果，不代表已查询全部税种或分页；未读取到不等于未申报或未缴费。'


def pilot_company(company):
    return company.get('internal_code') == '00XE' and company.get('region') == '江苏'


def status_company(company):
    from official_links import _PROVINCES
    return bool(company and company.get('region') in _PROVINCES and clean(company.get('name','')) and clean(company.get('tax_id','')))


def regional_site(url,company):
    from official_links import _PROVINCES
    parsed=urlparse(url)
    code=_PROVINCES.get(company.get('region'))
    suffix=(code+'.chinatax.gov.cn') if code else ''
    host=(parsed.hostname or '').lower()
    return bool(suffix and parsed.scheme=='https' and not parsed.username and not parsed.password and
                (host==suffix or host.endswith('.'+suffix)))


def clean(value): return re.sub(r'\s+', '', str(value))


def header(value):
    value=clean(value).replace('（','(').replace('）',')')
    return re.sub(r'\((?:人民币)?元\)$','',value).strip('*＊')


def parse_tables(tables, source):
    records = []
    for table in tables:
        headers = [header(x) for x in table.get('headers', [])]
        def find(*names): return next((i for i,h in enumerate(headers) if h in names), None)
        task_list = '事项名称' in headers and '标签状态' in headers
        tax = find('税种','税种名称','征收项目','税费种','税费种名称','事项名称')
        declaration = find('申报状态','申报情况','标签状态')
        payment = find('缴款状态','缴费状态','缴纳状态','扣款状态')
        period = find('税款所属期','所属期','所属期间','税费所属期')
        start, end = find('税款所属期起','所属期起'), find('税款所属期止','所属期止')
        payable=find('应缴金额','应纳税额','应补退税额','应补(退)税额','应缴税费金额')
        paid=find('已缴金额','实缴金额','实缴税额','已缴税额','入库金额','已缴税费金额')
        generic=find('缴款金额','本次缴款金额')
        outstanding=find('待缴金额','未缴金额','未缴税额','欠税金额','未缴税费金额')
        has_amount=any(x is not None for x in (payable,paid,generic,outstanding))
        if tax is None or (declaration is None and payment is None and not (has_amount and (period is not None or start is not None and end is not None))): continue
        kind='本期待办' if task_list else ('缴款查询' if payment is not None or has_amount else '申报查询')
        for cells in table.get('rows', []):
            def value(index): return str(cells[index]).strip() if index is not None and index<len(cells) else ''
            if not value(tax) or value(tax) in ('合计','总计'): continue
            label = value(period) or (value(start)+' 至 '+value(end) if value(start) and value(end) else '')
            paid_value=value(paid)
            # A generic "缴款金额" on an unpaid/failed page is not proof of payment.
            if not paid_value and clean(value(payment)) in ('已缴款','已缴费','缴款成功','扣款成功','已入库'):
                paid_value=value(generic)
            records.append(dict(tax=value(tax),period=label or ('本期应申报（所属期待核对）' if task_list else '所属期待核对'),
                                declaration=value(declaration) or '未读取', payment=value(payment) or '未读取',
                                payable=value(payable) or '未读取',paid=paid_value or '未读取',
                                outstanding=value(outstanding) or '未读取',
                                payment_amount=value(generic) or '未读取',kind=kind,period_known=bool(label),
                                source=source,raw=dict(zip(headers,cells))))
    return records


def capture_context(context, company):
    if not status_company(company): raise ValueError('企业名称、税号或地区不完整，不能安全读取。请先完善企业档案。')
    tax_id, name = clean(company.get('tax_id','')), clean(company.get('name',''))
    if not tax_id or not name: raise ValueError('企业名称或税号不完整，不能核验当前登录身份。')
    identity = False
    snapshots = []
    denied = False
    script = '''() => {
      const tables=[];
      const roots=[...document.querySelectorAll('.el-table,.ant-table-wrapper,table')];
      for(const root of roots){
        if(root.tagName==='TABLE' && root.closest('.el-table,.ant-table-wrapper'))continue;
        const headers=[...root.querySelectorAll('thead th')].map(x=>x.innerText.trim());
        if(!headers.length)continue;
        const cellText=c=>{
          const text=c.innerText.trim(); if(text)return text;
          const field=[...c.querySelectorAll('input:not([type=password]):not([type=hidden]),textarea,select')]
            .find(x=>x.getClientRects().length);
          return field ? String(field.value||'').trim() : '';
        };
        const rows=[...root.querySelectorAll('tbody tr')].filter(x=>x.getClientRects().length)
          .slice(0,1000).map(r=>[...r.querySelectorAll('td')].map(cellText));
        tables.push({headers,rows});
      }
      return {text:(document.body?.innerText||'').slice(0,500000),tables};
    }'''
    for page in context.pages:
        if page.is_closed(): continue
        parsed = urlparse(page.url)
        if not regional_site(page.url,company): continue
        # Keep SPA route identity, never its query/token parameters.
        fragment=parsed.fragment.split('?')[0]
        if not re.fullmatch(r'/[A-Za-z0-9_./-]{0,200}',fragment):fragment=''
        source = urlunparse((parsed.scheme,parsed.netloc,parsed.path,'','',fragment))
        # The homepage abbreviates long enterprise names with an ellipsis.
        # Permit that only when the full tax ID is visible on this same page.
        page_tables = []
        page_matches = False
        page_text = ''
        for frame in page.frames:
            if not regional_site(frame.url,company): continue
            try: snapshot = frame.evaluate(script)
            except Exception: continue
            text = clean(snapshot['text'])
            page_text += text
            page_matches = page_matches or name in text
            identity = identity or (tax_id in text and name in text)
            denied = denied or any(x in text for x in ('您不是用票试点纳税人','无权操作税务数字账户','没有权限'))
            page_tables.extend(snapshot['tables'])
        # A strict prefix of at least eight normalized characters plus ellipsis
        # supports the tax homepage's company card without guessing identity.
        short_match = any(name[:length]+mark in page_text for length in range(8,len(name)) for mark in ('...','…'))
        page_matches = page_matches or (tax_id in page_text and short_match)
        identity = identity or (tax_id in page_text and (name in page_text or short_match))
        # A matching old homepage must not authorize reading a different
        # company's query tab after the user manually switches identity.
        if page_matches and tax_id in page_text: snapshots.append((page_tables,source))
    if not identity: raise ValueError('未在'+company['region']+'官方页面同时核对到所选企业名称和完整税号；请确认企业身份。不会读取其他企业或地区的数据。')
    records = [r for tables,source in snapshots for r in parse_tables(tables,source)]
    if not records:
        raise ValueError(('税局页面提示权限受限；请核对企业身份和人员授权。' if denied else '') +
                         '尚未识别到申报／缴款状态表，请手动打开相应查询页并执行查询；此页版式可能仍需适配。')
    unique = {str(sorted(x.items())):x for x in records}
    groups={}
    for row in unique.values():
        key=hashlib.sha256((row['source']+'|'+row['kind']+'|'+'|'.join(row['raw'])).encode()).hexdigest()
        groups.setdefault(key,{'key':key,'source':row['source'],'kind':row['kind'],'records':[]})['records'].append(row)
    return {'company':company.get('internal_code'), 'region':company['region'], 'tax_id':tax_id, 'company_name':company['name'],
            'synced_at':datetime.now().isoformat(timespec='seconds'), 'coverage':'仅可见查询结果',
            'notice':NOTICE, 'records':list(unique.values()), 'groups':list(groups.values())}
