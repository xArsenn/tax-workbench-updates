"""Small bounded XML reader using Expat included in the original frozen client.

Only the element/path operations used by the invoice reader are supported.
No ElementTree, compiled extension addition, DTD, external entities or network.
"""
from xml.parsers import expat


def _expanded(name):
    return '{'+name if '}' in name else name


class Element:
    def __init__(self,name,attributes):
        self.name=_expanded(name)
        self.attrib={_expanded(key):value for key,value in attributes.items()}
        self.children=[]
        self.parts=[]

    @property
    def text(self):return ''.join(self.parts)

    def __iter__(self):return iter(self.children)

    def findall(self,path,namespaces):
        if path.startswith('.//'):
            wanted=self._tag(path[3:],namespaces)
            result=[]
            def visit(node):
                for child in node.children:
                    if child.name==wanted:result.append(child)
                    visit(child)
            visit(self)
            return result
        nodes=[self]
        for part in path.split('/'):
            wanted=self._tag(part,namespaces)
            nodes=[child for node in nodes for child in node.children if child.name==wanted]
        return nodes

    iterfind=findall

    def find(self,path,namespaces):
        values=self.findall(path,namespaces)
        return values[0] if values else None

    @staticmethod
    def _tag(value,namespaces):
        if ':' not in value:return value
        prefix,local=value.split(':',1)
        return '{'+namespaces[prefix]+'}'+local


def fromstring(raw):
    parser=expat.ParserCreate(namespace_separator='}')
    stack=[];roots=[];count=0
    def reject(*_):raise ValueError('不支持DTD或自定义实体的XML模板')
    def start(name,attributes):
        nonlocal count
        count+=1
        if len(stack)>=100 or count>1000000:
            raise ValueError('模板XML层级或节点数量超过限制')
        node=Element(name,attributes)
        if stack:stack[-1].children.append(node)
        else:roots.append(node)
        stack.append(node)
    def end(_):stack.pop()
    def text(value):
        if stack:stack[-1].parts.append(value)
    parser.StartElementHandler=start
    parser.EndElementHandler=end
    parser.CharacterDataHandler=text
    parser.StartDoctypeDeclHandler=reject
    parser.EntityDeclHandler=reject
    parser.ExternalEntityRefHandler=reject
    try:parser.Parse(raw,True)
    except expat.ExpatError as error:raise ValueError('模板XML损坏：'+str(error)) from None
    if len(roots)!=1:raise ValueError('模板XML缺少唯一根节点')
    return roots[0]
