"""Independent browser profiles and a read-only bridge, never the default profile."""
import hashlib
import importlib.util
import os
from pathlib import Path
import queue
import shutil
import tempfile
import threading
import time
import uuid
from urllib.parse import urlparse
from browser_preferences import reserve_browser, release_browser, region_from_url

_lock = threading.Lock()
_external = {}
_channels = {}
_auto = {}
_auto_enabled = True
_company_auto = {}
AUTO_INTERVAL = 30


def identity_key(company):
    value = '|'.join(str(company.get(k, '')).strip().casefold() for k in ('region', 'tax_id', 'username'))
    return hashlib.sha256(value.encode()).hexdigest()


def profile_directory(base):
    parent = Path(base) / 'browser-sessions'
    parent.mkdir(parents=True, exist_ok=True)
    return Path(tempfile.mkdtemp(prefix='isolated-', dir=parent))


def launch_context(playwright, directory, headless=False, browser='msedge', executable=None):
    options={'executable_path':executable} if executable else {}
    return playwright.chromium.launch_persistent_context(
        user_data_dir=str(directory), channel=browser, headless=headless,
        no_viewport=True, locale='zh-CN', ignore_https_errors=False,
        timeout=30000,
        chromium_sandbox=True, ignore_default_args=['--no-sandbox'],
        args=['--start-maximized'], **options)


def is_tax_site(url):
    from official_links import _PROVINCES
    host = (urlparse(url).hostname or '').lower()
    return any(host == code + '.chinatax.gov.cn' or host.endswith('.' + code + '.chinatax.gov.cn')
               for code in _PROVINCES.values())


def login_entry(company, defaults):
    """Reject a province mismatch; business deep links are not login entries."""
    from official_links import _PROVINCES
    from region_portals import official_url
    url = str(company.get('tax_url', '')).strip()
    if not official_url(url):
        raise ValueError('登录入口必须是税务机关官方HTTPS网址，请在地区网址管理中重新选择。')
    host = (urlparse(url).hostname or '').lower()
    region = company.get('region', '')
    for name, code in _PROVINCES.items():
        suffix = code + '.chinatax.gov.cn'
        if (host == suffix or host.endswith('.' + suffix)) and name != region:
            raise ValueError(f'企业地区是{region}，链接却属于{name}，请先修正地区或入口，避免登录错地区。')
    if host.startswith('dppt.') or '/digital-tax-account' in urlparse(url).path:
        if not defaults.get(region):
            raise ValueError('当前链接是税务数字账户业务页，不是登录入口；请先配置当地电子税务局入口。')
        return defaults[region]
    return url


def external_count():
    with _lock:
        return len(_external)


def open_isolated(url, on_error=None):
    if importlib.util.find_spec('playwright') is None:
        raise RuntimeError('缺少独立浏览器组件，请使用完整安装版；不会退回共用登录状态的普通窗口。')
    session_id = uuid.uuid4().hex
    choice = reserve_browser(region_from_url(url),session_id)
    def work():
        directory = None
        try:
            from playwright.sync_api import sync_playwright
            base = Path(os.environ.get('LOCALAPPDATA', Path.home())) / 'ShenzhenTaxLoginManager'
            directory = profile_directory(base)
            with sync_playwright() as p:
                context = launch_context(p, directory, browser=choice['channel'], executable=choice['path'])
                page = context.pages[0] if context.pages else context.new_page()
                try:
                    page.goto(url, wait_until='domcontentloaded', timeout=45000)
                except Exception as error:
                    # Keep the error page available; never silently reuse the default browser.
                    if on_error: on_error('独立窗口已打开，但网站加载失败：' + str(error)[:250])
                while True:
                    pages = [x for x in context.pages if not x.is_closed()]
                    if not pages: break
                    try: pages[-1].wait_for_timeout(100)
                    except Exception:
                        if not context.pages: break
        except Exception as error:
            if on_error: on_error('无法打开隔离浏览器：' + str(error)[:250])
        finally:
            if directory: shutil.rmtree(directory, ignore_errors=True)
            with _lock: _external.pop(session_id, None)
            release_browser(session_id)
    worker = threading.Thread(target=work, daemon=True)
    with _lock: _external[session_id] = worker
    try: worker.start()
    except Exception:
        with _lock: _external.pop(session_id, None)
        release_browser(session_id)
        raise
    return session_id


def register_bridge(session_id, company):
    with _lock:
        _channels[session_id] = (identity_key(company), queue.Queue())
        from tax_status import status_company
        if status_company(company):
            _auto[session_id]={'company':{k:company.get(k,'') for k in ('internal_code','region','name','tax_id')},
                               'last_tick':None,'attempted_at':'','synced_at':'','error':'','phase':'等待企业登录'}


def unregister_bridge(session_id):
    with _lock:
        channel = _channels.pop(session_id, None)
        _auto.pop(session_id,None)
    if channel:
        while True:
            try: channel[1].get_nowait()[1].put({'error':'登录会话已结束，请重新登录。'})
            except queue.Empty: break


def request_snapshot(company):
    response = queue.Queue()
    with _lock:
        channel = next((q for key, q in _channels.values() if key == identity_key(company)), None)
        if channel is None: raise RuntimeError('该企业尚无客户端管理的登录会话，请先点击“登录所选企业”。')
        channel.put((company.copy(), response))
    return response


def drain_readonly(session_id, context):
    with _lock: channel = _channels.get(session_id)
    if not channel: return
    while True:
        try: company, response = channel[1].get_nowait()
        except queue.Empty: break
        try:
            from tax_status import capture_context
            from status_store import save_status
            value=save_status(company,capture_context(context,company))
            _set_auto_result(session_id,value=value)
            response.put(value)
        except Exception as error: response.put({'error':str(error)})
    _poll_auto(session_id,context)


def set_auto_sync(enabled,company=None):
    global _auto_enabled
    with _lock:
        if company is None:
            _auto_enabled=bool(enabled);_company_auto.clear()
        else:_company_auto[identity_key(company)]=bool(enabled)
        for sid,state in _auto.items():
            if company is None or _channels[sid][0]==identity_key(company):state['last_tick']=None


def auto_sync_state(company):
    with _lock:
        states=[x for key,x in _auto.items() if _channels.get(key,(None,))[0]==identity_key(company)]
        state=states[0] if states else {}
        return {k:state.get(k,'') for k in ('phase','attempted_at','synced_at','error')} | {
            'active':bool(states),'enabled':_auto_enabled and _company_auto.get(identity_key(company),True),'interval':AUTO_INTERVAL}


def _set_auto_result(session_id,value=None,error=None):
    from datetime import datetime
    with _lock:
        state=_auto.get(session_id)
        if state is None:return
        state['last_tick']=time.monotonic()
        state['attempted_at']=datetime.now().isoformat(timespec='seconds')
        if value:
            state.update(synced_at=value['synced_at'],error='',phase='自动读取已完成')
        else:
            state.update(error=str(error),phase='自动读取暂停，等待页面或身份核对')


def _poll_auto(session_id,context):
    # This runs on the owning Playwright thread, not a Tk timer/new browser.
    with _lock:
        state=_auto.get(session_id)
        if not _auto_enabled or not state or not _company_auto.get(_channels[session_id][0],True):return
        now=time.monotonic()
        if state['last_tick'] is not None and now-state['last_tick']<AUTO_INTERVAL:return
        state['last_tick']=now
        company=state['company'].copy()
    try:
        from tax_status import capture_context
        from status_store import save_status
        _set_auto_result(session_id,value=save_status(company,capture_context(context,company)))
    except Exception as error:
        # No modal, retries/login loops, cookie export, navigation or payment.
        _set_auto_result(session_id,error=error)
