"""Local-only invoice import/preflight. No tax submission or mail transport."""
from copy import deepcopy
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import invoice_xml as ET
import zipfile

NS = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
REL = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
CENT = Decimal('0.01')
MAX_ROWS = 20000


def _text(value):
    if value is None:
        return ''
    return str(value).strip()


def _xml(packed, name):
    raw = packed.read(name)
    if b'<!DOCTYPE' in raw or b'<!ENTITY' in raw:
        raise ValueError('不支持含外部实体的模板')
    return ET.fromstring(raw)


def read_template(path):
    """Read bounded OOXML without Excel/Python third-party dependencies.

    Formula and error cells are rejected, never silently replaced by caches.
    Auxiliary lookup/validation sheets remain in the untouched source file.
    """
    path = Path(path)
    if path.suffix.lower() != '.xlsx':
        raise ValueError('开票试点仅支持税局原版 .xlsx 模板，不支持改扩展名的文件')
    raw = path.read_bytes()
    if len(raw) > 30 * 1024 * 1024:
        raise ValueError('模板超过30MB，请拆分后导入')
    import io
    with zipfile.ZipFile(io.BytesIO(raw)) as packed:
        infos = packed.infolist()
        if len(infos) > 10000 or sum(x.file_size for x in infos) > 120 * 1024 * 1024:
            raise ValueError('模板解压大小超出限制')
        strings = []
        if 'xl/sharedStrings.xml' in packed.namelist():
            strings = [''.join(t.text or '' for t in item.iterfind('.//s:t', NS))
                       for item in _xml(packed, 'xl/sharedStrings.xml')]
        links = {x.attrib['Id']: x.attrib['Target']
                 for x in _xml(packed, 'xl/_rels/workbook.xml.rels')
                 if x.attrib.get('TargetMode') != 'External'}
        sheets = {}
        for sheet in _xml(packed, 'xl/workbook.xml').findall('s:sheets/s:sheet', NS):
            name = sheet.attrib['name']
            if not any(token in name for token in ('发票基本信息', '发票明细信息', '特定业务信息', '附加要素信息')):
                continue
            target = links.get(sheet.attrib[REL], '')
            part = target.lstrip('/') if target.startswith('/') else 'xl/' + target
            if '..' in PurePosixPath(part).parts or not part.startswith('xl/'):
                raise ValueError('模板包含不支持的工作表路径')
            rows = []
            for row in _xml(packed, part).findall('s:sheetData/s:row', NS):
                number = int(row.attrib['r'])
                if number > MAX_ROWS + 10:
                    raise ValueError('模板行数超过20000行，请拆分批次')
                values = {}
                for cell in row.findall('s:c', NS):
                    ref = cell.attrib['r']
                    if cell.find('s:f', NS) is not None or cell.attrib.get('t') == 'e':
                        raise ValueError(f'{name}!{ref} 包含公式或错误值，请先在副本中转为确定值')
                    v = cell.find('s:v', NS)
                    value = v.text if v is not None else ''
                    if cell.attrib.get('t') == 's':
                        value = strings[int(value)]
                    elif cell.attrib.get('t') == 'inlineStr':
                        value = ''.join(x.text or '' for x in cell.findall('.//s:t', NS))
                    if _text(value):
                        values[re.sub(r'\d', '', ref)] = _text(value)
                if values:
                    rows.append((number, values))
            sheets[name] = rows
    return sheets, hashlib.sha256(raw).hexdigest()


def _records(sheets, token, required):
    candidates = [name for name in sheets if token in name]
    if len(candidates) != 1:
        raise ValueError(f'需要且只能有一张“{token}”工作表')
    name = candidates[0]
    for number, cells in sheets[name]:
        if number > 10:
            break
        headings = {key: value.replace('\n', '').strip() for key, value in cells.items()}
        if set(required).issubset(headings.values()):
            data = []
            for rownum, row in sheets[name]:
                if rownum > number:
                    data.append({'_sheet': name, '_row': rownum,
                                 **{title: row.get(col, '') for col, title in headings.items()}})
            return data
    raise ValueError(f'{name} 未识别到列：' + '、'.join(required))


def _number(value, label, optional=False):
    value = _text(value)
    if not value and optional:
        return None
    try:
        result = Decimal(value)
        if not result.is_finite() or abs(result) > Decimal('1e16'):
            raise InvalidOperation
        return result
    except InvalidOperation:
        raise ValueError(f'{label}必须是有限数值') from None


def _money(value):
    return str(value.quantize(CENT, rounding=ROUND_HALF_UP))


def analyze_records(basics, details, test_mode=True):
    """Use template meanings only. Preflight is not tax-authority approval."""
    basics, details = deepcopy(basics), deepcopy(details)
    issues, invoices, by_id = [], [], {}

    def issue(record, message, severity='错误'):
        issues.append({'severity': severity, 'invoice_id': record.get('发票流水号', ''),
                       'location': f"{record.get('_sheet', '')} 第{record.get('_row', '?')}行",
                       'message': message})

    for index, record in enumerate(basics, 1):
        flow = _text(record.get('发票流水号'))
        if not flow or flow in by_id:
            issue(record, '发票流水号缺失或基本信息重复，不能确定发票分组')
            continue
        if len(flow) > 80:
            issue(record, '发票流水号过长')
        if record.get('发票类型') != '增值税专用发票':
            issue(record, '当前00PZ试点只处理“增值税专用发票”')
        if record.get('特定业务类型'):
            issue(record, '特定业务尚未适配，不能按普通蓝字流程处理')
        if record.get('是否含税') not in ('是', '否'):
            issue(record, '是否含税必须明确填写“是”或“否”')
        if not record.get('购买方名称'):
            issue(record, '缺少购买方名称')
        tax_id = _text(record.get('购买方纳税人识别号'))
        simulated = False
        if not tax_id and test_mode:
            tax_id = f'91110000{index:09d}X'
            simulated = True
            issue(record, '缺失购方税号已在内存中补为模拟值，仅供本地测试', '提示')
        elif not tax_id:
            issue(record, '缺少购买方纳税人识别号')
        if tax_id and not re.fullmatch(r'[0-9A-Z]{15,20}', tax_id):
            issue(record, '购方税号基础格式异常（仅检查15—20位大写字母或数字，不核验真实性）')
        email = _text(record.get('购买方邮箱'))
        if not email:
            issue(record, '未填写收件邮箱，后续不能邮件交付', '提醒')
        elif len(email) > 254 or not re.fullmatch(r'[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+', email):
            issue(record, '收件邮箱格式异常，请填写一个明确的收件地址')
        invoice = {'invoice_id': flow, 'buyer': record.get('购买方名称', ''),
                   'buyer_tax_id': tax_id, 'simulated_tax_id': simulated, 'email': email,
                   'inclusive': record.get('是否含税') == '是', 'lines': [],
                   'source_row': record.get('_row'), 'source': record}
        invoices.append(invoice)
        by_id[flow] = invoice
    for record in details:
        flow = _text(record.get('发票流水号'))
        invoice = by_id.get(flow)
        if not invoice:
            issue(record, '明细流水号在基本信息中不存在')
            continue
        try:
            if not record.get('项目名称'):
                raise ValueError('缺少项目名称')
            if not re.fullmatch(r'\d{19}', record.get('商品和服务税收编码', '')):
                raise ValueError('商品和服务税收编码需为19位数字；适用性仍需人工核实')
            if any(record.get(key) for key in ('折扣金额', '优惠政策类型', '即征即退类型', '煤炭种类')) or record.get('是否使用优惠政策', '') not in ('', '否'):
                raise ValueError('折扣、优惠或特殊业务暂未适配，不能静默忽略')
            amount = _number(record.get('金额'), '金额')
            rate = _number(record.get('税率'), '税率')
            if amount <= 0 or amount != amount.quantize(CENT) or not 0 <= rate <= 1:
                raise ValueError('蓝字金额须大于0且最多两位小数，税率须用0至1的小数填写')
            qty = _number(record.get('数量'), '数量', True)
            price = _number(record.get('单价'), '单价', True)
            if qty is not None and qty <= 0 or price is not None and price < 0:
                raise ValueError('蓝字数量须大于0、单价不得为负数')
            if price is not None and qty is None:
                raise ValueError('填写单价时也需填写数量')
            if price is not None and (qty * price).quantize(CENT, rounding=ROUND_HALF_UP) != amount:
                raise ValueError('数量×单价与金额不一致（按分四舍五入）')
            if invoice['inclusive']:
                net = (amount / (1 + rate)).quantize(CENT, rounding=ROUND_HALF_UP)
                tax = amount - net
                gross = amount
            else:
                net = amount
                tax = (net * rate).quantize(CENT, rounding=ROUND_HALF_UP)
                gross = net + tax
            invoice['lines'].append({'item': record.get('项目名称'),
                                     'code': record.get('商品和服务税收编码'),
                                     'quantity': str(qty) if qty is not None else '',
                                     'unit_price': str(price) if price is not None else '',
                                     'rate': str(rate), 'amount': _money(amount),
                                     'net': _money(net), 'tax': _money(tax), 'gross': _money(gross),
                                     'source_row': record.get('_row')})
        except (ValueError, InvalidOperation) as error:
            issue(record, str(error))
    for invoice in invoices:
        if not invoice['lines']:
            issue(invoice['source'], '没有可用的发票明细')
        for key in ('net', 'tax', 'gross'):
            invoice[key] = _money(sum((Decimal(x[key]) for x in invoice['lines']), Decimal(0)))
        invoice['status'] = '待修正' if any(x['severity'] == '错误' and x['invoice_id'] == invoice['invoice_id'] for x in issues) else '本地校验通过'
        del invoice['source']
    errors = sum(x['severity'] == '错误' for x in issues)
    return {'schema': 1, 'company_code': '00PZ', 'region': '北京',
            'mode': '本地模拟' if test_mode else '本地预检', 'test_mode': bool(test_mode),
            'submission_enabled': False, 'delivery_enabled': False,
            'notice': '本地计算预览，不是税局开票结果。模拟数据禁止提交税局或发送邮件。税额以税局核算为准。',
            'invoices': invoices, 'issues': issues, 'error_count': errors,
            'invoice_count': len(invoices),
            'gross_total': _money(sum((Decimal(x['gross']) for x in invoices), Decimal(0))),
            'preview_complete': not errors and bool(invoices)}


def load_batch(path, test_mode=True):
    sheets, digest = read_template(path)
    basics = _records(sheets, '发票基本信息', ('发票流水号', '发票类型', '是否含税', '购买方名称', '购买方纳税人识别号', '购买方邮箱'))
    details = _records(sheets, '发票明细信息', ('发票流水号', '项目名称', '商品和服务税收编码', '金额', '税率'))
    batch = analyze_records(basics, details, test_mode)
    if not basics:
        raise ValueError('模板没有发票基本信息，请在表头下面填写数据')
    for name, rows in sheets.items():
        if any(token in name for token in ('特定业务信息', '附加要素信息')) and any(number > 3 for number, _ in rows):
            batch['issues'].append({'severity': '错误', 'invoice_id': '', 'location': name,
                                    'message': '此表存在附加业务数据，当前试点不支持，不能忽略后继续'})
            batch['error_count'] += 1
            batch['preview_complete'] = False
    batch.update(source_name=Path(path).name, source_sha256=digest,
                 analyzed_at=datetime.now(timezone.utc).isoformat(),
                 batch_id=hashlib.sha256((digest + '|00PZ|' + batch['mode']).encode()).hexdigest())
    return batch


def save_preview(batch, destination):
    """Save a local review snapshot, never a tax-uploadable invoice workbook."""
    target = Path(destination)
    if target.suffix.lower() != '.json':
        raise ValueError('本地预览仅导出为JSON，不生成可上传的模拟开票模板')
    target.write_text(json.dumps(batch, ensure_ascii=False, indent=2), encoding='utf-8')
