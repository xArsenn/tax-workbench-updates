"""Local tax risk checks for the workbench."""
from datetime import date
import tkinter as tk
from tkinter import ttk


def risk_findings(companies, login_entry, defaults):
    findings = []
    codes = set()
    for company in companies:
        name = company.get('name', '')
        tax_id = company.get('tax_id', '').strip().upper()
        if not tax_id or tax_id in codes:
            findings.append((name, '税号缺失或重复', '请核对企业档案'))
        codes.add(tax_id)
        try:
            login_entry(company, defaults)
        except ValueError:
            findings.append((name, '申报入口待核对', '请核对税局地区和登录网址'))
        deadline = company.get('filing_deadline', '')
        if deadline and company.get('filing_status') == '未报税':
            try:
                days = (date.fromisoformat(deadline) - date.today()).days
            except ValueError:
                findings.append((name, '申报期限格式待核对', deadline))
                continue
            if days < 0:
                findings.append((name, '超过本机登记的申报期限', deadline))
            elif days <= 7:
                findings.append((name, '申报期限临近', f'{deadline}（剩余 {days} 天）'))
    return findings


def open_risk_center(app, login_entry):
    from workspace_modules import _window
    win = _window(app, '税务风险预警', '税号、地区网址和本机登记的申报期限', '940x620')
    tree = ttk.Treeview(win, columns=('company', 'check', 'detail'), show='headings')
    for key, title in zip(tree['columns'], ('企业', '检查结果', '处理提示')):
        tree.heading(key, text=title)
    tree.pack(fill='both', expand=True, padx=20, pady=12)
    summary = tk.StringVar(win)

    def refresh():
        findings = risk_findings(app.companies, login_entry, app.region_url_map())
        tree.delete(*tree.get_children())
        for row in findings:
            tree.insert('', 'end', values=row)
        summary.set(f'检查了 {len(app.companies)} 家企业，发现 {len(findings)} 条待核对事项。')

    ttk.Label(win, textvariable=summary).pack(side='left', padx=20, pady=12)
    ttk.Button(win, text='重新检查', command=refresh).pack(side='right', padx=20, pady=12)
    refresh()
