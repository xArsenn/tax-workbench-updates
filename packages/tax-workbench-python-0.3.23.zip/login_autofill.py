"""Fill a recognized enterprise login form on the selected region's official site."""
from urllib.parse import urlsplit

from official_links import _PROVINCES


def request_login_sms(page, region):
    """Click the official SMS request control once when the SMS form is ready."""
    if not allowed_login_origin(page.url, region) or not urlsplit(page.url).hostname.startswith('tpass.'):
        return False
    for frame in page.frames:
        if not allowed_login_origin(frame.url, region):
            continue
        field = frame.locator('input[placeholder*="短信验证码"]:visible:enabled')
        if field.count() != 1 or field.input_value(timeout=400):
            continue
        controls = frame.get_by_text('获取验证码', exact=True).filter(visible=True)
        if not controls.count():
            controls = frame.get_by_text('发送验证码', exact=True).filter(visible=True)
        if controls.count() != 1 or not controls.is_enabled():
            continue
        if controls.evaluate("(node) => Boolean(node.closest('[disabled], [aria-disabled=true]'))", timeout=400):
            continue
        if not allowed_login_origin(page.url, region) or not allowed_login_origin(frame.url, region):
            return False
        try:
            controls.click(timeout=700, no_wait_after=True)
        except Exception:
            return 'uncertain'
        return True
    return False


def allowed_login_origin(url, region):
    try:
        parts = urlsplit(url)
        code = _PROVINCES.get(region)
        return bool(code and parts.scheme == 'https' and parts.username is None
                    and parts.password is None and parts.port in (None, 443, 8443)
                    and parts.hostname in {f'{prefix}.{code}.chinatax.gov.cn'
                                           for prefix in ('etax', 'tpass')})
    except ValueError:
        return False


SELECTORS = (
    'input[placeholder*="统一社会信用代码"], input[placeholder*="纳税人识别号"], input[aria-label*="纳税人识别号"]',
    'input[placeholder*="居民身份证号码"], input[placeholder*="手机号"], input[placeholder*="用户名"]',
    'input[type="password"][placeholder*="密码"], input[type="password"][aria-label*="密码"]',
)


def fill_enterprise_form(page, region, values, *, submit=False):
    """Return True for prefill, or 'submitted' after clicking the matching form."""
    if not all(values) or not allowed_login_origin(page.url, region):
        return False
    for frame in page.frames:
        if not allowed_login_origin(frame.url, region):
            continue
        fields = []
        for selector in SELECTORS:
            controls = frame.locator(', '.join(s + ':visible:enabled:not([readonly])'
                                               for s in selector.split(', ')))
            if controls.count() != 1:
                break
            fields.append(controls.element_handle(timeout=800))
        if len(fields) != len(values):
            continue
        current = [field.input_value(timeout=800) for field in fields]
        if any(old and old != new for old, new in zip(current, values)):
            continue
        for field, old, new in zip(fields, current, values):
            if not allowed_login_origin(page.url, region) or not allowed_login_origin(frame.url, region):
                return False
            if not old:
                field.fill(new, timeout=1400)
        if (submit and allowed_login_origin(page.url, region) and allowed_login_origin(frame.url, region)
                and all(field.input_value(timeout=800) == value for field, value in zip(fields, values))):
            button = frame.get_by_role('button', name='登录', exact=True).filter(visible=True)
            if button.count() == 1 and button.is_enabled():
                try:
                    button.click(timeout=1600, no_wait_after=True)
                except Exception:
                    # A redirect or challenge can start while the click returns. Do not retry.
                    return True
                return 'submitted'
        return True
    return False
