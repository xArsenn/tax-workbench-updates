"""Local staff register, separate from login credentials and portal permissions."""
import json
import os
from pathlib import Path
import re
import tempfile
import unicodedata


def normalized(value):
    return unicodedata.normalize('NFKC', str(value or '')).strip()


def add_missing(records, companies, tax_ids, name):
    name = normalized(name)
    if not name or len(name) > 60 or any(ord(c) < 32 for c in name):
        raise ValueError('请输入办税员姓名。')
    code = lambda value: normalized(value).upper()
    known = {}
    for company in companies:
        key = code(company.get('tax_id'))
        known[key] = known.get(key, 0) + 1
    existing = {(code(row.get('tax_id')), normalized(row.get('name')))
                for row in records if row.get('role') == '办税员'}
    updated = list(records)
    result = {}
    for key in dict.fromkeys(tax_ids):
        if not re.fullmatch(r'[A-Z0-9]{18}', key):
            result[key] = '信用代码格式不符'
        elif not known.get(key):
            result[key] = '企业档案未匹配'
        elif known[key] != 1:
            result[key] = '企业档案重复，需核对'
        elif (key, name) in existing:
            result[key] = '已登记，跳过'
        else:
            updated.append({'tax_id': key, 'name': name, 'role': '办税员'})
            result[key] = '待补录'
    return updated, result


def load_staff(path):
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except FileNotFoundError:
        return []
    if not isinstance(data, list) or any(not isinstance(item, dict) for item in data):
        raise ValueError('本地办税员档案格式不正确，已停止操作。')
    return data


def save_staff(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=path.parent,
                                         delete=False) as file:
            temporary = Path(file.name)
            json.dump(rows, file, ensure_ascii=False, indent=2)
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def open_staff(parent, companies, path):
    import tkinter as tk
    from tkinter import ttk, messagebox
    from workspace_modules import _window

    if getattr(parent, '_staff_window', None) is not None and parent._staff_window.winfo_exists():
        parent._staff_window.lift()
        return parent._staff_window
    win = parent._staff_window = _window(parent, '办税员档案',
                                          '仅在本机登记 · 不变更电子税务局授权', '940x690')
    box = ttk.Frame(win, padding=12)
    box.pack(fill='both', expand=True)
    ttk.Label(box, text='办税员姓名').pack(anchor='w')
    name = ttk.Entry(box, width=30)
    name.pack(anchor='w', pady=(2, 8))
    ttk.Label(box, text='统一社会信用代码（可粘贴多个，以换行、空格或逗号分隔）').pack(anchor='w')
    codes = tk.Text(box, height=4)
    codes.pack(fill='x', pady=(2, 8))
    controls = ttk.Frame(box)
    controls.pack(fill='x')
    feedback = tk.StringVar(win, value='可先查看本地档案，或输入名单后点击预览。')
    ttk.Label(box, textvariable=feedback, wraplength=850).pack(anchor='w', pady=8)
    table_box = ttk.Frame(box)
    table_box.pack(fill='both', expand=True)
    tree = ttk.Treeview(table_box, columns=('company', 'code', 'staff', 'state'), show='headings')
    bar = ttk.Scrollbar(table_box, command=tree.yview)
    tree.configure(yscrollcommand=bar.set)
    bar.pack(side='right', fill='y')
    tree.pack(side='left', fill='both', expand=True)
    for col, label, width in zip(tree['columns'], ('企业', '信用代码', '办税员', '结果'), (330, 200, 90, 180)):
        tree.heading(col, text=label)
        tree.column(col, width=width)

    def paint(rows):
        tree.delete(*tree.get_children())
        company_names = {normalized(c.get('tax_id')).upper(): c.get('name', '') for c in companies}
        for key, staff, state in rows:
            tree.insert('', 'end', values=(company_names.get(key, '—'), key, staff, state))

    def show():
        try:
            rows = load_staff(path)
        except (OSError, ValueError) as exc:
            messagebox.showerror('无法读取档案', str(exc), parent=win)
            return
        paint((row.get('tax_id', ''), row.get('name', ''), '本地已登记')
              for row in rows if row.get('role') == '办税员')
        feedback.set(f'本地有 {sum(row.get("role") == "办税员" for row in rows)} 条办税员记录。')

    def process(commit):
        try:
            keys = [key for key in re.split(r'[\s,，;；]+', normalized(codes.get('1.0', 'end')).upper()) if key]
            if not keys:
                raise ValueError('请输入至少一个统一社会信用代码。')
            old = load_staff(path)
            updated, result = add_missing(old, companies, keys, name.get())
            if commit and len(updated) != len(old):
                save_staff(path, updated)
        except (OSError, ValueError) as exc:
            messagebox.showerror('办税员档案', str(exc), parent=win)
            return
        paint((key, normalized(name.get()), '已补录' if commit and state == '待补录' else state)
              for key, state in result.items())
        skipped = sum(state == '已登记，跳过' for state in result.values())
        pending = len(updated) - len(old)
        feedback.set(f'{"已补录" if commit else "待补录"} {pending} 家；已登记跳过 {skipped} 家；需核对 {len(result) - skipped - pending} 家。')

    ttk.Button(controls, text='查看本地档案', command=show).pack(side='left', padx=(0, 8))
    ttk.Button(controls, text='预览核对', command=lambda: process(False)).pack(side='left', padx=(0, 8))
    ttk.Button(controls, text='补录缺失', command=lambda: process(True)).pack(side='left')
    show()
    return win
