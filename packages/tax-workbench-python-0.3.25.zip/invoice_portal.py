"""Send a validated workbook to the visible tax portal's batch review page."""
from urllib.parse import urlsplit
import time


def _host(url):
    try:
        parsed = urlsplit(url)
        if parsed.scheme == 'https' and not parsed.username and not parsed.password and parsed.port in (None, 443, 8443):
            return parsed.hostname
    except ValueError:
        pass
    return None


class InvoiceImport:
    portal = 'etax.beijing.chinatax.gov.cn'
    invoice = 'dppt.beijing.chinatax.gov.cn'

    def __init__(self, tax_id, upload):
        self.tax_id = tax_id
        self.upload = upload
        self.authenticated = False
        self.clicked = set()
        self.finished = False
        self.next_check = 0

    def tick(self, pages, authenticated):
        now = time.monotonic()
        if self.finished or now < self.next_check:
            return None
        self.next_check = now + 0.6
        for page in reversed(pages):
            if page.is_closed():
                continue
            host = _host(page.url)
            if host == self.portal and authenticated(page, self.tax_id):
                self.authenticated = True
            if not self.authenticated or host not in (self.portal, self.invoice):
                continue
            for frame in page.frames:
                if _host(frame.url) != host:
                    continue
                if host == self.invoice:
                    batch_heading = frame.get_by_text('批量开具', exact=True).filter(visible=True)
                    if not batch_heading.count():
                        batch_heading = frame.get_by_text('批量开票', exact=True).filter(visible=True)
                    file_field = frame.locator('input[type=file]:not([multiple])')
                    path = urlsplit(frame.url).path.lower()
                    blue_entry = any(label == '蓝字发票开具' for _, label in self.clicked)
                    batch_page = (blue_entry or 'blue-invoice' in path) and (
                        'batch' in path or batch_heading.count() == 1)
                    if batch_page and file_field.count() == 1:
                        # Require an explicit file selection control before handing over the workbook.
                        select_file = frame.get_by_text('选择文件', exact=True).filter(visible=True)
                        if select_file.count() != 1:
                            continue
                        self.finished = True
                        try:
                            file_field.set_input_files(self.upload, timeout=2500)
                        except Exception:
                            return '未能确认文件是否已选中。请查看税局页面，确认后再操作。'
                        return '已选中开票模板。请查看税局导入结果；如页面要求点击上传，请先上传，再复核开票。'
                actions = (('蓝字发票开具', '发票业务', '开票业务', '发票使用', '我要办税')
                           if host == self.portal else ('批量开具', '批量开票', '蓝字发票开具'))
                for label in actions:
                    key = (host, label)
                    if key in self.clicked:
                        continue
                    item = frame.get_by_text(label, exact=True).filter(visible=True)
                    if item.count() == 1 and item.is_enabled():
                        try:
                            item.click(timeout=1400, no_wait_after=True)
                        except Exception:
                            continue
                        self.clicked.add(key)
                        return f'已点击「{label}」，正在等待税局下一页。'
        return None
