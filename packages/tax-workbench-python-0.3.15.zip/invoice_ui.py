"""Native invoice review workspace; live issuance deliberately unavailable."""
import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from apple_theme import C
from apple_widgets import AppleButton
from invoice_tasks import load_batch, save_preview


def open_invoice_tasks(parent, companies, login_callback):
    from workspace_modules import _window
    win = _window(parent, '开票任务', '00PZ 北京专票试点 · 本地导入与校验 · 未接通税局批导、开票和邮件交付', '1180x800')
    batch = [None]
    busy = [False]
    path = tk.StringVar(win, value='尚未选择税局开票模板（.xlsx）')
    summary = tk.StringVar(win, value='选择模板开始。模拟模式仅在内存中补缺失税号，原文件保持不变。')
    test_mode = tk.BooleanVar(win, value=True)
    # Reserve actions first so they remain visible on smaller desktop screens.
    footer = tk.Frame(win, bg=C('white'))
    footer.pack(side='bottom', fill='x', padx=24, pady=12)
    tk.Label(footer, text='未开票 · 未发送邮件', bg=C('white'), fg=C('muted')).pack(side='left', padx=8)
    bar = tk.Frame(win, bg=C('white'))
    bar.pack(fill='x', padx=24, pady=12)
    tk.Label(bar, text='开票企业：00PZ（北京）', bg=C('white'), fg=C('ink')).pack(anchor='w', padx=12, pady=6)
    row = tk.Frame(bar, bg=C('white'))
    row.pack(fill='x', padx=12, pady=8)
    tk.Label(row, textvariable=path, bg=C('white'), fg=C('muted'), anchor='w', wraplength=780).pack(side='left', fill='x', expand=True)
    tk.Label(win, textvariable=summary, bg=C('white'), fg=C('ink'), wraplength=1080, anchor='w', justify='left', padx=12, pady=10).pack(fill='x', padx=24)
    tabs = ttk.Notebook(win)
    tabs.pack(fill='both', expand=True, padx=24, pady=12)
    invoice_tab = tk.Frame(tabs, bg=C('white'))
    issue_tab = tk.Frame(tabs, bg=C('white'))
    tabs.add(invoice_tab, text='发票预览')
    tabs.add(issue_tab, text='校验明细')

    def make_table(frame, columns):
        tree = ttk.Treeview(frame, columns=[x[0] for x in columns], show='headings', height=5)
        for key, title, width in columns:
            tree.heading(key, text=title)
            tree.column(key, width=width, minwidth=80)
        tree.grid(row=0, column=0, sticky='nsew')
        y = ttk.Scrollbar(frame, command=tree.yview)
        y.grid(row=0, column=1, sticky='ns')
        x = ttk.Scrollbar(frame, orient='horizontal', command=tree.xview)
        x.grid(row=1, column=0, sticky='ew')
        tree.configure(yscrollcommand=y.set, xscrollcommand=x.set)
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)
        return tree

    top = tk.Frame(invoice_tab, bg=C('white'))
    top.pack(fill='both', expand=True)
    tree = make_table(top, (('invoice_id','流水号',110),('buyer','购买方',230),('buyer_tax_id','购方税号',180),
                            ('gross','价税合计（元）',130),('tax','税额（元）',110),('email','收件邮箱',200),('status','本地状态',110)))
    detail = tk.Text(invoice_tab, height=6, wrap='word', bg=C('white'), fg=C('ink'), relief='flat', state='disabled')
    detail.pack(fill='x', padx=8, pady=8)
    problems = make_table(issue_tab, (('severity','级别',75),('invoice_id','流水号',115),('location','位置',200),('message','说明',700)))

    def selected(_=None):
        text = '选择一张发票查看明细。价税拆分为本地估算，不代表税局核算或开票成功。'
        if batch[0] and tree.selection():
            invoice = batch[0]['invoices'][int(tree.selection()[0])]
            text = f"流水号：{invoice['invoice_id']}　{'含税金额' if invoice['inclusive'] else '不含税金额'}\n"
            if invoice['simulated_tax_id']:
                text += '购方税号为模拟值，禁止用于真实开票。\n'
            for item in invoice['lines']:
                text += f"{item['item']}　税率 {item['rate']}　不含税 {item['net']}　税额 {item['tax']}　价税合计 {item['gross']}\n"
            text += '税收编码、税率适用性和真实购方身份尚未由税局核验。'
        detail.configure(state='normal')
        detail.delete('1.0', 'end')
        detail.insert('1.0', text)
        detail.configure(state='disabled')
    tree.bind('<<TreeviewSelect>>', selected)
    selected()

    def reset_mode():
        batch[0] = None
        tree.delete(*tree.get_children())
        problems.delete(*problems.get_children())
        export_button.configure(state='disabled')
        summary.set('模式已切换，请重新选择模板校验。旧预览已清除，不会将模拟税号带入新模式。')
        selected()
    mode_button = ttk.Checkbutton(bar, text='本地模拟：仅在内存中补缺失税号，不提交税局、不发送邮件', variable=test_mode, command=reset_mode)
    mode_button.pack(anchor='w', padx=12, pady=(0,8))

    def choose():
        if busy[0]:
            return
        source = filedialog.askopenfilename(parent=win, title='选择税局开票模板（不修改原件）', filetypes=[('税局Excel模板', '*.xlsx')])
        if not source:
            return
        batch[0] = None
        tree.delete(*tree.get_children())
        problems.delete(*problems.get_children())
        selected()
        export_button.configure(state='disabled')
        path.set(source)
        summary.set('正在读取并校验模板，请稍候…')
        busy[0] = True
        import_button.configure(state='disabled')
        mode_button.configure(state='disabled')
        events = queue.Queue()
        mode = test_mode.get()
        def worker():
            try:
                events.put((True, load_batch(source, mode)))
            except Exception as error:
                events.put((False, str(error)))
        threading.Thread(target=worker, daemon=True).start()
        def poll():
            if not win.winfo_exists():
                return
            try:
                ok, value = events.get_nowait()
            except queue.Empty:
                win.after(100, poll)
                return
            busy[0] = False
            import_button.configure(state='normal')
            mode_button.configure(state='normal')
            if not ok:
                summary.set('导入失败：' + value)
                messagebox.showerror('模板导入失败', value, parent=win)
                return
            batch[0] = value
            for index, invoice in enumerate(value['invoices']):
                tree.insert('', 'end', iid=str(index), values=[invoice[key] for key in ('invoice_id','buyer','buyer_tax_id','gross','tax','email','status')])
            for error in value['issues']:
                problems.insert('', 'end', values=[error[key] for key in ('severity','invoice_id','location','message')])
            summary.set(f"{value['mode']}：识别 {value['invoice_count']} 张，当前有效明细价税合计 ¥{value['gross_total']}，错误 {value['error_count']} 项。"
                        + ('存在错误，金额可能不完整，请查看校验明细。' if value['error_count'] else '本地校验完成，尚未开票。')
                        + ' 原文件未修改；税局批量导入和邮件交付尚未接通。')
            export_button.configure(state='normal')
            if value['error_count']:
                tabs.select(issue_tab)
            else:
                tabs.select(invoice_tab)
            if tree.get_children():
                tree.selection_set('0')
                selected()
        poll()

    def export():
        if not batch[0]:
            messagebox.showinfo('没有可导出的预览', '请先导入开票模板。', parent=win)
            return
        destination = filedialog.asksaveasfilename(parent=win, title='导出本地预览（不是开票回执）',
                                                  initialfile='00PZ-本地开票预览.json', defaultextension='.json', filetypes=[('本地预览', '*.json')])
        if destination:
            try:
                save_preview(batch[0], destination)
                summary.set('已导出本地预览，不是开票回执，不能作为税局上传模板。未开票、未发送邮件。')
            except Exception as error:
                messagebox.showerror('导出失败', str(error), parent=win)

    def login():
        company = next((x for x in companies if x.get('internal_code') == '00PZ' and x.get('region') == '北京'), None)
        if company is None:
            messagebox.showwarning('未找到试点企业', '请先在企业档案中配置00PZ及北京地区。不会替换成其他企业登录。', parent=win)
            return
        login_callback(company)
    import_button = AppleButton(row, text='导入开票模板', command=choose, bg=C('primary'), fg='white')
    import_button.pack(side='right', padx=8)
    AppleButton(footer, text='手动登录00PZ税局', command=login).pack(side='right', padx=6)
    export_button = AppleButton(footer, text='导出本地预览', command=export, state='disabled')
    export_button.pack(side='right', padx=6)
    AppleButton(footer, text='正式开票未接通', state='disabled').pack(side='right', padx=6)
    return win
