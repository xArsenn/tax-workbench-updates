"""Batch additions to the workbench's existing company register."""
import re
import unicodedata
from uuid import uuid4


def canonical(value):
    return unicodedata.normalize('NFKC', str(value or '')).strip().upper()


def plan_import(text, companies, regions, region_urls):
    known = {canonical(company.get('tax_id')) for company in companies}
    codes = {canonical(company.get('internal_code')) for company in companies}
    additions, preview = [], []
    for number, line in enumerate(text.splitlines(), 1):
        if not line.strip():
            continue
        columns = [item.strip() for item in line.split('\t')]
        if columns[:2] in (['公司名称', '统一社会信用代码'], ['企业名称', '统一社会信用代码']):
            continue
        if len(columns) == 4 and columns[2] in ('小规模', '一般纳税人', '小规模纳税人'):
            columns.pop(2)
        if len(columns) not in (3, 4):
            preview.append((number, columns[0], '', '', '需核对：每行应有 3 或 4 列'))
            continue
        name, tax_id, region = columns[:3]
        if region == '昆山':
            region = '江苏'
        tax_id = canonical(tax_id)
        code = canonical(columns[3]) if len(columns) == 4 else ''
        if tax_id in known and tax_id:
            status = '已存在，跳过'
        elif not name or not re.fullmatch(r'[0-9A-HJ-NP-RTUWXY]{18}', tax_id) or region not in regions:
            status = '需核对：公司名称、信用代码或税局地区'
        elif code and code in codes:
            status = '需核对：内部代码已占用'
        else:
            if not code:
                base = 'E' + tax_id[-6:]
                code = base
                index = 2
                while code in codes:
                    code = f'{base}-{index}'
                    index += 1
            known.add(tax_id)
            codes.add(code)
            additions.append(dict(id=str(uuid4()), internal_code=code, name=name, tax_id=tax_id, region=region,
                                  tax_url=region_urls.get(region, ''), username='', password='', method='扫码登录',
                                  filing_status='未设置', tax_due='0.00', filing_deadline='', note=''))
            status = '待添加'
        preview.append((number, name, tax_id, region, status))
    return additions, preview


def open_company_import(app, regions, save):
    import tkinter as tk
    from tkinter import ttk, messagebox
    from workspace_modules import _window

    win = _window(app, '批量添加企业', '从表格复制企业资料，按统一社会信用代码跳过已有公司', '960x650')
    frame = ttk.Frame(win, padding=12)
    frame.pack(fill='both', expand=True)
    ttk.Label(frame, text='依次粘贴公司名称、统一社会信用代码、税局地区。第四列可填内部代码，留空自动生成。').pack(anchor='w')
    editor = tk.Text(frame, height=7)
    editor.pack(fill='x', pady=8)
    bar = ttk.Frame(frame)
    bar.pack(fill='x')
    feedback = tk.StringVar(win, value='先预览，再添加新公司。')
    ttk.Label(frame, textvariable=feedback).pack(anchor='w', pady=8)
    listing = ttk.Frame(frame)
    listing.pack(fill='both', expand=True)
    tree = ttk.Treeview(listing, columns=('row', 'name', 'tax_id', 'region', 'status'), show='headings')
    scroll = ttk.Scrollbar(listing, command=tree.yview)
    tree.configure(yscrollcommand=scroll.set)
    scroll.pack(side='right', fill='y')
    tree.pack(side='left', fill='both', expand=True)
    for column, title, width in zip(tree['columns'], ('行', '公司名称', '信用代码', '地区', '结果'), (40, 275, 185, 70, 260)):
        tree.heading(column, text=title)
        tree.column(column, width=width)

    def process(commit=False):
        additions, preview = plan_import(editor.get('1.0', 'end'), app.companies, regions, app.region_url_map())
        if commit and additions:
            combined = additions + app.companies
            try:
                save(combined)
            except OSError as error:
                messagebox.showerror('保存失败', str(error), parent=win)
                return
            app.companies[:] = combined
            app.refresh()
        tree.delete(*tree.get_children())
        for row in preview:
            tree.insert('', 'end', values=(*row[:-1], '已添加' if commit and row[-1] == '待添加' else row[-1]))
        skipped = sum(row[-1] == '已存在，跳过' for row in preview)
        feedback.set(f'{"已添加" if commit else "待添加"} {len(additions)} 家，已存在跳过 {skipped} 家，需核对 {len(preview)-len(additions)-skipped} 行。')

    ttk.Button(bar, text='预览核对', command=process).pack(side='left', padx=(0, 8))
    ttk.Button(bar, text='添加新公司', command=lambda: process(True)).pack(side='left')
    editor.focus_set()
    return win
