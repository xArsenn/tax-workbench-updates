"""Identity-bound local observations. No tax requests or inferred payment totals."""
from copy import deepcopy
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import threading
import uuid

from tax_status import pilot_company, clean

_lock=threading.RLock()


def app_dir():
    return Path(os.environ.get('LOCALAPPDATA',Path.home()))/'ShenzhenTaxLoginManager'


def status_path(directory=None):
    return Path(directory or app_dir())/'status-00XE.json'


def load_status(company,directory=None):
    if not pilot_company(company): return None
    with _lock:
        try:
            value=json.loads(status_path(directory).read_text(encoding='utf-8'))
            if not isinstance(value,dict):return None
            if (value.get('company') != company.get('internal_code') or
                value.get('tax_id') != clean(company.get('tax_id','')) or
                clean(value.get('company_name','')) != clean(company.get('name',''))):
                return None
            if not isinstance(value.get('records'),list): return None
            return value
        except (OSError,ValueError,TypeError):return None


def _groups(value):
    if isinstance(value.get('groups'),list) and value['groups']:
        return value['groups']
    # Preserve a pre-0.3.12 snapshot as history, not a fresh server observation.
    rows=value.get('records',[])
    if not rows:return []
    key=hashlib.sha256(('legacy|'+value.get('synced_at','')).encode()).hexdigest()
    return [{'key':key,'source':'旧版快照','kind':'旧版记录','records':rows,
             'observed_at':value.get('synced_at','')}]


def save_status(company,observation,directory=None):
    if not pilot_company(company):raise ValueError('仅支持00XE江苏试点')
    if (observation.get('company') != company.get('internal_code') or
        observation.get('tax_id') != clean(company.get('tax_id','')) or
        clean(observation.get('company_name','')) != clean(company.get('name',''))):
        raise ValueError('状态记录与企业身份不一致，不保存')
    with _lock:
        previous=load_status(company,directory) or {}
        old={g['key']:g for g in _groups(previous)}
        stamp=observation['synced_at']
        for group in _groups(observation):
            current=deepcopy(group)
            current['observed_at']=stamp
            for row in current['records']:row['observed_at']=stamp
            old[current['key']]=current
        # Bounded local history. Never mix periods or sum different page rows.
        groups=sorted(old.values(),key=lambda g:g.get('observed_at',''),reverse=True)[:60]
        result={**observation,'schema':2,'groups':groups,
                'records':[dict(row,kind=row.get('kind',g.get('kind','旧版记录')),
                                observed_at=row.get('observed_at',g.get('observed_at','')))
                           for g in groups for row in g['records']]}
        result['retention_notice']='合并本机各查询页的最近观察；每条时间独立，不代表当前全量申报或缴款状态。'
        target=status_path(directory)
        target.parent.mkdir(parents=True,exist_ok=True)
        temp=target.with_name(target.name+'.'+uuid.uuid4().hex+'.tmp')
        try:
            temp.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
            os.replace(temp,target)
        finally:
            if temp.exists():temp.unlink()
        return result


def dashboard_observation(company,directory=None):
    """Summary is scoped to observed tasks, never marks all tax filings complete."""
    value=load_status(company,directory)
    if not value:return None
    today=datetime.now().date().isoformat()
    rows=[r for r in value['records'] if r.get('kind')=='本期待办' and r.get('observed_at','').startswith(today)]
    if not rows:return None
    # Multiple homepage views are not added into company-level totals.
    latest=max(r.get('observed_at','') for r in rows)
    rows=[r for r in rows if r.get('observed_at')==latest]
    done=sum(r.get('declaration') in ('已申报','申报成功') for r in rows)
    return {'label':f'待办已申报{done}/{len(rows)}','time':latest,'due_label':'未汇总（见状态页）'}
