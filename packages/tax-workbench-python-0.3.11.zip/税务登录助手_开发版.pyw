if __name__ == '__main__':
    import os as _bootstrap_os
    if _bootstrap_os.environ.get('TAX_WORKBENCH_CHILD') != '1':
        import runpy as _bootstrap_runpy
        from pathlib import Path as _BootstrapPath
        _bootstrap_runpy.run_path(str(_BootstrapPath(__file__).with_name('startup_launcher.pyw')), run_name='__main__')
        raise SystemExit(0)

import base64
import ctypes
import json
import os
import shutil
import threading
import time
import tempfile
import uuid
from ctypes import wintypes
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, ttk
from urllib.parse import urlparse
from apple_widgets import AppleButton, RoundedPanel
from apple_theme import C, apply_typography
from update_core import current_version
from region_portals import portal_defaults
from branding import apply_app_icon, brand_photo
from filing_ui import open_archive, open_status
from invoice_ui import open_invoice_tasks
from browser_preferences import reserve_browser, release_browser, open_browser_settings
from browser_sessions import (identity_key, login_entry, profile_directory, launch_context,
                              external_count, register_bridge, unregister_bridge, drain_readonly)

from workspace_modules import (
    open_case_library,
    open_policy_library,
    open_practice_library,
    open_region_url_manager,
    open_report_center,
)


# Ask Windows for native per-monitor DPI rendering before Tk creates a window.
# This prevents bitmap stretching and blurry text on 125%/150%/4K displays.
if os.name == "nt":
    try:
        ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            pass


APP_DIR = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "ShenzhenTaxLoginManager"
DATA_FILE = APP_DIR / "companies.json"
REGION_URL_FILE = APP_DIR / "region_urls.json"
TAX_LOGIN_URL = "https://etax.shenzhen.chinatax.gov.cn:8443/"
REGIONS = ("北京", "天津", "河北", "山西", "内蒙古", "辽宁", "吉林", "黑龙江", "上海", "江苏", "浙江", "安徽", "福建", "江西", "山东", "河南", "湖北", "湖南", "广东", "深圳", "广西", "海南", "重庆", "四川", "贵州", "云南", "西藏", "陕西", "甘肃", "青海", "宁夏", "新疆", "大连", "宁波", "厦门", "青岛")
REGION_TAX_URLS = portal_defaults()


def infer_region(company: dict) -> str:
    name = company.get("name", "")
    tax_id = company.get("tax_id", "")
    if "深圳" in name or tax_id.startswith("914403"):
        return "深圳"
    markers = (("郑州", "河南"), ("成都", "四川"), ("西安", "陕西"), ("广州", "广东"), ("南京", "江苏"), ("昆山", "江苏"), ("漳州", "福建"), ("福建", "福建"), ("吉林", "吉林"), ("天津", "天津"), ("重庆", "重庆"), ("北京", "北京"))
    for marker, region in markers:
        if marker in name:
            return region
    prefixes = {"11": "北京", "12": "天津", "22": "吉林", "32": "江苏", "35": "福建", "41": "河南", "44": "广东", "50": "重庆", "51": "四川", "61": "陕西"}
    return prefixes.get(tax_id[2:4] if len(tax_id) >= 4 else "", "")


def asset_path(name: str) -> Path:
    local = Path(__file__).parent / "assets" / name
    if local.exists():
        return local
    return Path(__file__).parent.parent / "outputs" / "assets" / name
APP_DIR.mkdir(parents=True, exist_ok=True)


def normalize_url(value: str) -> str:
    """Validate without rewriting query strings or hash routes used by tax portals."""
    value = value.strip()
    if not value:
        return ""
    parsed = urlparse(value)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ValueError("报税网站链接需要以 http:// 或 https:// 开头。")
    return value


class DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]


def _blob(data: bytes):
    buffer = ctypes.create_string_buffer(data)
    return DATA_BLOB(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_byte))), buffer


def protect_text(text: str) -> str:
    """Use Windows DPAPI; only the current Windows user can decrypt it."""
    if not text:
        return ""
    source, keepalive = _blob(text.encode("utf-8"))
    result = DATA_BLOB()
    if not ctypes.windll.crypt32.CryptProtectData(
        ctypes.byref(source), None, None, None, None, 0, ctypes.byref(result)
    ):
        raise ctypes.WinError()
    try:
        raw = ctypes.string_at(result.pbData, result.cbData)
        return base64.b64encode(raw).decode("ascii")
    finally:
        ctypes.windll.kernel32.LocalFree(result.pbData)


def unprotect_text(value: str) -> str:
    if not value:
        return ""
    try:
        source, keepalive = _blob(base64.b64decode(value))
        result = DATA_BLOB()
        if not ctypes.windll.crypt32.CryptUnprotectData(
            ctypes.byref(source), None, None, None, None, 0, ctypes.byref(result)
        ):
            return ""
        try:
            return ctypes.string_at(result.pbData, result.cbData).decode("utf-8")
        finally:
            ctypes.windll.kernel32.LocalFree(result.pbData)
    except Exception:
        return ""


def load_companies() -> list[dict]:
    try:
        if not DATA_FILE.exists():
            return []
        value = json.loads(DATA_FILE.read_text(encoding="utf-8-sig"))
        if isinstance(value, list):
            companies = value
        # Be tolerant of older files that stored a single company as one object.
        if isinstance(value, dict) and value.get("id"):
            companies = [value]
        if not isinstance(value, (list, dict)):
            return []
        for company in companies:
            if not company.get("region"):
                company["region"] = infer_region(company)
            if not company.get("tax_url") and company.get("region") in REGION_TAX_URLS:
                company["tax_url"] = REGION_TAX_URLS[company["region"]]
            # 自动升级早期版本保存的江苏失效入口，不覆盖用户自行填写的网址。
            if company.get("tax_url", "").rstrip("/") == "https://etax.jiangsu.chinatax.gov.cn/sso/login":
                company["tax_url"] = REGION_TAX_URLS["江苏"]
            company.setdefault("filing_status", "未设置")
            company.setdefault("tax_due", "0.00")
            company.setdefault("filing_deadline", "")
        return companies
    except (OSError, json.JSONDecodeError):
        return []


def save_companies(companies: list[dict]) -> None:
    temporary = DATA_FILE.with_suffix(".tmp")
    temporary.write_text(json.dumps(companies, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(DATA_FILE)


def load_custom_region_urls() -> dict:
    try:
        value = json.loads(REGION_URL_FILE.read_text(encoding="utf-8-sig")) if REGION_URL_FILE.exists() else {}
        result={str(key): str(url) for key, url in value.items() if key in REGIONS and url}
        registry=APP_DIR/'region_urls_registry.json'
        if registry.is_file():
            for item in json.loads(registry.read_text(encoding='utf-8')):
                if item.get('login_url'):result[item['region']]=item['login_url']
        return result
    except (OSError, json.JSONDecodeError, AttributeError):
        return {}


def save_custom_region_urls(urls: dict) -> None:
    custom = {key: url for key, url in urls.items() if url and url!=REGION_TAX_URLS.get(key)}
    REGION_URL_FILE.write_text(json.dumps(custom, ensure_ascii=False, indent=2), encoding="utf-8")


class CompanyDialog(tk.Toplevel):
    METHODS = ("账号密码登录", "手机号登录", "个人用户登录", "扫码登录")
    FILING_STATUSES = ("未设置", "未报税", "已报税", "无需申报")

    def __init__(self, parent, company=None, region_urls=None):
        super().__init__(parent)
        self.result = None
        self.company = company
        self.region_urls = {**REGION_TAX_URLS, **(region_urls or {})}
        self.title("编辑公司" if company else "新增公司")
        self.after_idle(lambda: apply_typography(self) if self.winfo_exists() else None)
        self.geometry("760x900")
        self.resizable(False, False)
        self.configure(bg=C('parchment'))
        self.transient(parent)
        self.grab_set()

        heading = tk.Frame(self, bg=C('white'), height=72)
        heading.pack(fill="x"); heading.pack_propagate(False)
        tk.Label(heading, text="企业档案维护", bg=C('white'), fg=C('ink'),
                 font=("Microsoft YaHei UI", 15, "bold")).pack(anchor="w", padx=28, pady=(14, 2))
        tk.Label(heading, text="带 * 的项目为必填项，登录凭据将使用 Windows 密钥加密保存",
                 bg=C('white'), fg=C('muted'), font=("Microsoft YaHei UI", 8)).pack(anchor="w", padx=28)
        body = tk.Frame(self, bg="white", highlightbackground=C('hairline'), highlightthickness=1)
        body.pack(fill="both", expand=True, padx=18, pady=18)
        buttons = tk.Frame(body, bg="white")
        buttons.pack(side='bottom', fill='x', padx=24, pady=16)
        AppleButton(buttons, text="取消", bg=C('white'), command=self.destroy).pack(side='right',padx=(12,0))
        AppleButton(buttons, text="保存公司", command=self.save).pack(side='right')
        viewport=tk.Canvas(body,bg=C('white'),highlightthickness=0)
        bar=ttk.Scrollbar(body,orient='vertical',command=viewport.yview)
        bar.pack(side='right',fill='y')
        viewport.pack(fill='both',expand=True,padx=24,pady=16)
        viewport.configure(yscrollcommand=bar.set)
        form = tk.Frame(viewport, bg="white")
        form_window=viewport.create_window(0,0,window=form,anchor='nw')
        form.bind('<Configure>',lambda e:viewport.configure(scrollregion=viewport.bbox('all')))
        viewport.bind('<Configure>',lambda e:viewport.itemconfigure(form_window,width=e.width))
        viewport.bind('<MouseWheel>',lambda e:viewport.yview_scroll(int(-e.delta/120),'units'))
        self.values = {
            "internal_code": tk.StringVar(value=company.get("internal_code", "") if company else ""),
            "name": tk.StringVar(value=company.get("name", "") if company else ""),
            "tax_id": tk.StringVar(value=company.get("tax_id", "") if company else ""),
            "username": tk.StringVar(value=company.get("username", "") if company else ""),
            "method": tk.StringVar(value=company.get("method", self.METHODS[0]) if company else self.METHODS[0]),
            "password": tk.StringVar(value=unprotect_text(company.get("password", "")) if company else ""),
            "tax_url": tk.StringVar(value=company.get("tax_url", "") if company else ""),
            "region": tk.StringVar(value=company.get("region", "") if company else ""),
            "filing_status": tk.StringVar(value=company.get("filing_status", "未设置") if company else "未设置"),
            "tax_due": tk.StringVar(value=company.get("tax_due", "0.00") if company else "0.00"),
            "filing_deadline": tk.StringVar(value=company.get("filing_deadline", "") if company else ""),
        }
        fields = (
            ("内部代码 *", "internal_code"),
            ("公司名称 *", "name"),
            ("税号 / 统一社会信用代码 *", "tax_id"),
            ("登录用户名或手机号 *", "username"),
        )
        for row, (label, key) in enumerate(fields):
            ttk.Label(form, text=label).grid(row=row * 2, column=0, sticky="w", pady=(0 if row == 0 else 12, 5))
            ttk.Entry(form, textvariable=self.values[key], width=62).grid(row=row * 2 + 1, column=0, sticky="ew")

        ttk.Label(form, text="登录方式 *").grid(row=8, column=0, sticky="w", pady=(12, 5))
        ttk.Combobox(form, textvariable=self.values["method"], values=self.METHODS, state="readonly", width=59).grid(row=9, column=0, sticky="ew")
        location_labels = tk.Frame(form, bg="white")
        location_labels.grid(row=10, column=0, sticky="ew", pady=(14, 6))
        ttk.Label(location_labels, text="所属地区 *").pack(side="left")
        ttk.Label(location_labels, text="报税网站链接", padding=(112, 0, 0, 0)).pack(side="left")
        location_row = tk.Frame(form, bg="white")
        location_row.grid(row=11, column=0, sticky="ew")
        region_box = ttk.Combobox(location_row, textvariable=self.values["region"], values=REGIONS, state="readonly", width=12)
        region_box.pack(side="left")
        ttk.Entry(location_row, textvariable=self.values["tax_url"], width=45).pack(side="left", fill="x", expand=True, padx=(12, 0))
        region_box.bind("<<ComboboxSelected>>", self._region_changed)
        ttk.Label(form, text="选择地区后会自动带出网址；同一地区的公司共用该网址", foreground=C('muted')).grid(row=12, column=0, sticky="w", pady=(4, 0))

        tax_labels = tk.Frame(form, bg="white")
        tax_labels.grid(row=13, column=0, sticky="ew", pady=(12, 5))
        for column in range(3):
            tax_labels.columnconfigure(column, weight=1)
        ttk.Label(tax_labels, text="申报状态").grid(row=0, column=0, sticky="w")
        ttk.Label(tax_labels, text="应缴税额（元）").grid(row=0, column=1, sticky="w", padx=(12, 0))
        ttk.Label(tax_labels, text="申报期限（YYYY-MM-DD）").grid(row=0, column=2, sticky="w", padx=(12, 0))
        tax_row = tk.Frame(form, bg="white")
        tax_row.grid(row=14, column=0, sticky="ew")
        for column in range(3):
            tax_row.columnconfigure(column, weight=1)
        ttk.Combobox(tax_row, textvariable=self.values["filing_status"], values=self.FILING_STATUSES,
                     state="readonly", width=15).grid(row=0, column=0, sticky="ew")
        ttk.Entry(tax_row, textvariable=self.values["tax_due"], width=18).grid(row=0, column=1, sticky="ew", padx=(12, 0))
        ttk.Entry(tax_row, textvariable=self.values["filing_deadline"], width=22).grid(row=0, column=2, sticky="ew", padx=(12, 0))

        ttk.Label(form, text="登录密码 *").grid(row=15, column=0, sticky="w", pady=(12, 5))
        password_row = tk.Frame(form, bg="white")
        password_row.grid(row=16, column=0, sticky="ew")
        password_row.columnconfigure(0, weight=1)
        self.password_entry = ttk.Entry(password_row, textvariable=self.values["password"], show="●")
        self.password_entry.grid(row=0, column=0, sticky="ew")
        ttk.Button(password_row, text="显示", width=7, command=self.toggle_password).grid(row=0, column=1, padx=(8, 0))
        ttk.Label(form, text="备注").grid(row=17, column=0, sticky="w", pady=(12, 5))
        self.note = tk.Text(form, height=3, font=("Microsoft YaHei UI", 9), relief="solid", bd=1,
                            highlightbackground=C('hairline'), highlightthickness=1)
        self.note.grid(row=18, column=0, sticky="ew")
        if company:
            self.note.insert("1.0", company.get("note", ""))

        form.columnconfigure(0, weight=1)
        self.bind("<Escape>", lambda _event: self.destroy())
        self.bind("<Return>", lambda _event: self.save())
        self.after(50, lambda: self.focus_force())

    def toggle_password(self):
        self.password_entry.configure(show="" if self.password_entry.cget("show") else "●")

    def save(self):
        data = {key: value.get().strip() for key, value in self.values.items()}
        if not all(data[key] for key in ("internal_code", "name", "tax_id", "username", "password", "region")):
            messagebox.showwarning("提示", "请填写所有必填项。", parent=self)
            return
        data["tax_id"] = data["tax_id"].upper()
        try:
            amount = Decimal(data["tax_due"] or "0")
            if amount < 0:
                raise InvalidOperation
            data["tax_due"] = f"{amount.quantize(Decimal('0.01')):.2f}"
        except (InvalidOperation, ValueError):
            messagebox.showwarning("税额格式不正确", "应缴税额请输入大于或等于 0 的数字。", parent=self)
            return
        if data["filing_deadline"]:
            try:
                datetime.strptime(data["filing_deadline"], "%Y-%m-%d")
            except ValueError:
                messagebox.showwarning("日期格式不正确", "申报期限请使用 YYYY-MM-DD，例如 2026-10-20。", parent=self)
                return
        if data["tax_url"]:
            try:
                data["tax_url"] = normalize_url(data["tax_url"])
            except ValueError as error:
                messagebox.showwarning("网址格式不正确", str(error), parent=self)
                return
        data["note"] = self.note.get("1.0", "end").strip()
        data["password"] = protect_text(data["password"])
        data["id"] = self.company.get("id") if self.company else str(uuid.uuid4())
        self.result = data
        self.destroy()

    def _region_changed(self, _event=None):
        region = self.values["region"].get()
        preset = self.region_urls.get(region, "")
        if preset:
            self.values["tax_url"].set(preset)


class TaxManager(tk.Tk):
    def __init__(self):
        super().__init__()
        apply_app_icon(self)
        try:
            self.tk.call("tk", "scaling", self.winfo_fpixels("1i") / 72.0)
        except tk.TclError:
            pass
        self.title("")
        self.geometry("1540x920")
        self.minsize(980, 620)
        self.configure(bg=C('parchment'))
        self.companies = load_companies()
        self.region_urls = {**REGION_TAX_URLS, **load_custom_region_urls()}
        self.active_sessions = {}
        self.session_threads = {}
        self.session_identities = {}
        self.search_value = tk.StringVar()
        self.region_filter = tk.StringVar(value="全部地区")
        self.status_filter = tk.StringVar(value="全部状态")
        self.count_value = tk.StringVar()
        self.configured_value = tk.StringVar(value="0")
        self.unconfigured_value = tk.StringVar(value="0")
        self.session_value = tk.StringVar(value="0")
        self.filed_value = tk.StringVar(value="0")
        self.pending_value = tk.StringVar(value="0")
        self.tax_due_value = tk.StringVar(value="¥0.00")
        self.status_value = tk.StringVar(value="系统就绪")
        self.setup_style()
        self.build_ui()
        apply_typography(self)
        self.bind("<Configure>", self._on_window_resize)
        self.refresh()
        from update_ui import UpdateCenter
        from update_core import startup_ready
        self.updates = UpdateCenter(self)
        self.after_idle(startup_ready)
        self.after(1500, self._poll_session_count)

    def _poll_session_count(self):
        self.refresh_login_sessions()
        self.after(1500, self._poll_session_count)

    def setup_style(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TLabel", font=("Microsoft YaHei UI", 10), background=C('white'), foreground=C('secondary'))
        style.configure("TButton", font=("Microsoft YaHei UI", 10), padding=(14, 9), borderwidth=0)
        style.configure("Primary.TButton", foreground="white", background=C('parchment'), borderwidth=0)
        style.map("Primary.TButton", background=[("active", C('parchment'))])
        style.configure("Secondary.TButton", foreground=C('ink'), background=C('pearl'), borderwidth=1, relief="solid")
        style.map("Secondary.TButton", background=[("active", C('parchment'))])
        style.configure("Danger.TButton", foreground=C('ink'), background=C('parchment'), borderwidth=0)
        style.map("Danger.TButton", background=[("active", C('parchment'))])
        style.configure("Treeview", font=("Microsoft YaHei UI", 10), rowheight=48, background="white", fieldbackground="white", foreground=C('ink'), borderwidth=0)
        style.map("Treeview", background=[("selected", C('parchment'))], foreground=[("selected", C('ink'))])
        style.configure("Treeview.Heading", font=("Microsoft YaHei UI", 9, "bold"), padding=12, background=C('pearl'), foreground=C('ink'), relief="flat")
        style.map("Treeview.Heading", background=[("active", C('parchment'))])

    def build_ui(self):
        shell = tk.Frame(self, bg=C('parchment'))
        shell.pack(fill="both", expand=True)

        sidebar = tk.Frame(shell, bg=C('ink'), width=220)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)
        self.sidebar = sidebar
        logo = tk.Frame(sidebar, bg=C('ink'), height=102)
        logo.pack(fill="x"); logo.pack_propagate(False)
        tk.Label(logo, text="🔎", bg=C('parchment'), fg="white", width=2, height=1, font=("Segoe UI Emoji", 17, "bold")).pack(side="left", padx=(18, 10), pady=26)
        brand = tk.Frame(logo, bg=C('ink')); brand.pack(side="left", pady=24)
        tk.Label(brand, text="税务小侦探", bg=C('ink'), fg="white", font=("Microsoft YaHei UI", 13, "bold")).pack(anchor="w")
        tk.Label(brand, text="企业税务登录助手", bg=C('ink'), fg=C('parchment'), font=("Microsoft YaHei UI", 8)).pack(anchor="w", pady=(3, 0))
        nav = tk.Frame(sidebar, bg=C('ink'), height=48)
        nav.pack(fill="x", padx=14, pady=(14, 0)); nav.pack_propagate(False)
        tk.Label(nav, text="★   公司管理", bg=C('ink'), fg="white", font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w", padx=18, pady=14)
        safe = tk.Frame(sidebar, bg=C('ink'))
        safe.pack(side="bottom", fill="x", padx=14, pady=18)
        tk.Label(safe, text="🔒  秘密档案已加密", bg=C('ink'), fg="white", font=("Microsoft YaHei UI", 9, "bold")).pack(anchor="w", padx=13, pady=(12, 4))
        tk.Label(safe, text="账号密码只保存在本机，\n侦探也不会看到明文哦！", justify="left", bg=C('ink'), fg=C('parchment'), font=("Microsoft YaHei UI", 8)).pack(anchor="w", padx=13, pady=(0, 12))

        try:
            mascot = tk.PhotoImage(file=str(asset_path("detective_mascot.png"))).subsample(6, 6)
            self.mascot_image = mascot
            tk.Label(sidebar, image=mascot, bg=C('ink'), bd=0).pack(side="bottom", pady=(0, 8))
        except tk.TclError:
            pass

        content = tk.Frame(shell, bg=C('parchment'))
        content.pack(side="left", fill="both", expand=True)
        self.content = content
        header = tk.Frame(content, bg=C('parchment'), height=116)
        header.pack(fill="x", padx=32); header.pack_propagate(False)
        tk.Label(header, text="企业税务档案 📚", bg=C('parchment'), fg=C('ink'), font=("Microsoft YaHei UI", 22, "bold")).pack(anchor="w", pady=(25, 3))
        tk.Label(header, text="选择公司，自动打开对应地区税务局并填写登录资料", bg=C('parchment'), fg=C('ink'), font=("Microsoft YaHei UI", 10)).pack(anchor="w")
        add_button = AppleButton(header, text="＋  新增公司", command=self.add_company, bg=C('parchment'), fg="white", activebackground=C('parchment'), activeforeground="white", relief="flat", bd=0, cursor="hand2", font=("Microsoft YaHei UI", 10, "bold"), padx=18, pady=10)
        add_button.place(relx=1, x=0, y=31, anchor="ne")

        summary = tk.Frame(content, bg="white", highlightbackground=C('parchment'), highlightthickness=2)
        summary.pack(fill="x", padx=32, pady=(0, 16))
        tk.Label(summary, text="📁 企业档案", bg="white", fg=C('ink'), font=("Microsoft YaHei UI", 10, "bold")).pack(side="left", padx=(20, 10), pady=17)
        tk.Label(summary, textvariable=self.count_value, bg=C('parchment'), fg=C('ink'), font=("Microsoft YaHei UI", 9, "bold"), padx=10, pady=4).pack(side="left")
        search_box = tk.Frame(summary, bg=C('parchment'), highlightbackground=C('parchment'), highlightthickness=1)
        search_box.pack(side="right", padx=18, pady=11)
        tk.Label(search_box, text="🔍", bg=C('parchment'), fg=C('ink'), font=("Segoe UI Emoji", 12)).pack(side="left", padx=(10, 3))
        search = tk.Entry(search_box, textvariable=self.search_value, width=32, relief="flat", bd=0, bg=C('parchment'), fg=C('ink'), insertbackground=C('ink'), font=("Microsoft YaHei UI", 10))
        search.pack(side="left", padx=(0, 10), pady=8)
        self.search_entry = search
        self.search_value.trace_add("write", lambda *_: self.refresh())
        login_selected = AppleButton(
            summary,
            text="登录税务局  →",
            command=self.login_company,
            bg=C('parchment'),
            fg="white",
            activebackground=C('parchment'),
            activeforeground="white",
            relief="flat",
            bd=0,
            cursor="hand2",
            font=("Microsoft YaHei UI", 10, "bold"),
            padx=18,
            pady=8,
        )
        login_selected.pack(side="right", padx=(0, 10), pady=10)

        table_card = tk.Frame(content, bg="white", highlightbackground=C('parchment'), highlightthickness=2)
        table_card.pack(fill="both", expand=True, padx=32, pady=(0, 16))
        table_frame = tk.Frame(table_card, bg="white")
        table_frame.pack(fill="both", expand=True, padx=1, pady=1)
        columns = ("internal_code", "name", "region", "tax_id", "username", "method", "website", "password", "note")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")
        headings = {"internal_code": "内部代码", "name": "公司名称", "region": "地区", "tax_id": "税号 / 统一社会信用代码", "username": "登录账号", "method": "登录方式", "website": "报税网站", "password": "密码", "note": "备注"}
        widths = {"internal_code": 82, "name": 205, "region": 70, "tax_id": 175, "username": 120, "method": 110, "website": 95, "password": 75, "note": 110}
        for key in columns:
            self.tree.heading(key, text=headings[key])
            self.tree.column(key, width=widths[key], minwidth=80, stretch=key in ("name", "note"))
        self.tree.grid(row=0, column=0, sticky="nsew")
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        horizontal = ttk.Scrollbar(table_frame, orient="horizontal", command=self.tree.xview)
        horizontal.grid(row=1, column=0, sticky="ew")
        table_frame.rowconfigure(0, weight=1)
        table_frame.columnconfigure(0, weight=1)
        self.tree.configure(yscrollcommand=scrollbar.set, xscrollcommand=horizontal.set)
        self.tree.bind("<Double-1>", lambda _event: self.edit_company())
        self.tree.bind("<Button-3>", self.open_menu)

        self.menu = tk.Menu(self, tearoff=False, font=("Microsoft YaHei UI", 10))
        self.menu.add_command(label="登录税务局", command=self.login_company)
        self.menu.add_command(label="编辑公司", command=self.edit_company)
        self.menu.add_separator()
        self.menu.add_command(label="删除公司", command=self.delete_company)

        footer = tk.Frame(content, bg=C('parchment'))
        footer.pack(fill="x", padx=32, pady=(0, 22))
        tk.Label(footer, text="登录进度：", bg=C('parchment'), fg=C('ink'), font=("Microsoft YaHei UI", 9)).pack(side="left", pady=9)
        tk.Label(footer, textvariable=self.status_value, bg=C('parchment'), fg=C('parchment'), font=("Microsoft YaHei UI", 9, "bold")).pack(side="left", pady=9)
        ttk.Button(footer, text="删除", style="Danger.TButton", command=self.delete_company).pack(side="right", padx=(8, 0))
        ttk.Button(footer, text="编辑资料", style="Secondary.TButton", command=self.edit_company).pack(side="right", padx=(8, 0))

    def _on_window_resize(self, event):
        if event.widget is not self:
            return
        width = self.winfo_width()
        if width < 1050 and self.sidebar.winfo_manager():
            self.sidebar.pack_forget()
        elif width >= 1050 and not self.sidebar.winfo_manager():
            self.sidebar.pack(side="left", fill="y", before=self.content)
        self.search_entry.configure(width=18 if width < 1150 else 32)

    def refresh(self):
        query = self.search_value.get().strip().lower()
        self.tree.delete(*self.tree.get_children())
        for company in self.companies:
            text = " ".join(str(company.get(key, "")) for key in ("internal_code", "name", "region", "tax_id", "username", "note")).lower()
            if query and query not in text:
                continue
            website = "已设置" if company.get("tax_url") else "未设置"
            self.tree.insert("", "end", iid=company["id"], values=(company.get("internal_code", ""), company.get("name", ""), company.get("region", ""), company.get("tax_id", ""), company.get("username", ""), company.get("method", ""), website, "••••••••", company.get("note", "")))
        self.count_value.set(f"共 {len(self.companies)} 家公司")

    # Business-workbench presentation.  These later definitions intentionally
    # replace the earlier compact prototype while keeping its data operations.
    def setup_style(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TLabel", font=("Microsoft YaHei UI", 9), background=C('white'), foreground=C('secondary'))
        style.configure("TButton", font=("Microsoft YaHei UI", 9), padding=(16, 9), borderwidth=0)
        style.configure("Primary.TButton", foreground="white", background=C('primary'), borderwidth=0)
        style.map("Primary.TButton", background=[("active", C('focus'))])
        style.configure("Secondary.TButton", foreground=C('ink'), background=C('pearl'), borderwidth=0)
        style.map("Secondary.TButton", background=[("active", C('hairline'))])
        style.configure("Danger.TButton", foreground=C('ink'), background=C('parchment'), borderwidth=0)
        style.map("Danger.TButton", background=[("active", C('parchment'))])
        style.configure("Treeview", font=("Microsoft YaHei UI", 9), rowheight=46,
                        background="white", fieldbackground="white", foreground=C('ink'), borderwidth=0)
        style.map("Treeview", background=[("selected", C('parchment'))], foreground=[("selected", C('focus'))])
        style.configure("Treeview.Heading", font=("Microsoft YaHei UI", 9, "bold"), padding=(10, 12),
                        background=C('parchment'), foreground=C('secondary'), relief="flat")
        style.map("Treeview.Heading", background=[("active", C('pearl'))])
        style.configure("TCombobox", padding=(10, 6), fieldbackground="white", background="white",
                        foreground=C('ink'), bordercolor=C('hairline'), arrowcolor=C('muted'))
        style.map("TCombobox", fieldbackground=[("readonly", "white")],
                  foreground=[("readonly", C('ink'))], bordercolor=[("focus", C('ink'))])
        style.configure("Office.TCombobox", padding=(10, 6))
        style.configure("TScrollbar", background=C('hairline'), troughcolor=C('parchment'),
                        bordercolor=C('parchment'), arrowcolor=C('muted'), width=12)
        style.map("TScrollbar", background=[("active", C('ink'))])
        self.option_add("*TCombobox*Listbox.font", ("Microsoft YaHei UI", 9))
        self.option_add("*TCombobox*Listbox.background", "white")
        self.option_add("*TCombobox*Listbox.foreground", C('ink'))

    def _nav_item(self, parent, icon, text, active=False, badge="", command=None):
        color = C('pearl') if active else C('white')
        row = tk.Frame(parent, bg=color, height=40)
        row.pack(fill="x", padx=10, pady=1)
        row.pack_propagate(False)
        tk.Label(row, text=f"{icon}   {text}", bg=color,
                 fg=C('ink') if active else C('muted'),
                 font=("Microsoft YaHei UI", 9, "bold" if active else "normal")).pack(side="left", padx=15, pady=10)
        if badge:
            tk.Label(row, text=badge, bg=color, fg=C('muted'),
                     font=("Microsoft YaHei UI", 7)).pack(side="right", padx=12)
        if command:
            row.configure(cursor="hand2")
            for widget in (row, *row.winfo_children()):
                widget.configure(cursor="hand2")
                widget.bind("<Button-1>", lambda _event, action=command: action())
        if not active:
            def hover(value):
                row.configure(bg=value)
                for child in row.winfo_children():
                    child.configure(bg=value)
            row.bind("<Enter>", lambda _e: hover(C('parchment')))
            row.bind("<Leave>", lambda _e: hover(color))
        return row

    def _nav_group(self, parent, title, children):
        holder = tk.Frame(parent, bg=C('white'))
        holder.pack(fill="x")
        child_box = tk.Frame(holder, bg=C('parchment'))
        expanded = {"value": False}
        header = tk.Frame(holder, bg=C('white'), height=40, cursor="hand2")
        header.pack(fill="x", padx=10, pady=1); header.pack_propagate(False)
        arrow = tk.Label(header, text="▸", bg=C('white'), fg=C('ink'), font=("Segoe UI Symbol", 9))
        arrow.pack(side="left", padx=(15, 8))
        label = tk.Label(header, text=title, bg=C('white'), fg=C('ink'), font=("Microsoft YaHei UI", 9, "bold"))
        label.pack(side="left", pady=10)
        def toggle():
            expanded["value"] = not expanded["value"]
            arrow.configure(text="▾" if expanded["value"] else "▸")
            if expanded["value"]: child_box.pack(fill="x", padx=(14, 0))
            else: child_box.pack_forget()
        for widget in (header, arrow, label): widget.bind("<Button-1>", lambda _event: toggle())
        for icon, text, badge, command in children:
            self._nav_item(child_box, icon, text, badge=badge, command=command)

    def _metric_card(self, parent, column, title, variable, color, caption):
        card = RoundedPanel(parent, height=168, radius=18, padding=24)
        card.configure(width=190 if column==3 else 110)
        card.grid(row=0, column=column, sticky="ew", padx=(0 if column == 0 else 5, 0 if column == 3 else 5))
        body = card.body
        tk.Label(body, text=title, bg="white", fg=C('muted'), font=("Microsoft YaHei UI", 8)).pack(anchor="w")
        tk.Label(body, textvariable=variable, bg="white", fg=C('ink'),
                 font=("Segoe UI", 22)).pack(anchor="w", pady=(10, 8))
        tk.Label(body, text=caption, bg="white", fg=C('muted'), font=("Microsoft YaHei UI", 7)).pack(anchor="w")

    def build_ui(self):
        self.configure(bg=C('parchment'))
        shell = tk.Frame(self, bg=C('parchment'))
        shell.pack(fill="both", expand=True)

        self.sidebar = tk.Frame(shell, bg=C('white'), width=252,
                                highlightbackground=C('hairline'), highlightthickness=1)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)
        brand = tk.Frame(self.sidebar, bg=C('white'), height=98)
        brand.pack(fill="x"); brand.pack_propagate(False)
        self._sidebar_brand_photo = brand_photo(self, 48)
        tk.Label(brand, image=self._sidebar_brand_photo, bg=C('white'),
                 borderwidth=0).pack(side="left", padx=(18, 11), pady=22)
        brand_words = tk.Frame(brand, bg=C('white'))
        brand_words.pack(side="left", fill="both", expand=True, pady=22, padx=(0, 14))
        tk.Label(brand_words, text="税务工作台", bg=C('white'), fg=C('ink'),
                 font=("Microsoft YaHei UI", 12, "bold")).pack(anchor="w")
        tk.Label(brand_words, text="企业涉税事项管理", bg=C('white'), fg=C('muted'),
                 font=("Microsoft YaHei UI", 8)).pack(anchor="w", pady=(3, 0))
        tk.Label(self.sidebar, text="业务导航", bg=C('white'), fg=C('muted'),
                 font=("Microsoft YaHei UI", 8)).pack(anchor="w", padx=22, pady=(18, 8))
        self._nav_item(self.sidebar, "▣", "登录工作台", True)
        self._nav_group(self.sidebar, "企业与申报", (
            ("▤", "企业档案", "当前", lambda: None),
            ("◴", "申报与缴费状态", "00XE试点", lambda: open_status(self,self.companies,self._start_company_login)),
            ("▣", "申报资料档案", "本机", lambda: open_archive(self,self.companies)),
            ("▧", "报表与申报", "可使用",
             lambda: open_report_center(self, self.companies, None,
                                        lambda company: self._start_company_login(company, report_mode=True))),
            ("▦", "开票任务", "本地预览", lambda: open_invoice_tasks(self, self.companies, self._start_company_login)),
        ))
        self._nav_group(self.sidebar, "知识中心", (
            ("⌕", "税收政策库", "官方", lambda: open_policy_library(self)),
            ("◇", "税务案例库", "知识", lambda: open_case_library(self)),
            ("▶", "申报实操库", "资料", lambda: open_practice_library(self)),
        ))
        self._nav_group(self.sidebar, "系统管理", (
            ("↻", "软件更新", current_version(), lambda: self.updates.show()),
            ("◎", "地区网址管理", "检测", lambda: open_region_url_manager(self, self.companies, save_companies)),
            ("◷", "浏览器分配", "自动", lambda: open_browser_settings(self)),
        ))
        security = tk.Frame(self.sidebar, bg=C('parchment'), highlightbackground=C('hairline'), highlightthickness=1)
        security.pack(side="bottom", fill="x", padx=14, pady=12)
        tk.Label(security, text="●  本地安全存储", bg=C('parchment'), fg=C('ink'),
                 font=("Microsoft YaHei UI", 9, "bold")).pack(anchor="w", padx=13, pady=(12, 5))
        tk.Label(security, text="凭据使用 Windows 用户密钥加密\n仅保存在本机，不上传云端", justify="left",
                 bg=C('parchment'), fg=C('muted'), font=("Microsoft YaHei UI", 8)).pack(anchor="w", padx=13, pady=(0, 12))
        tk.Label(security, text="版本 "+current_version(),bg=C('parchment'),fg=C('muted'),
                 font=("Microsoft YaHei UI",8)).pack(anchor='w',padx=13)
        AppleButton(security,text="检查更新",bg=C('white'),command=lambda:self.updates.show()).pack(fill='x',padx=12,pady=12)

        self.content = tk.Frame(shell, bg=C('parchment'))
        self.content.pack(side="left", fill="both", expand=True)

        header = tk.Frame(self.content, bg=C('parchment'), height=140)
        header.pack(fill="x", padx=32); header.pack_propagate(False)
        header_text = tk.Frame(header, bg=C('parchment'))
        header_text.pack(side="left", fill="y")
        tk.Label(header_text, text="企业工作台", bg=C('parchment'), fg=C('ink'),
                 font=("Microsoft YaHei UI", 24, "bold")).pack(anchor="w", pady=(28, 12))
        tk.Label(header_text, text="集中管理企业账号，快速进入各地区电子税务局", bg=C('parchment'), fg=C('muted'),
                 font=("Microsoft YaHei UI", 9)).pack(anchor="w")
        AppleButton(header, text="＋  新增公司", command=self.add_company, bg=C('primary'), fg="white",
                  activebackground=C('focus'), activeforeground="white", relief="flat", bd=0,
                  cursor="hand2", font=("Microsoft YaHei UI", 9, "bold"), padx=18, pady=9
                  ).pack(side="right", pady=(30, 34))

        metrics = tk.Frame(self.content, bg=C('parchment'))
        metrics.pack(fill="x", padx=28, pady=(0, 13))
        for column in range(5):
            metrics.columnconfigure(column, weight=2 if column==3 else 1)
        self._metric_card(metrics, 0, "企业总数", self.count_value, C('ink'), "已纳入工作台")
        self._metric_card(metrics, 1, "本期已报税", self.filed_value, C('primary'), "状态为已报税")
        self._metric_card(metrics, 2, "本期待申报", self.pending_value, C('parchment'), "状态为未报税")
        self._metric_card(metrics, 3, "待缴税额", self.tax_due_value, C('parchment'), "全部企业汇总")
        self._metric_card(metrics, 4, "活动窗口", self.session_value, C('ink'), "当前登录会话")

        toolbar = tk.Frame(self.content, bg="white", highlightbackground=C('hairline'), highlightthickness=1)
        toolbar.pack(fill="x", padx=28, pady=(0, 11))
        tk.Label(toolbar, text="企业档案", bg="white", fg=C('ink'),
                 font=("Microsoft YaHei UI", 11, "bold")).pack(side="left", padx=(16, 12), pady=14)
        region_box = ttk.Combobox(toolbar, textvariable=self.region_filter, values=("全部地区",) + REGIONS,
                                  state="readonly", width=10, style="Office.TCombobox")
        region_box.pack(side="left", padx=(0, 10))
        region_box.bind("<<ComboboxSelected>>", lambda _event: self.refresh())
        status_box = ttk.Combobox(toolbar, textvariable=self.status_filter,
                                  values=("全部状态", "未设置", "未报税", "已报税", "无需申报"),
                                  state="readonly", width=9, style="Office.TCombobox")
        status_box.pack(side="left", padx=(0, 10))
        status_box.bind("<<ComboboxSelected>>", lambda _event: self.refresh())
        search_panel = RoundedPanel(toolbar, height=48, radius=24, padding=8)
        search_panel.pack(side="left", fill="x", expand=True, padx=(0, 12), pady=9)
        search_wrap = search_panel.body
        tk.Label(search_wrap, text="搜索", bg=C('white'), fg=C('muted'),
                 font=("Segoe UI Symbol", 13)).pack(side="left", padx=(10, 4))
        self.search_entry = tk.Entry(search_wrap, textvariable=self.search_value, relief="flat", bd=0,
                                     bg=C('white'), fg=C('secondary'), insertbackground=C('secondary'),
                                     font=("Microsoft YaHei UI", 9))
        self.search_entry.pack(side="left", fill="x", expand=True, padx=(0, 10), pady=7)
        self.search_value.trace_add("write", lambda *_: self.refresh())
        AppleButton(toolbar, text="登录税务局", command=self.login_company, bg=C('primary'), fg="white",
                  activebackground=C('focus'), activeforeground="white", relief="flat", bd=0,
                  cursor="hand2", font=("Microsoft YaHei UI", 9, "bold"), padx=20, pady=8
                  ).pack(side="right", padx=(0, 14), pady=9)

        table_card = tk.Frame(self.content, bg="white", highlightbackground=C('hairline'), highlightthickness=1)
        table_card.pack(fill="both", expand=True, padx=28, pady=(0, 11))
        columns = ("internal_code", "name", "region", "tax_id", "filing_status", "tax_due",
                   "filing_deadline", "website")
        self.tree = ttk.Treeview(table_card, columns=columns, show="headings", selectmode="browse", height=2)
        headings = {"internal_code": "内部代码", "name": "公司名称", "region": "地区",
                    "tax_id": "税号 / 统一社会信用代码", "filing_status": "申报状态",
                    "tax_due": "应缴税额（元）", "filing_deadline": "申报期限",
                    "website": "税务局入口"}
        widths = {"internal_code": 90, "name": 360, "region": 75, "tax_id": 240,
                  "filing_status": 100, "tax_due": 130, "filing_deadline": 115, "website": 105}
        for key in columns:
            self.tree.heading(key, text=headings[key], anchor="w" if key in ("name", "tax_id") else "center")
            self.tree.column(key, width=widths[key], minwidth=70,
                             anchor="w" if key in ("name", "tax_id") else "center", stretch=False)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vertical = ttk.Scrollbar(table_card, orient="vertical", command=self.tree.yview)
        vertical.grid(row=0, column=1, sticky="ns")
        horizontal = ttk.Scrollbar(table_card, orient="horizontal", command=self.tree.xview)
        horizontal.grid(row=1, column=0, sticky="ew")
        table_card.rowconfigure(0, weight=1); table_card.columnconfigure(0, weight=1)
        self.tree.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        self.empty_hint = tk.Label(self.tree, text="没有匹配的企业\n请调整搜索条件或新增公司", bg=C('white'), fg=C('muted'),
                                   font=("Microsoft YaHei UI", -17), justify='center')
        self.tree.tag_configure("pending", foreground=C('ink'))
        self.tree.tag_configure("filed", foreground=C('ink'))
        self.tree.bind("<Double-1>", lambda _event: self.edit_company())
        self.tree.bind("<Button-3>", self.open_menu)

        self.menu = tk.Menu(self, tearoff=False, font=("Microsoft YaHei UI", 9))
        self.menu.add_command(label="登录税务局", command=self.login_company)
        self.menu.add_command(label="编辑企业资料", command=self.edit_company)
        self.menu.add_separator(); self.menu.add_command(label="删除企业", command=self.delete_company)

        footer = tk.Frame(self.content, bg=C('parchment'))
        footer.pack(fill="x", padx=28, pady=(0, 14))
        tk.Label(footer, text="运行状态：", bg=C('parchment'), fg=C('muted'),
                 font=("Microsoft YaHei UI", 8)).pack(side="left", pady=9)
        tk.Label(footer, textvariable=self.status_value, bg=C('parchment'), fg=C('ink'),
                 font=("Microsoft YaHei UI", 8, "bold")).pack(side="left", pady=9)
        ttk.Button(footer, text="删除", style="Danger.TButton", command=self.delete_company).pack(side="right", padx=(8, 0))
        ttk.Button(footer, text="编辑资料", style="Secondary.TButton", command=self.edit_company).pack(side="right")

    def _on_window_resize(self, event):
        if event.widget is not self:
            return
        width = self.winfo_width()
        desired_sidebar = 230 if width < 1180 else 252
        if int(self.sidebar.cget('width')) != desired_sidebar:
            self.sidebar.configure(width=desired_sidebar)
        if hasattr(self, "tree"):
            # Limit the name column so a wide window does not push the other
            # columns off-screen. The horizontal bar remains at small widths.
            sidebar_width = 230 if width < 1180 else 252
            available = max(900, width - sidebar_width - 76)
            fixed = 90 + 75 + 240 + 100 + 130 + 115 + 105
            desired_name = min(620, max(320, available - fixed))
            if int(self.tree.column('name','width')) != desired_name:
                self.tree.column("name", width=desired_name)

    def refresh(self):
        query = self.search_value.get().strip().lower()
        selected_region = self.region_filter.get()
        selected_status = self.status_filter.get()
        self.tree.delete(*self.tree.get_children())
        for company in self.companies:
            text = " ".join(str(company.get(key, "")) for key in
                            ("internal_code", "name", "region", "tax_id", "username", "note")).lower()
            if query and query not in text:
                continue
            if selected_region != "全部地区" and company.get("region") != selected_region:
                continue
            filing_status = company.get("filing_status", "未设置")
            if selected_status != "全部状态" and filing_status != selected_status:
                continue
            website = "已配置" if company.get("tax_url") else "待配置"
            status_tag = "pending" if filing_status == "未报税" else ("filed" if filing_status == "已报税" else "")
            self.tree.insert("", "end", iid=company["id"], tags=(status_tag,) if status_tag else (), values=(
                company.get("internal_code", ""), company.get("name", ""), company.get("region", ""),
                company.get("tax_id", ""), filing_status, f"¥{company.get('tax_due', '0.00')}",
                company.get("filing_deadline", "") or "—", website))
        configured = sum(1 for company in self.companies if company.get("tax_url"))
        filed = sum(1 for company in self.companies if company.get("filing_status", "未设置") == "已报税")
        pending = sum(1 for company in self.companies if company.get("filing_status", "未设置") == "未报税")
        total_due = Decimal("0")
        for company in self.companies:
            try:
                total_due += Decimal(str(company.get("tax_due", "0") or "0"))
            except InvalidOperation:
                continue
        self.count_value.set(str(len(self.companies)))
        self.configured_value.set(str(configured))
        self.unconfigured_value.set(str(len(self.companies) - configured))
        self.filed_value.set(str(filed))
        self.pending_value.set(str(pending))
        self.tax_due_value.set(f"¥{total_due:,.2f}")
        self.session_value.set(str(len(self.active_sessions)))
        if hasattr(self,'empty_hint'):
            if self.tree.get_children():
                self.empty_hint.place_forget()
            else:
                self.empty_hint.place(relx=0.5,rely=0.45,anchor='center')

    def selected(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showinfo("提示", "请先选择一家公司。", parent=self)
            return None
        return next((item for item in self.companies if item.get("id") == selection[0]), None)

    def add_company(self):
        dialog = CompanyDialog(self, region_urls=self.region_url_map())
        self.wait_window(dialog)
        if dialog.result:
            if any(item.get("tax_id") == dialog.result["tax_id"] for item in self.companies):
                messagebox.showwarning("提示", "该税号已存在，请检查。", parent=self)
                return
            if any(item.get("internal_code") == dialog.result["internal_code"] for item in self.companies):
                messagebox.showwarning("提示", "该内部代码已存在，请检查。", parent=self)
                return
            self.companies.insert(0, dialog.result)
            self.sync_region_url(dialog.result)
            save_companies(self.companies)
            self.refresh()

    def edit_company(self):
        company = self.selected()
        if not company:
            return
        dialog = CompanyDialog(self, company, self.region_url_map())
        self.wait_window(dialog)
        if dialog.result:
            if any(item.get("tax_id") == dialog.result["tax_id"] and item.get("id") != company["id"] for item in self.companies):
                messagebox.showwarning("提示", "该税号已存在，请检查。", parent=self)
                return
            if any(item.get("internal_code") == dialog.result["internal_code"] and item.get("id") != company["id"] for item in self.companies):
                messagebox.showwarning("提示", "该内部代码已存在，请检查。", parent=self)
                return
            index = self.companies.index(company)
            self.companies[index] = dialog.result
            self.sync_region_url(dialog.result)
            save_companies(self.companies)
            self.refresh()

    def region_url_map(self):
        return dict(self.region_urls)

    def sync_region_url(self, source):
        region, url = source.get("region"), source.get("tax_url")
        if not region:
            return
        if url:
            self.region_urls[region] = url
        elif region not in REGION_TAX_URLS:
            self.region_urls.pop(region, None)
        save_custom_region_urls(self.region_urls)
        for company in self.companies:
            if company.get("region") == region:
                company["tax_url"] = url

    def delete_company(self):
        company = self.selected()
        if company and messagebox.askyesno("确认删除", f"确定删除公司「{company['name']}」吗？", parent=self):
            self.companies.remove(company)
            save_companies(self.companies)
            self.refresh()

    def open_menu(self, event):
        row = self.tree.identify_row(event.y)
        if row:
            self.tree.selection_set(row)
            self.menu.tk_popup(event.x_root, event.y_root)

    def login_company(self):
        company = self.selected()
        if not company:
            return
        self._start_company_login(company)

    def _start_company_login(self, company, report_mode=False):
        self.refresh_login_sessions()
        key = identity_key(company)
        if key in self.session_identities.values():
            messagebox.showinfo('企业登录窗口已打开', '该企业已有独立登录窗口，请使用原窗口；如需重新登录，请先自行关闭原窗口。重复登录可能触发税局单账号会话限制。', parent=self)
            return
        password = unprotect_text(company.get("password", ""))
        if not password:
            messagebox.showerror("无法读取密码", "密码解密失败，请编辑该公司并重新保存密码。", parent=self)
            return
        tax_url = company.get("tax_url", "").strip()
        if not tax_url:
            messagebox.showwarning(
                "尚未设置报税网站",
                "请双击该公司，在“报税网站链接”中填写所属省份的电子税务局网址。",
                parent=self,
            )
            return
        try:
            tax_url = login_entry(company, self.region_urls)
        except ValueError as error:
            messagebox.showwarning('请检查登录地区和入口', str(error), parent=self)
            return
        session_id = str(uuid.uuid4())
        try:
            browser_choice=reserve_browser(company.get('region'),session_id)
        except ValueError as error:
            messagebox.showwarning('无法分配独立浏览器',str(error),parent=self)
            return
        cancel_event = threading.Event()
        self.active_sessions[session_id] = company.get("name", "")
        self.session_identities[session_id] = key
        register_bridge(session_id, company)
        self.session_value.set(str(len(self.active_sessions)))
        self.status_value.set(f"正在使用 {browser_choice['name']} 打开 {company.get('region', '')}｜{company.get('name', '')}（独立会话）…")
        worker = threading.Thread(
            target=self._browser_worker,
            args=(session_id, tax_url, company.get("tax_id", ""), company.get("username", ""), password, cancel_event, report_mode, browser_choice),
            daemon=True,
        )
        self.session_threads[session_id] = worker
        try:worker.start()
        except Exception:
            self._login_finished(session_id)
            raise

    def _browser_worker(self, session_id: str, tax_url: str, tax_id: str, username: str, password: str, cancel_event, report_mode=False, browser_choice=None):
        profile_dir = None
        try:
            from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
            from playwright.sync_api import sync_playwright
        except ImportError:
            self.after(0, lambda: messagebox.showerror(
                "缺少浏览器组件",
                "请先双击同一文件夹中的“安装运行环境.pyw”，安装完成后再试。",
                parent=self,
            ))
            self.after(0, lambda: self._login_finished(session_id))
            return

        try:
            with sync_playwright() as playwright:
                profile_dir = profile_directory(APP_DIR)
                context = launch_context(playwright, profile_dir,
                                         browser=(browser_choice or {}).get('channel','msedge'),
                                         executable=(browser_choice or {}).get('path'))
                page = context.pages[0] if context.pages else context.new_page()
                try:
                    session = context.new_cdp_session(page)
                    window = session.send("Browser.getWindowForTarget")
                    session.send(
                        "Browser.setWindowBounds",
                        {"windowId": window["windowId"], "bounds": {"windowState": "maximized"}},
                    )
                except Exception:
                    # --start-maximized remains as the fallback for Edge versions
                    # that do not expose window bounds through CDP.
                    pass
                page = self._open_tax_portal(
                    context, page, tax_url, cancel_event=cancel_event
                )
                page._tax_status_poll = lambda: drain_readonly(session_id, context)
                # Provincial portals may contain more than one official landing
                # layer (for example Jiangsu: SSO page -> portal -> unified login).
                # Follow up to three top-right Login controls until form fields appear.
                for _landing_step in range(3):
                    state = self._wait_for_login_state(page, timeout=15, cancel_event=cancel_event)
                    if state == "form":
                        break
                    if state != "portal":
                        raise RuntimeError("税务局页面已打开，但没有检测到登录入口或账号输入框。")
                    old_url = page.url
                    if not self._click_top_right_login(page, timeout=2, cancel_event=cancel_event):
                        raise RuntimeError("税务局页面已打开，但未找到右上角的“登录”入口。")
                    self.after(0, lambda: self.status_value.set("正在等待税务局跳转至统一登录页面…"))
                    page = self._wait_for_navigation_change(context, page, old_url, timeout=35, cancel_event=cancel_event)
                    page._tax_status_poll = lambda: drain_readonly(session_id, context)
                if not self._has_input_keyword(page, "统一社会信用代码"):
                    raise RuntimeError("已经完成税务局首页跳转，但仍未进入统一登录页面。")

                fields = (
                    (("统一社会信用代码", "纳税人识别号"), tax_id),
                    (("居民身份证号码", "手机号码", "用户名"), username),
                    (("个人用户密码",), password),
                )
                for keywords, value in fields:
                    if not self._fill_login_field(page, keywords, value):
                        raise RuntimeError("登录页面已变化，未找到字段：" + "/".join(keywords))

                if not self._click_text_button(page, ("登录",), timeout=15, cancel_event=cancel_event):
                    raise RuntimeError("三项信息已填写，但未找到可点击的“登录”按钮。")

                self.after(0, lambda: self.status_value.set("请在当前税局浏览器中完成页面安全验证；通过后将自动获取验证码"))

                if not self._click_text_button(page, ("获取验证码", "发送验证码"), timeout=300, cancel_event=cancel_event,
                                               ready_check=lambda: any(self._has_authenticated_identity(p,tax_id) for p in context.pages if not p.is_closed())):
                    if cancel_event.is_set():
                        return
                    raise RuntimeError("等待验证超过5分钟，或没有找到可用的“获取验证码”按钮。请重新发起登录。")

                status_message = '已识别企业登录成功，可在状态中心同步当前页面。' if any(self._has_authenticated_identity(p,tax_id) for p in context.pages if not p.is_closed()) else '验证码已请求，请查看短信并在当前税局浏览器中输入。'
                self.after(0, lambda m=status_message: self.status_value.set(m))
                if report_mode:
                    self.after(0, lambda: self.status_value.set("等待完成短信验证；登录后将自动寻找财务报表申报入口"))
                    if self._open_financial_report_entry(page, timeout=600, cancel_event=cancel_event):
                        self.after(0, lambda: self.status_value.set("已进入财务报表申报入口，请核对页面后继续"))
                    elif not cancel_event.is_set() and not page.is_closed():
                        self.after(0, lambda: self.status_value.set("已登录，但未自动识别财务报表入口，请在税务局首页手动选择"))
                self._keep_browser_session_alive(context, page, cancel_event,
                                                on_tick=lambda: drain_readonly(session_id, context))
        except PlaywrightTimeoutError:
            if cancel_event.is_set():
                return
            self.after(0, lambda: messagebox.showerror("打开失败", "税务局登录页面加载超时，请检查网络后重试。", parent=self))
        except Exception as error:
            if cancel_event.is_set():
                return
            message = str(error)
            self.after(0, lambda m=message: messagebox.showerror("自动填写失败", m, parent=self))
        finally:
            password = ""
            release_browser(session_id)
            if profile_dir:
                shutil.rmtree(profile_dir, ignore_errors=True)
            self.after(0, lambda: self._login_finished(session_id))

    @staticmethod
    def _keep_browser_session_alive(context, page, cancel_event, on_tick=None):
        """Dispatch popup/close events until this session's last tab closes."""
        while not cancel_event.is_set():
            if on_tick: on_tick()
            try:
                pages = [candidate for candidate in context.pages if not candidate.is_closed()]
            except Exception:
                return
            if not pages:
                return
            if page not in pages:
                page = pages[-1]
            try:
                page.wait_for_timeout(100)
            except Exception:
                continue

    @staticmethod
    def _open_financial_report_entry(page, timeout: int, cancel_event=None) -> bool:
        """After the user completes security verification, open the report task.

        This only navigates to the financial-statement workspace.  It never
        clicks a declaration/submission confirmation.
        """
        deadline = time.time() + timeout
        while time.time() < deadline:
            if cancel_event is not None and cancel_event.is_set():
                return False
            if page.is_closed():
                return False
            for frame in page.frames:
                try:
                    task = frame.get_by_text("财务报表报送（季报）", exact=True)
                    for index in range(task.count()):
                        label = task.nth(index)
                        if not label.is_visible():
                            continue
                        row = label.locator("xpath=ancestor::tr[1]")
                        if row.count():
                            action = row.get_by_text("填写申报表", exact=True)
                            if action.count() and action.first.is_visible():
                                action.first.click()
                                return True
                        label.click()
                        return True
                except Exception:
                    pass
                for text in ("财务报表报送及更正", "财务报表报送"):
                    try:
                        candidate = frame.get_by_text(text, exact=True)
                        if candidate.count() and candidate.first.is_visible():
                            candidate.first.click()
                            return True
                    except Exception:
                        continue
            page.wait_for_timeout(200)
        return False

    @staticmethod
    def _open_tax_portal(context, page, tax_url: str, cancel_event=None):
        """Open an official portal with safe fallbacks for unstable landing URLs.

        A few provincial gateways intermittently return an HTTP error for their old
        deep link while the provincial home page remains available.  Retrying only
        the same deep link left Edge on a white/error tab.  This method keeps the
        configured address first, adds known official home-page fallbacks, and only
        accepts a page that has visible tax-portal content.
        """
        parsed = urlparse(tax_url)
        host = (parsed.hostname or "").lower()
        candidates = [tax_url]
        if host == "etax.jiangsu.chinatax.gov.cn":
            candidates = [
                "https://etax.jiangsu.chinatax.gov.cn:8443/",
                tax_url,
                "https://etax.jiangsu.chinatax.gov.cn/",
            ]
        # Preserve order while removing duplicates.
        candidates = list(dict.fromkeys(url for url in candidates if url))
        errors = []
        for candidate_url in candidates:
            if cancel_event is not None and cancel_event.is_set():
                return page
            try:
                page.goto(candidate_url, wait_until="commit", timeout=30000)
                try:
                    page.wait_for_load_state("domcontentloaded", timeout=20000)
                except Exception:
                    pass
                page.wait_for_timeout(800)
                current_host = (urlparse(page.url).hostname or "").lower()
                if current_host != host:
                    raise RuntimeError(f"网页跳转到了非预期地址：{page.url}")
                title = ""
                body = ""
                try:
                    title = page.title().strip()
                    body = page.locator("body").inner_text(timeout=3000).strip()
                except Exception:
                    pass
                error_words = ("无法访问此页面", "ERR_HTTP_RESPONSE_CODE_FAILURE", "无法显示此页")
                if any(word in (title + "\n" + body) for word in error_words):
                    raise RuntimeError("税务局入口返回了浏览器错误页")
                if body or TaxManager._find_top_right_login(page) is not None or TaxManager._has_input_keyword(page, "统一社会信用代码"):
                    return page
                raise RuntimeError("税务局页面内容为空")
            except Exception as error:
                errors.append(f"{candidate_url}：{error}")
                try:
                    page.goto("about:blank", wait_until="commit", timeout=5000)
                except Exception:
                    pass
        raise RuntimeError(
            "税务局网页暂时无法打开，已自动尝试省局首页和备用入口。\n"
            + "\n".join(errors[-3:])
        )

    @staticmethod
    def _fill_login_field(page, keywords: tuple[str, ...], value: str) -> bool:
        """Find visible login inputs in the main page or any iframe."""
        deadline = time.time() + 15
        while time.time() < deadline:
            for frame in page.frames:
                inputs = frame.locator("input:visible")
                try:
                    count = inputs.count()
                except Exception:
                    continue
                for index in range(count):
                    field = inputs.nth(index)
                    try:
                        description = " ".join(filter(None, (
                            field.get_attribute("placeholder"),
                            field.get_attribute("aria-label"),
                            field.get_attribute("name"),
                        )))
                        if any(keyword in description for keyword in keywords):
                            field.fill(value)
                            return True
                    except Exception:
                        continue
            page.wait_for_timeout(200)
        return False

    @staticmethod
    def _has_input_keyword(page, keyword: str) -> bool:
        for frame in page.frames:
            try:
                inputs = frame.locator("input")
                for index in range(inputs.count()):
                    field = inputs.nth(index)
                    description = " ".join(filter(None, (
                        field.get_attribute("placeholder"),
                        field.get_attribute("aria-label"),
                    )))
                    if keyword in description:
                        return True
            except Exception:
                continue
        return False

    @staticmethod
    def _has_authenticated_identity(page, tax_id):
        if not tax_id:return False
        for frame in page.frames:
            try:
                text=''.join(frame.locator('body').inner_text(timeout=500).split())
                if tax_id in text and any(x in text for x in ('我的待办','本期应申报')):return True
            except Exception:pass
        return False

    @staticmethod
    def _click_text_button(page, labels: tuple[str, ...], timeout: int, cancel_event=None, ready_check=None) -> bool:
        """Wait until a visible matching button becomes enabled, then click it once."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            if cancel_event is not None and cancel_event.is_set():
                return False
            heartbeat=getattr(page,'_tax_status_poll',None)
            if heartbeat:heartbeat()
            if ready_check and ready_check():return True
            for frame in page.frames:
                candidates = []
                for label in labels:
                    candidates.extend((
                        frame.get_by_role("button", name=label, exact=True),
                        frame.locator("button, [role='button'], a").filter(has_text=label),
                    ))
                for candidate in candidates:
                    try:
                        count = candidate.count()
                    except Exception:
                        continue
                    for index in range(count):
                        button = candidate.nth(index)
                        try:
                            text = button.inner_text().strip()
                            if text not in labels or not button.is_visible() or not button.is_enabled():
                                continue
                            disabled = button.get_attribute("disabled")
                            aria_disabled = button.get_attribute("aria-disabled")
                            class_name = button.get_attribute("class") or ""
                            if disabled is not None or aria_disabled == "true" or "disabled" in class_name.lower():
                                continue
                            button.click()
                            return True
                        except Exception:
                            continue
            page.wait_for_timeout(200)
        return False

    @staticmethod
    def _click_top_right_login(page, timeout: int, cancel_event=None) -> bool:
        """Click the visible Login control nearest the top-right of the tax portal."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            if cancel_event is not None and cancel_event.is_set():
                return False
            candidate = TaxManager._find_top_right_login(page)
            if candidate is not None:
                candidate.click()
                return True
            page.wait_for_timeout(200)
        return False

    @staticmethod
    def _find_top_right_login(page):
        matches = []
        try:
            viewport_width = page.evaluate("window.innerWidth")
        except Exception:
            viewport_width = 1000
        for frame in page.frames:
            try:
                candidates = frame.get_by_text("登录", exact=True)
                for index in range(candidates.count()):
                    candidate = candidates.nth(index)
                    if not candidate.is_visible() or not candidate.is_enabled():
                        continue
                    box = candidate.bounding_box()
                    # Exclude the central Login button inside the credential form.
                    if box and box["y"] < 200 and box["x"] > viewport_width * 0.55:
                        matches.append((box["x"], -box["y"], candidate))
            except Exception:
                continue
        if not matches:
            return None
        matches.sort(key=lambda item: (item[0], item[1]), reverse=True)
        return matches[0][2]

    @staticmethod
    def _wait_for_login_state(page, timeout: int, cancel_event=None) -> str:
        deadline = time.time() + timeout
        while time.time() < deadline:
            if cancel_event is not None and cancel_event.is_set():
                return "cancelled"
            if TaxManager._has_input_keyword(page, "统一社会信用代码"):
                return "form"
            if TaxManager._find_top_right_login(page) is not None:
                return "portal"
            page.wait_for_timeout(200)
        return "unknown"

    @staticmethod
    def _wait_for_navigation_change(context, page, old_url: str, timeout: int, cancel_event=None):
        """Wait for a real destination page and ignore temporary about:blank tabs.

        Several provincial portals call window.open() first and assign the SSO
        address asynchronously.  Returning that temporary tab stopped the old
        workflow on a white page.
        """
        def usable(candidate):
            try:
                url = (candidate.url or "").strip().lower()
                return (not candidate.is_closed()) and url not in (
                    "", "about:blank", "edge://newtab/", "chrome://newtab/"
                )
            except Exception:
                return False

        deadline = time.time() + timeout
        while time.time() < deadline:
            if cancel_event is not None and cancel_event.is_set():
                return page
            candidates = []
            for candidate in context.pages:
                if not usable(candidate):
                    continue
                try:
                    changed = candidate is not page or candidate.url != old_url
                except Exception:
                    changed = False
                if changed:
                    candidates.append(candidate)
            if candidates:
                # Prefer a page on which the unified login form has already mounted.
                selected = next(
                    (candidate for candidate in reversed(candidates)
                     if TaxManager._has_input_keyword(candidate, "统一社会信用代码")),
                    candidates[-1],
                )
                try:
                    selected.wait_for_load_state("domcontentloaded", timeout=8000)
                except Exception:
                    pass
                try:
                    selected.bring_to_front()
                    selected.wait_for_timeout(600)
                except Exception:
                    pass
                return selected
            live_pages = [candidate for candidate in context.pages if not candidate.is_closed()]
            if not live_pages:
                return page
            live_pages[0].wait_for_timeout(150)

        # A slow SSO popup may still be waiting for its opener's redirect.
        # Never destroy its window reference merely because our wait timed out.
        try:
            page.bring_to_front()
        except Exception:
            pass
        return page

    def _login_finished(self, session_id):
        release_browser(session_id)
        unregister_bridge(session_id)
        self.session_identities.pop(session_id, None)
        self.active_sessions.pop(session_id, None)
        self.session_threads.pop(session_id, None)
        count = len(self.active_sessions)
        self.session_value.set(str(count))
        self.status_value.set(f"当前有 {count} 个登录窗口" if count else "就绪")

    def refresh_login_sessions(self):
        # Only remove entries whose owning worker really exited. Never clear an
        # active session merely to bypass the update protection.
        for session_id, worker in list(self.session_threads.items()):
            if not worker.is_alive():
                self._login_finished(session_id)
        count = len(self.active_sessions) + external_count()
        self.session_value.set(str(count))
        return count


if __name__ == "__main__":
    TaxManager().mainloop()
