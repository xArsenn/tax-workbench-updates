"""Choose installed Edge/Chrome per region; never silently reuse an occupied brand."""
import json
import os
from pathlib import Path
import threading
import uuid
from urllib.parse import urlparse

NAMES = {'msedge':'Microsoft Edge', 'chrome':'Google Chrome'}
_guard = threading.RLock()
_leases = {}


def settings_file(base=None):
    return (Path(base) if base else Path(os.environ.get('LOCALAPPDATA',Path.home()))/'ShenzhenTaxLoginManager')/'browser_preferences.json'


def installed_browsers():
    candidates = {'msedge':[], 'chrome':[]}
    for variable in ('ProgramFiles','ProgramFiles(x86)','LOCALAPPDATA'):
        if os.environ.get(variable):
            base=Path(os.environ[variable])
            candidates['msedge'].append(base/'Microsoft/Edge/Application/msedge.exe')
            candidates['chrome'].append(base/'Google/Chrome/Application/chrome.exe')
    try:
        import winreg
        for key, filename in (('msedge','msedge.exe'),('chrome','chrome.exe')):
            for hive in (winreg.HKEY_CURRENT_USER,winreg.HKEY_LOCAL_MACHINE):
                for view in (winreg.KEY_WOW64_64KEY,winreg.KEY_WOW64_32KEY):
                    try:
                        with winreg.OpenKey(hive,r'Software\Microsoft\Windows\CurrentVersion\App Paths'+'\\'+filename,0,winreg.KEY_READ|view) as entry:
                            candidates[key].append(Path(str(winreg.QueryValueEx(entry,'')[0]).strip('"')))
                    except OSError: pass
    except ImportError: pass
    found={}
    for key,paths in candidates.items():
        path=next((p for p in paths if p.is_file() and p.name.lower() in ('msedge.exe','chrome.exe')),None)
        if path:found[key]={'channel':key,'name':NAMES[key],'path':str(path)}
    return found


def read_preferences(base=None):
    path=settings_file(base)
    if not path.exists():return {}
    try:
        data=json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(data,dict) or any(v not in (*NAMES,'auto') for v in data.values()):raise ValueError()
        return data
    except (OSError,ValueError):
        raise ValueError('浏览器分配配置无法读取，未覆盖原文件；请检查浏览器分配设置。')


def save_preference(region, browser, base=None):
    if browser not in (*NAMES,'auto'):raise ValueError('不支持此浏览器。')
    with _guard:
        data=read_preferences(base);data[region]=browser
        path=settings_file(base);path.parent.mkdir(parents=True,exist_ok=True)
        temporary=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
        try:
            temporary.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
            temporary.replace(path)
        finally:temporary.unlink(missing_ok=True)


def region_from_url(url):
    from official_links import _PROVINCES
    host=(urlparse(url).hostname or '').lower()
    return next((region for region,code in _PROVINCES.items() if host==code+'.chinatax.gov.cn' or host.endswith('.'+code+'.chinatax.gov.cn')),None)


def reserve_browser(region, session_id, base=None, available=None):
    if not region:raise ValueError('无法识别该入口所属地区，请先配置地区。')
    available=installed_browsers() if available is None else available
    with _guard:
        if not available:raise ValueError('未检测到可用的Edge或Chrome。请自行安装受支持浏览器后重新检测，程序不会自动安装。')
        explicit=read_preferences(base).get(region,'auto')
        existing=next((x['channel'] for x in _leases.values() if x['region']==region),None)
        if existing and explicit not in ('auto',existing):
            raise ValueError('该地区已有浏览器会话，新设置需在自行关闭该地区原窗口后生效。')
        occupied={x['channel'] for x in _leases.values() if x['region']!=region}
        preference=explicit if explicit!='auto' else existing or {'深圳':'msedge','北京':'chrome'}.get(region)
        if explicit!='auto' and explicit not in available:
            raise ValueError(NAMES[explicit]+'未安装或路径不可用，请重新选择；不会静默退回Edge。')
        if explicit!='auto' and explicit in occupied:
            raise ValueError(NAMES[explicit]+'正被其他地区使用。请选另一浏览器，或先自行结束原地区会话。')
        choices=[x for x in (preference,'msedge','chrome') if x in available and x not in occupied]
        if not choices:raise ValueError('可用浏览器均已被其他地区占用，不能继续分配。请先自行结束一个地区会话；不会关闭已有窗口或共用浏览器。')
        choice=choices[0]
        result={**available[choice],'region':region}
        _leases[session_id]=result
        return dict(result)


def release_browser(session_id):
    with _guard:_leases.pop(session_id,None)


def active_assignments():
    with _guard:return [dict(x) for x in _leases.values()]


def open_browser_settings(parent):
    import tkinter as tk
    from tkinter import ttk,messagebox
    from apple_widgets import AppleButton
    from apple_theme import C
    from workspace_modules import _window
    from official_links import _PROVINCES
    win=_window(parent,'浏览器分配','不同地区分配不同浏览器；设置仅影响新会话，不关闭当前窗口。','1000x720')
    description=tk.StringVar(win)
    tk.Label(win,textvariable=description,bg=C('parchment'),fg=C('muted'),wraplength=920,anchor='w').pack(fill='x',padx=28,pady=16)
    tree=ttk.Treeview(win,columns=('region','preference','active'),show='headings')
    for key,label,width in (('region','地区',140),('preference','指定浏览器',230),('active','当前使用',230)):
        tree.heading(key,text=label);tree.column(key,width=width)
    box=tk.Frame(win);box.pack(fill='both',expand=True,padx=28)
    tree.pack(in_=box,side='left',fill='both',expand=True)
    bar=ttk.Scrollbar(box,command=tree.yview);bar.pack(side='right',fill='y');tree.configure(yscrollcommand=bar.set)
    selection=tk.StringVar(win,value='自动分配')
    footer=tk.Frame(win,bg=C('parchment'));footer.pack(fill='x',padx=28,pady=18)
    values={'自动分配':'auto',**{name:key for key,name in NAMES.items()}}
    ttk.Combobox(footer,textvariable=selection,values=list(values),state='readonly').pack(side='left')
    def refresh():
        try:
            available=installed_browsers();prefs=read_preferences();active=active_assignments()
            description.set('检测到：'+('、'.join(x['name'] for x in available.values()) or '无')+'。自动模式优先深圳Edge、北京Chrome；浏览器数量不足时会阻止新增地区。当前支持Edge和Chrome，不自动下载。')
            tree.delete(*tree.get_children())
            for region in _PROVINCES:
                live=next((x['name'] for x in active if x['region']==region),'未打开')
                tree.insert('','end',iid=region,values=(region,NAMES.get(prefs.get(region),'自动分配'),live))
        except Exception as e:messagebox.showerror('无法读取浏览器配置',str(e),parent=win)
    def save():
        if not tree.selection():return
        try:
            choice=values[selection.get()]
            if choice!='auto' and choice not in installed_browsers():raise ValueError('该浏览器尚未安装，未保存。')
            save_preference(tree.selection()[0],choice);refresh()
        except Exception as e:messagebox.showwarning('无法保存',str(e),parent=win)
    def select(_):
        if tree.selection():selection.set(tree.item(tree.selection()[0],'values')[1])
    tree.bind('<<TreeviewSelect>>',select)
    AppleButton(footer,text='保存所选地区',command=save,bg=C('primary'),fg='white').pack(side='right')
    AppleButton(footer,text='重新检测',command=refresh).pack(side='right',padx=10)
    refresh()
