"""Small native Tk components for the Apple-inspired desktop theme."""
import tkinter as tk
import math
from tkinter import font as tkfont
from apple_theme import C, RADII, SPACE


def rounded(canvas, width, height, radius, fill, outline=""):
    r = min(radius, height / 2, width / 2)
    points=[]
    for cx,cy,start in ((width-1-r,1+r,-90),(width-1-r,height-1-r,0),
                        (1+r,height-1-r,90),(1+r,1+r,180)):
        for step in range(17):
            angle=math.radians(start+step*90/16)
            points.extend((cx+r*math.cos(angle),cy+r*math.sin(angle)))
    return canvas.create_polygon(*points, fill=fill, outline=outline)


class AppleButton(tk.Canvas):
    def __init__(self, parent, **options):
        self._button_options = dict(text="", command=None, bg=C('primary'), fg=C('white'),
                             activebackground=C('primary'), activeforeground=C('white'),
                             disabledforeground=C('muted'), state="normal", cursor="hand2",
                             font=("Microsoft YaHei UI", -17), padx=22, pady=11)
        self._button_options.update(options)
        font = tkfont.Font(font=self._button_options['font'])
        width = font.measure(self._button_options['text']) + 2 * self._button_options['padx'] + 8
        height = max(44, font.metrics('linespace') + 2 * self._button_options['pady'])
        super().__init__(parent, width=width, height=height, bg=parent.cget('bg'),
                         highlightthickness=0, bd=0, takefocus=1, cursor=self._button_options['cursor'])
        self._pressed = False
        self.bind('<Configure>', lambda e: self._paint())
        self.bind('<FocusIn>', lambda e: self._paint())
        self.bind('<FocusOut>', lambda e: self._paint())
        self.bind('<ButtonPress-1>', self._press)
        self.bind('<ButtonRelease-1>', self._release)
        self.bind('<space>', lambda e: self.invoke())
        self.bind('<Return>', lambda e: self.invoke())
        self._paint()

    def configure(self, cnf=None, **kwargs):
        if cnf:
            kwargs.update(cnf)
        native = {}
        for key, value in kwargs.items():
            if key in self._button_options:
                self._button_options[key] = value
                if key == 'cursor':
                    native[key] = value
            else:
                native[key] = value
        if native:
            super().configure(**native)
        if any(key in kwargs for key in ('font','text','padx','pady')):
            metric = tkfont.Font(font=self._button_options['font'])
            super().configure(width=metric.measure(self._button_options['text'])+2*self._button_options['padx'],
                              height=max(44,metric.metrics('linespace')+2*self._button_options['pady']))
        self._paint()

    config = configure

    def cget(self, key):
        if key in self._button_options:
            return self._button_options[key]
        return super().cget(key)

    def _paint(self):
        self.delete('all')
        width = max(self.winfo_width(), int(super().cget('width')))
        height = max(self.winfo_height(), int(super().cget('height')))
        disabled = self._button_options['state'] == 'disabled'
        fill = C('chip') if disabled else self._button_options['bg']
        secondary = fill != C('primary') and not disabled
        fill = C('white') if secondary else fill
        outline = C('focus') if self.focus_get() is self else (C('primary') if secondary else '')
        shape = rounded(self, width, height, height/2, fill, outline)
        self.itemconfigure(shape, width=2 if self.focus_get() is self else 1)
        if self._pressed and not disabled:
            self.scale(shape, width/2, height/2, 0.95, 0.95)
        self.create_text(width/2, height/2, text=self._button_options['text'],
                         font=self._button_options['font'],
                         fill=C('muted') if disabled else (C('primary') if secondary else C('white')))

    def _press(self, event):
        if self._button_options['state'] != 'disabled':
            self.focus_set()
            self._pressed = True
            self._paint()

    def _release(self, event):
        pressed = self._pressed
        self._pressed = False
        self._paint()
        if pressed and 0 <= event.x < self.winfo_width() and 0 <= event.y < self.winfo_height():
            self.invoke()

    def invoke(self):
        if self._button_options['state'] != 'disabled' and self._button_options['command']:
            return self._button_options['command']()


class RoundedPanel(tk.Frame):
    def __init__(self, parent, height=160, radius=RADII['lg'], padding=SPACE['lg']):
        super().__init__(parent, bg=parent.cget('bg'), height=height, width=140)
        self.pack_propagate(False)
        self.grid_propagate(False)
        self.canvas = tk.Canvas(self, highlightthickness=0, bd=0, bg=parent.cget('bg'))
        self.canvas.pack(fill='both', expand=True)
        self.body = tk.Frame(self.canvas, bg=C('white'))
        self._window = self.canvas.create_window(padding, padding, anchor='nw', window=self.body)
        self.radius = radius
        self.padding = padding
        self.canvas.bind('<Configure>', self._resize)

    def _resize(self, event):
        self.canvas.delete('surface')
        shape = rounded(self.canvas, event.width, event.height, self.radius, C('white'), C('hairline'))
        self.canvas.itemconfigure(shape, tags=('surface',))
        self.canvas.tag_lower(shape)
        self.canvas.itemconfigure(self._window, width=max(1, event.width-2*self.padding),
                                  height=max(1, event.height-2*self.padding))
