"""Native dashboard layout for the tax workbench."""
from datetime import date
import tkinter as tk
from tkinter import ttk

from business_center import risk_findings

BACKGROUND = '#f1f4fa'
SURFACE = '#ffffff'
BORDER = '#dde5f2'
TEXT = '#192437'
MUTED = '#52637c'
BLUE = '#305fc4'
PALE = '#eaf1ff'


def label(parent, text='', *, color=TEXT, size=14, bold=False, **kwargs):
    widget = tk.Label(parent, text=text, bg=parent.cget('bg'), fg=color,
                      font=('Microsoft YaHei UI', -size, 'bold' if bold else 'normal'), **kwargs)
    widget._dashboard_font = True
    return widget


def action(parent, text, callback, *, background=PALE, foreground=BLUE):
    widget = tk.Button(parent, text=text, command=callback, bg=background, fg=foreground,
                       activebackground='#d9e6fc', activeforeground='#183f91', relief='flat',
                       borderwidth=0, cursor='hand2', padx=12, pady=7,
                       font=('Microsoft YaHei UI', -14, 'bold'))
    widget._dashboard_font = True
    return widget


def panel(parent, color=SURFACE):
    return tk.Frame(parent, bg=color, highlightbackground=BORDER, highlightthickness=1)


class Dashboard(tk.Frame):
    def __init__(self, parent, app, login_entry, actions):
        super().__init__(parent, bg=BACKGROUND)
        self.app = app
        self.login_entry = login_entry
        self.todo_signature = None
        canvas = tk.Canvas(self, bg=BACKGROUND, highlightthickness=0)
        scroll = ttk.Scrollbar(self, orient='vertical', command=canvas.yview)
        scroll.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)
        canvas.configure(yscrollcommand=scroll.set)
        body = tk.Frame(canvas, bg=BACKGROUND)
        viewport = canvas.create_window(0, 0, window=body, anchor='nw')
        body.bind('<Configure>', lambda _event: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>', lambda event: canvas.itemconfigure(viewport, width=event.width))
        self.bind('<Map>', lambda _event: canvas.yview_moveto(0))
        self.canvas = canvas

        main = tk.Frame(body, bg=BACKGROUND)
        main.grid(row=0, column=0, sticky='nsew', padx=(20, 12), pady=18)
        aside = tk.Frame(body, bg=BACKGROUND, width=248)
        aside.grid(row=0, column=1, sticky='new', padx=(0, 18), pady=18)
        body.columnconfigure(0, weight=1)
        hero = panel(main)
        hero.pack(fill='x', pady=(0, 12))
        label(hero, '税务工作台', size=28, bold=True).pack(anchor='w', padx=18, pady=(14, 4))
        self.company_info = tk.StringVar(self)
        label(hero, textvariable=self.company_info, color=MUTED, anchor='w', justify='left').pack(
            fill='x', padx=18, pady=(0, 15))

        metrics = tk.Frame(main, bg=BACKGROUND)
        metrics.pack(fill='x', pady=(0, 12))
        self.risk_count = tk.StringVar(self, '—')
        for index, (title, variable, caption) in enumerate((
            ('管理企业', app.count_value, '企业档案'),
            ('待申报企业', app.pending_value, '按本机登记'),
            ('待核对事项', self.risk_count, '按本机检查'),
            ('税局会话', app.session_value, '当前打开'),
        )):
            metrics.columnconfigure(index, weight=1, uniform='metrics')
            card = panel(metrics)
            card.grid(row=0, column=index, sticky='nsew', padx=(0, 6) if index < 3 else 0)
            label(card, title, color=MUTED, size=13).pack(anchor='w', padx=10, pady=(9, 2))
            label(card, textvariable=variable, size=26, bold=True).pack(anchor='w', padx=10)
            label(card, caption, color=MUTED, size=11).pack(anchor='w', padx=10, pady=(2, 9))

        operations = panel(main)
        operations.pack(fill='x', pady=(0, 12))
        label(operations, '常用功能', size=18, bold=True).pack(anchor='w', padx=14, pady=(11, 6))
        grid = tk.Frame(operations, bg=SURFACE)
        grid.pack(fill='x', padx=10, pady=(0, 10))
        for index, (title, caption, callback) in enumerate(actions):
            column = index % 3
            grid.columnconfigure(column, weight=1, uniform='actions')
            card = panel(grid, '#f6f8fc')
            card.grid(row=index // 3, column=column, sticky='nsew', padx=4, pady=4)
            action(card, title, callback).pack(fill='x', padx=7, pady=(7, 3))
            label(card, caption, color=MUTED, size=12).pack(padx=4, pady=(1, 7))

        workflow = panel(main)
        workflow.pack(fill='x')
        label(workflow, '批量开票流程', size=18, bold=True).pack(anchor='w', padx=14, pady=(11, 5))
        steps = tk.Frame(workflow, bg=SURFACE)
        steps.pack(fill='x', padx=10, pady=(0, 9))
        for index, text in enumerate(('导入模板', '本地校验', '登录验证', '税局批导', '复核开票')):
            steps.columnconfigure(index, weight=1, uniform='steps')
            card = panel(steps, '#fff5e0' if index in (2, 4) else '#edf3ff')
            card.grid(row=0, column=index, sticky='nsew', padx=3, pady=4)
            label(card, str(index + 1), color='#8a5400' if index in (2, 4) else BLUE, size=13,
                  bold=True).pack(anchor='w', padx=7, pady=(7, 2))
            label(card, text, size=13, bold=True).pack(anchor='w', padx=7, pady=(0, 8))

        todo = panel(aside)
        todo.pack(fill='x', pady=(0, 12))
        label(todo, '待办与预警', size=18, bold=True).pack(anchor='w', padx=13, pady=(12, 6))
        self.todo = tk.Frame(todo, bg=SURFACE, width=220)
        self.todo.pack(fill='x', padx=13, pady=(0, 8))
        action(todo, '查看风险详情', actions[-1][2]).pack(fill='x', padx=13, pady=(0, 12))
        reminders = panel(aside)
        reminders.pack(fill='x')
        label(reminders, '操作提醒', size=18, bold=True).pack(anchor='w', padx=13, pady=(12, 6))
        label(reminders, '图片和短信验证按税局提示完成。\n开票或申报前，请核对企业和明细。',
              color=MUTED, size=13, wraplength=198, justify='left').pack(anchor='w', padx=13, pady=(0, 12))

    def refresh(self, company):
        period = date.today().strftime('%Y 年 %m 月')
        name = company.get('name', '') if company else '请选择企业'
        self.company_info.set(f'{name}  ·  {period}')
        findings = risk_findings(self.app.companies, self.login_entry, self.app.region_url_map())
        self.risk_count.set(str(len(findings)))
        scoped = risk_findings([company], self.login_entry, self.app.region_url_map()) if company else findings
        if company and company.get('tax_id') and sum(
            row.get('tax_id', '').strip().upper() == company['tax_id'].strip().upper()
            for row in self.app.companies
        ) > 1:
            scoped.insert(0, (name, '税号重复', '请核对企业档案'))
        visible = scoped[:4]
        signature = (name, tuple(visible), len(scoped))
        if signature == self.todo_signature:
            return
        self.todo_signature = signature
        for child in self.todo.winfo_children():
            child.destroy()
        for _, title, detail in visible:
            label(self.todo, title, size=13, bold=True, wraplength=196, justify='left').pack(anchor='w', pady=(5, 2))
            label(self.todo, detail, color=MUTED, size=12, wraplength=196, justify='left').pack(anchor='w', pady=(0, 5))
        if not visible:
            label(self.todo, '当前企业暂无本机预警' if company else '暂无本机预警',
                  color=MUTED, size=13).pack(anchor='w', pady=8)
        elif len(scoped) > len(visible):
            label(self.todo, f'另有 {len(scoped) - len(visible)} 条', color=MUTED, size=12).pack(anchor='w')

    def scroll(self, event):
        self.canvas.yview_scroll(-1 if event.delta > 0 else 1, 'units')
