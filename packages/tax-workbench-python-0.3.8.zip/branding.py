"""Approved C: graphite ledger icon, shared by the native app windows."""
from pathlib import Path
import base64
import tkinter as tk

ASSET_DIR = Path(__file__).resolve().parent / 'assets' / 'branding'


def apply_app_icon(root):
    """Set root and future Toplevel defaults; missing assets never block login."""
    photos = []
    try:
        for size in (16, 32, 48, 128, 256):
            photos.append(brand_photo(root, size))
        root.iconphoto(True, *photos)
        root._brand_icon_photos = photos
        return True
    except (tk.TclError, OSError):
        return False


def brand_photo(widget, size=48):
    # Read via Python: Tcl's native file reader cannot see every packaged or
    # virtualized Windows path, even when Python can read the same resource.
    encoded = base64.b64encode((ASSET_DIR / f'tax-workbench-{size}.png').read_bytes())
    return tk.PhotoImage(master=widget, data=encoded, format='png')
