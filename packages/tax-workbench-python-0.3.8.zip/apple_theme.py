"""Design tokens extracted from the user supplied Apple-DESIGN.md (alpha).

Source SHA256: 83fbc614443a9b3d7569e9956a43e7b8740f9d0f939f58b8154f7a7cec3002b2
Native Tk cannot express font weight 600, tracking, or backdrop blur. Those
limitations are explicitly recorded by the acceptance audit, not emulated.
"""
import tkinter as tk
import ctypes
import os
from pathlib import Path
from tkinter import font as tkfont, ttk

COLORS = {
    'primary': '#0066cc', 'focus': '#0071e3', 'on_dark_link': '#2997ff',
    'ink': '#1d1d1f', 'secondary': '#333333', 'muted': '#7a7a7a',
    'white': '#ffffff', 'parchment': '#f5f5f7', 'pearl': '#fafafc',
    'hairline': '#e0e0e0', 'divider': '#f0f0f0', 'chip': '#d2d2d7',
    'black': '#000000', 'dark1': '#272729', 'dark2': '#2a2a2c', 'dark3': '#252527',
    'muted_on_dark': '#cccccc',
}
SPACE = {'xxs':4, 'xs':8, 'sm':12, 'md':17, 'lg':24, 'xl':32, 'xxl':48, 'section':80}
RADII = {'none':0, 'xs':5, 'sm':8, 'md':11, 'lg':18, 'pill':9999}
TYPE = {
    'hero': (56,600,1.07,-0.28), 'display': (40,600,1.1,0),
    'section': (34,600,1.47,-0.374), 'tagline': (21,600,1.19,0.231),
    'body': (17,400,1.47,-0.374), 'caption': (14,400,1.43,-0.224),
    'utility': (14,400,1.29,-0.224), 'fine': (12,400,1.0,-0.12),
    'nav': (12,400,1.0,-0.12),
}
BREAKPOINTS = (419,640,735,833,1023,1068,1440)
FONT_DIRECTORY = Path(__file__).resolve().parent / 'assets' / 'fonts'
_fonts_loaded = False
FONT_LOAD_RESULTS = []

def load_local_fonts():
    """Register bundled fonts only in this application process on Windows."""
    global _fonts_loaded
    if _fonts_loaded:
        return
    _fonts_loaded = True
    if os.name != 'nt':
        return
    register = ctypes.windll.gdi32.AddFontResourceExW
    register.argtypes = (ctypes.c_wchar_p, ctypes.c_uint, ctypes.c_void_p)
    register.restype = ctypes.c_int
    for path in sorted(FONT_DIRECTORY.glob('*')):
        if path.suffix.lower() not in ('.ttf', '.otf', '.ttc'):
            continue
        count = register(str(path), 0x10, None)  # FR_PRIVATE: no OS-wide install.
        FONT_LOAD_RESULTS.append({'file':str(path),'registered':count > 0})

def C(name):
    return COLORS[name]

def family(widget, display=False):
    load_local_fonts()
    available = set(tkfont.families(widget))
    choices = ('SF Pro Display','Inter Display','Inter','Inter Variable Text','Inter Variable') if display else ('SF Pro Text','Inter','Inter Variable Text','Inter Variable')
    for name in choices:
        if name in available:
            return name
    # Execution fallback only. This is a documented unmet requirement, not a
    # claim that Microsoft YaHei is a design-approved SF Pro substitute.
    return 'Microsoft YaHei UI'

def font(widget, role='body'):
    size, weight, _, _ = TYPE[role]
    selected = family(widget, role in ('hero','display','section'))
    if weight == 600 and selected == 'Inter Variable Text' and 'Inter Variable Text SemiBold' in tkfont.families(widget):
        return ('Inter Variable Text SemiBold', -size, 'normal')
    return (selected, -size, 'bold' if weight == 600 else 'normal')

def apply_typography(root):
    """Apply a consistent pixel-sized hierarchy to the whole native workspace."""
    from apple_widgets import AppleButton
    def walk(widget):
        if isinstance(widget, AppleButton):
            widget.configure(font=font(widget, 'body'), padx=22, pady=11)
        elif isinstance(widget, (tk.Label, tk.Entry, tk.Text, tk.Button)):
            try:
                old = tkfont.Font(font=widget.cget('font'))
                size = abs(int(old.cget('size')))
                role = getattr(widget, '_apple_role', None)
                if role is None:
                    role = 'display' if size >= 19 else ('tagline' if size >= 12 else 'body')
                    if size <= 8:
                        role = 'fine'
                    widget._apple_role = role
                widget.configure(font=font(widget, role))
            except tk.TclError:
                pass
        for child in widget.winfo_children():
            walk(child)
    walk(root)
    style = ttk.Style(root)
    for name in ('TLabel','TEntry','TCombobox','Office.TCombobox','Treeview'):
        style.configure(name, font=font(root, 'body'))
    style.configure('Treeview', rowheight=44)
    style.configure('Treeview.Heading', font=font(root,'caption'), padding=(12,12))
    for name in ('TButton','Primary.TButton','Secondary.TButton','Danger.TButton'):
        style.configure(name, font=font(root,'utility'))
    root.option_add('*TCombobox*Listbox.font',font(root,'body'))
    style.map('TCombobox', fieldbackground=[('readonly',C('white'))],
              bordercolor=[('focus',C('focus'))])

# Register before Tk builds its initial font-family cache.
load_local_fonts()
