"""Install the one Python dependency without showing a command window."""
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import messagebox, ttk


class Installer(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("税务登录助手 · 安装运行环境")
        self.geometry("520x250")
        self.resizable(False, False)
        self.configure(bg="#fff8ef")
        self.status = tk.StringVar(value="点击下方按钮安装浏览器和财务报表解析组件。")
        tk.Label(self, text="运行环境安装", bg="#fff8ef", fg="#294f87",
                 font=("Microsoft YaHei UI", 18, "bold")).pack(pady=(28, 8))
        tk.Label(self, text="只需安装一次，不会修改您的公司资料。", bg="#fff8ef", fg="#7b6f68",
                 font=("Microsoft YaHei UI", 10)).pack()
        self.progress = ttk.Progressbar(self, mode="indeterminate", length=390)
        self.progress.pack(pady=(25, 10))
        tk.Label(self, textvariable=self.status, bg="#fff8ef", fg="#344054",
                 font=("Microsoft YaHei UI", 9)).pack()
        self.button = tk.Button(self, text="开始安装", command=self.start, bg="#ff5967", fg="white",
                                activebackground="#e84555", activeforeground="white", relief="flat",
                                font=("Microsoft YaHei UI", 10, "bold"), padx=28, pady=8)
        self.button.pack(pady=15)

    def start(self):
        self.button.configure(state="disabled")
        self.status.set("正在安装，请保持网络连接……")
        self.progress.start(12)
        threading.Thread(target=self.install, daemon=True).start()

    def install(self):
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "playwright>=1.45,<2", "xlrd>=2.0.2,<3"],
            capture_output=True, text=True, creationflags=creationflags,
        )
        self.after(0, lambda: self.finish(result.returncode, result.stderr.strip()))

    def finish(self, code, details):
        self.progress.stop()
        self.button.configure(state="normal")
        if code == 0:
            self.status.set("安装完成，现在可以启动税务登录助手。")
            messagebox.showinfo("安装完成", "运行环境安装成功。\n\n现在可以双击“税务登录助手（双击这里）”。", parent=self)
        else:
            self.status.set("安装失败，请检查网络或 Python 安装。")
            messagebox.showerror("安装失败", details[-1000:] or "未能安装运行组件。", parent=self)


if __name__ == "__main__":
    Installer().mainloop()
