"""Official tax destinations, separate from third-party search engines.

Sources checked 2026-10-17: fgk.chinatax.gov.cn province directory,
12366.chinatax.gov.cn/index.html navigation and FGK policy-navigation URL.
Presence in the official directory does not guarantee continuous availability.
"""
import os
from pathlib import Path
import subprocess
import webbrowser
from urllib.parse import urlencode, urlparse

POLICY_HOME='https://fgk.chinatax.gov.cn/'
CONSULTATIONS='https://12366.chinatax.gov.cn/nszx/onlinemessage/main'
ACADEMY='https://12366.chinatax.gov.cn/nsrxt/taxpayerAcademy/main'
VIDEOS='https://12366.chinatax.gov.cn/nsrxt/videoondemand/main'
_PROVINCES={
    '北京':'beijing','天津':'tianjin','河北':'hebei','山西':'shanxi','内蒙古':'neimenggu',
    '辽宁':'liaoning','吉林':'jilin','黑龙江':'heilongjiang','上海':'shanghai','江苏':'jiangsu',
    '浙江':'zhejiang','安徽':'anhui','福建':'fujian','江西':'jiangxi','山东':'shandong','河南':'henan',
    '湖北':'hubei','湖南':'hunan','广东':'guangdong','广西':'guangxi','海南':'hainan','重庆':'chongqing',
    '四川':'sichuan','贵州':'guizhou','云南':'yunnan','西藏':'xizang','陕西':'shaanxi','甘肃':'gansu',
    '青海':'qinghai','宁夏':'ningxia','新疆':'xinjiang','大连':'dalian','宁波':'ningbo','厦门':'xiamen',
    '青岛':'qingdao','深圳':'shenzhen'}

def regional_home(region):
    if region in ('全部地区','国家税务总局',''):return 'https://www.chinatax.gov.cn/'
    if region not in _PROVINCES:raise ValueError('尚未核实该地区的官网入口，请在地区网址管理中配置。')
    return 'https://'+_PROVINCES[region]+'.chinatax.gov.cn/'

def search_url(keyword, policy=False, region='全部地区'):
    keyword=keyword.strip()
    if not keyword:raise ValueError('请输入检索关键词。')
    if policy:
        return POLICY_HOME+'zcfgk/c100028/zcwj.html?'+urlencode({
            'siteCode':'bm29000002','searchWord':keyword,'type':'','pageSize':10,'pageNum':0,
            'orderBy':5,'column':'政策法规,政策解读,政策指引',
            'label':'文字政策解读,法律,行政法规,国务院文件,税务部门规章,税务规范性文件,财税文件,其他文件,工作通知,政策指引',
            'likeDoc':0,'wordPlace':0,'indexCode':1})
    if region not in ('全部地区','国家税务总局',''):
        regional_home(region) # Never silently substitute an unrelated region.
        keyword=region+' '+keyword
    return 'https://www.chinatax.gov.cn/search5/html/searchResult.html?'+urlencode({
        'siteCode':'bm29000002','searchWord':keyword,'left_right_index':0,'searchSource':0})

def open_url(url, official=False):
    parsed=urlparse(url)
    if parsed.scheme not in ('https','http') or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError('网址无效，请检查完整的 http/https 链接。')
    if official and not (parsed.hostname=='chinatax.gov.cn' or parsed.hostname.endswith('.chinatax.gov.cn')):
        raise ValueError('不是已核实的税务机关官方域名。')
    # A visible, maximized Edge window; no insecure or anti-detection flags.
    if os.name=='nt':
        for variable in ('ProgramFiles(x86)','ProgramFiles','LOCALAPPDATA'):
            base=os.environ.get(variable)
            if not base:continue
            executable=Path(base)/'Microsoft/Edge/Application/msedge.exe'
            if executable.is_file():
                subprocess.Popen([str(executable),'--new-window','--start-maximized',url],
                                 creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                return
    if not webbrowser.open_new_tab(url):raise RuntimeError('无法打开浏览器，请检查系统默认浏览器设置。')
