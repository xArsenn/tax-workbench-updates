"""Friendly, console-free launcher for the development version."""
from pathlib import Path
import runpy
import tkinter as tk
from tkinter import messagebox


try:
    target = Path(__file__).with_name("税务登录助手_开发版.pyw")
    runpy.run_path(str(target), run_name="__main__")
except Exception as error:
    root = tk.Tk()
    root.withdraw()
    messagebox.showerror("启动失败", f"税务登录助手无法启动：\n\n{error}")
    root.destroy()
