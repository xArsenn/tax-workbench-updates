"""Small native Tk components for the Apple-inspired desktop theme."""
import tkinter as tk
from tkinter import ttk
import math
from tkinter import font as tkfont
from apple_theme import C, RADII, SPACE


class SearchSelect(tk.Frame):
    """Single editable field with suggestions that never grab keyboard focus."""
    def __init__(self,parent,variable,options,on_results=None):
        super().__init__(parent,bg=parent.cget('bg'))
        self.variable=variable;self.options=list(options);self.matches=[]
        self.on_results=on_results;self._job=None;self._muted=False
        self.columnconfigure(0,weight=1)
        self.entry=ttk.Entry(self,textvariable=variable)
        self.entry.grid(row=0,column=0,sticky='ew')
        self.arrow=ttk.Button(self,text='▾',width=2,takefocus=False,command=self.toggle)
        self.arrow.grid(row=0,column=1,sticky='ns')
        self.top=self.winfo_toplevel()
        self.popup=tk.Frame(self.top,bg=C('white'),highlightbackground=C('hairline'),highlightthickness=1)
        self.listbox=tk.Listbox(self.popup,exportselection=False,takefocus=False,activestyle='none',
                                bg=C('white'),fg=C('ink'),selectbackground=C('primary'),selectforeground='white',
                                relief='flat',borderwidth=0,font=('Microsoft YaHei UI',10))
        self.listbox.pack(side='left',fill='both',expand=True)
        scrollbar=ttk.Scrollbar(self.popup,orient='vertical',command=self.listbox.yview)
        scrollbar.pack(side='right',fill='y');self.listbox.configure(yscrollcommand=scrollbar.set)
        self.listbox.bind('<ButtonPress-1>',self._mouse_choose)
        self.entry.bind('<Down>',lambda e:self.move(1))
        self.entry.bind('<Up>',lambda e:self.move(-1))
        self.entry.bind('<Return>',self._enter)
        self.entry.bind('<Escape>',lambda e:self.hide() or 'break')
        self.entry.bind('<Tab>',lambda e:self.hide())
        self.entry.bind('<FocusIn>',lambda e:self.entry.selection_range(0,'end'))
        self.entry.bind('<FocusOut>',lambda e:self.hide())
        self.bind('<Configure>',lambda e:self.hide())
        self._trace=variable.trace_add('write',self._schedule)
        self._outside=self.top.bind('<ButtonPress-1>',self._outside_click,add='+')
        self.bind('<Destroy>',self._destroy,add='+')
        self.filter(show=False)

    def cget(self,key):
        if key=='values':return tuple(self.matches)
        if key=='state':return self.entry.cget('state')
        return super().cget(key)

    def _schedule(self,*_):
        if self._muted:return
        if self._job is not None:self.after_cancel(self._job)
        # Do not show stale candidates during the debounce interval.
        self.hide()
        self._job=self.after(100,self.filter)

    def filter(self,show=True):
        self._job=None
        typed=self.variable.get().strip().casefold()
        self.matches=[label for label,searchable in self.options if not typed or typed in searchable.casefold()]
        self.listbox.delete(0,'end')
        for label in self.matches:self.listbox.insert('end',label)
        if self.on_results:self.on_results(len(self.matches))
        if show and typed and self.entry.focus_get() is self.entry:self.show()
        else:self.hide()

    def show(self):
        if not self.matches:self.hide();return
        self.update_idletasks()
        rows=min(7,len(self.matches))
        self.listbox.configure(height=rows)
        width=min(max(self.winfo_width(),420),max(100,self.top.winfo_width()-24))
        height=self.listbox.winfo_reqheight()+2
        x=max(8,min(self.winfo_rootx()-self.top.winfo_rootx(),self.top.winfo_width()-width-8))
        y=self.winfo_rooty()-self.top.winfo_rooty()+self.winfo_height()+2
        if y+height>self.top.winfo_height()-8:y=max(8,y-self.winfo_height()-height-4)
        self.popup.place(x=x,y=y,width=width,height=height)
        self.popup.lift()
        self.listbox.selection_clear(0,'end');self.listbox.selection_set(0);self.listbox.activate(0)

    def hide(self):
        self.popup.place_forget()

    def toggle(self):
        visible=bool(self.popup.winfo_ismapped())
        self.entry.focus_set()
        if visible:self.hide()
        else:self.filter(show=False);self.show()

    def move(self,direction):
        if self._job is not None:self.after_cancel(self._job);self._job=None;self.filter(show=False)
        if not self.popup.winfo_ismapped():self.show();return 'break'
        if self.matches:
            current=self.listbox.curselection()
            index=max(0,min(len(self.matches)-1,(current[0] if current else 0)+direction))
            self.listbox.selection_clear(0,'end');self.listbox.selection_set(index)
            self.listbox.activate(index);self.listbox.see(index)
        return 'break'

    def choose(self,index):
        if not 0<=index<len(self.matches):return
        if self._job is not None:self.after_cancel(self._job);self._job=None
        self._muted=True
        try:self.variable.set(self.matches[index])
        finally:self._muted=False
        self.hide();self.entry.focus_set();self.entry.icursor('end')

    def _enter(self,event):
        if self.popup.winfo_ismapped():
            selected=self.listbox.curselection()
            if selected:self.choose(selected[0])
            return 'break'

    def _mouse_choose(self,event):
        self.choose(self.listbox.nearest(event.y));return 'break'

    def _outside_click(self,event):
        widget=event.widget
        while widget is not None:
            if widget in (self,self.popup):return
            widget=getattr(widget,'master',None)
        self.hide()

    def _destroy(self,event):
        if event.widget is not self:return
        if self._job is not None:self.after_cancel(self._job)
        self.variable.trace_remove('write',self._trace)
        self.top.unbind('<ButtonPress-1>',self._outside)
        self.popup.destroy()


def rounded(canvas, width, height, radius, fill, outline=""):
    r = min(radius, height / 2, width / 2)
    points=[]
    for cx,cy,start in ((width-1-r,1+r,-90),(width-1-r,height-1-r,0),
                        (1+r,height-1-r,90),(1+r,1+r,180)):
        for step in range(17):
            angle=math.radians(start+step*90/16)
            points.extend((cx+r*math.cos(angle),cy+r*math.sin(angle)))
    return canvas.create_polygon(*points, fill=fill, outline=outline)


class AppleButton(tk.Canvas):
    def __init__(self, parent, **options):
        self._button_options = dict(text="", command=None, bg=C('primary'), fg=C('white'),
                             activebackground=C('primary'), activeforeground=C('white'),
                             disabledforeground=C('muted'), state="normal", cursor="hand2",
                             font=("Microsoft YaHei UI", -17), padx=22, pady=11)
        self._button_options.update(options)
        font = tkfont.Font(font=self._button_options['font'])
        width = font.measure(self._button_options['text']) + 2 * self._button_options['padx'] + 8
        height = max(44, font.metrics('linespace') + 2 * self._button_options['pady'])
        super().__init__(parent, width=width, height=height, bg=parent.cget('bg'),
                         highlightthickness=0, bd=0, takefocus=1, cursor=self._button_options['cursor'])
        self._pressed = False
        self.bind('<Configure>', lambda e: self._paint())
        self.bind('<FocusIn>', lambda e: self._paint())
        self.bind('<FocusOut>', lambda e: self._paint())
        self.bind('<ButtonPress-1>', self._press)
        self.bind('<ButtonRelease-1>', self._release)
        self.bind('<space>', lambda e: self.invoke())
        self.bind('<Return>', lambda e: self.invoke())
        self._paint()

    def configure(self, cnf=None, **kwargs):
        if cnf:
            kwargs.update(cnf)
        native = {}
        for key, value in kwargs.items():
            if key in self._button_options:
                self._button_options[key] = value
                if key == 'cursor':
                    native[key] = value
            else:
                native[key] = value
        if native:
            super().configure(**native)
        if any(key in kwargs for key in ('font','text','padx','pady')):
            metric = tkfont.Font(font=self._button_options['font'])
            super().configure(width=metric.measure(self._button_options['text'])+2*self._button_options['padx'],
                              height=max(44,metric.metrics('linespace')+2*self._button_options['pady']))
        self._paint()

    config = configure

    def cget(self, key):
        if key in self._button_options:
            return self._button_options[key]
        return super().cget(key)

    def _paint(self):
        self.delete('all')
        width = max(self.winfo_width(), int(super().cget('width')))
        height = max(self.winfo_height(), int(super().cget('height')))
        disabled = self._button_options['state'] == 'disabled'
        fill = C('chip') if disabled else self._button_options['bg']
        secondary = fill != C('primary') and not disabled
        fill = C('white') if secondary else fill
        outline = C('focus') if self.focus_get() is self else (C('primary') if secondary else '')
        shape = rounded(self, width, height, height/2, fill, outline)
        self.itemconfigure(shape, width=2 if self.focus_get() is self else 1)
        if self._pressed and not disabled:
            self.scale(shape, width/2, height/2, 0.95, 0.95)
        self.create_text(width/2, height/2, text=self._button_options['text'],
                         font=self._button_options['font'],
                         fill=C('muted') if disabled else (C('primary') if secondary else C('white')))

    def _press(self, event):
        if self._button_options['state'] != 'disabled':
            self.focus_set()
            self._pressed = True
            self._paint()

    def _release(self, event):
        pressed = self._pressed
        self._pressed = False
        self._paint()
        if pressed and 0 <= event.x < self.winfo_width() and 0 <= event.y < self.winfo_height():
            self.invoke()

    def invoke(self):
        if self._button_options['state'] != 'disabled' and self._button_options['command']:
            return self._button_options['command']()


class RoundedPanel(tk.Frame):
    def __init__(self, parent, height=160, radius=RADII['lg'], padding=SPACE['lg']):
        super().__init__(parent, bg=parent.cget('bg'), height=height, width=140)
        self.pack_propagate(False)
        self.grid_propagate(False)
        self.canvas = tk.Canvas(self, highlightthickness=0, bd=0, bg=parent.cget('bg'))
        self.canvas.pack(fill='both', expand=True)
        self.body = tk.Frame(self.canvas, bg=C('white'))
        self._window = self.canvas.create_window(padding, padding, anchor='nw', window=self.body)
        self.radius = radius
        self.padding = padding
        self.canvas.bind('<Configure>', self._resize)

    def _resize(self, event):
        self.canvas.delete('surface')
        shape = rounded(self.canvas, event.width, event.height, self.radius, C('white'), C('hairline'))
        self.canvas.itemconfigure(shape, tags=('surface',))
        self.canvas.tag_lower(shape)
        self.canvas.itemconfigure(self._window, width=max(1, event.width-2*self.padding),
                                  height=max(1, event.height-2*self.padding))
