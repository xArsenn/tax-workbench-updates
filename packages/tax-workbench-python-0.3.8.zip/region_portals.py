"""Public regional portal catalog, repair rules, and conservative HTTP checks."""
import json
from pathlib import Path
import socket
import ssl
import urllib.error
import urllib.request
from urllib.parse import urlparse

CATALOG_DATE='2026-10-18'

def official_url(url):
    try:
        p=urlparse(url);host=(p.hostname or '').lower()
        return p.scheme=='https' and not p.username and not p.password and (host=='chinatax.gov.cn' or host.endswith('.chinatax.gov.cn'))
    except ValueError:return False

def catalog():
    return json.loads(Path(__file__).with_name('region_portals.json').read_text(encoding='utf-8'))

def portal_defaults():
    return {item['region']:item['login_url'] for item in catalog() if item.get('login_url')}

def merged_registry(saved):
    previous={x.get('region'):x for x in saved if isinstance(x,dict)}
    result=[]
    for default in catalog():
        item=dict(previous.get(default['region'],{}))
        bad=item.get('status') in ('不可用','异常','无效','链接失效')
        repair=bad and item.get('catalog_date')!=CATALOG_DATE and bool(default.get('login_url'))
        if repair:
            item['previous_home_url']=item.get('home_url','')
            item['previous_login_url']=item.get('login_url','')
        changed=False
        for field in ('home_url','login_url'):
            if not item.get(field) or repair:
                if item.get(field)!=default[field]:changed=True
                item[field]=default[field]
        for field in ('region','official_home','source_url','catalog_date'):
            item[field]=default[field]
        if repair or changed or 'status' not in item:
            item.update(status='待检测' if item['login_url'] else '入口待核验',checked_at='—',note=default['note'])
        item.setdefault('checked_at','—');item.setdefault('note',default['note'])
        result.append(item)
    return result

def check_entry(item,opener=None):
    url=item.get('login_url') or item.get('home_url')
    if not url:return '入口待核验','未配置官方入口'
    if not official_url(url):return '网址异常','不是有效的税务机关HTTPS域名'
    try:
        request=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
        with (opener or urllib.request.urlopen)(request,timeout=10) as response:
            final=response.geturl()
            if not official_url(final):return '跳转异常','重定向到了非税务机关HTTPS域名'
            original_host=urlparse(url).hostname;final_host=urlparse(final).hostname
            source_region='.'.join(original_host.split('.')[1:]) if original_host.startswith(('etax.','tpass.')) else original_host
            if final_host!=source_region and not final_host.endswith('.'+source_region):
                return '跳转待核验','重定向至其他税务域名，请人工确认所属地区'
            code=getattr(response,'status',200)
            return 'HTTP可达',f'HTTP {code}；仅验证网络访问，未验证登录'
    except urllib.error.HTTPError as error:
        if error.code in (401,403,412,418,429):return '需浏览器核验',f'HTTP {error.code}：网站限制自动检测，不代表链接失效'
        if error.code in (404,410):return '入口待复核',f'HTTP {error.code}：入口路径可能已调整'
        return '服务待重试',f'HTTP {error.code}：可能为网站临时异常'
    except (ssl.SSLError,urllib.error.URLError,OSError) as error:
        detail=str(error)
        if isinstance(error,ssl.SSLError) or isinstance(getattr(error,'reason',None),ssl.SSLError) or 'SSL' in detail.upper() or 'CERTIFICATE' in detail.upper():
            return '需浏览器核验','TLS/证书握手异常；未关闭证书校验，不据此认定网址失效'
        if isinstance(error,(TimeoutError,socket.timeout)) or 'timed out' in detail.lower():
            return '连接待重试','连接超时；请稍后重试或在浏览器打开'
        return '连接待重试','网络检测未完成：'+detail[:100]
