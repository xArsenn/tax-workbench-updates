"""Local financial-statement parser and validation for legacy Jiangsu XLS files.

The source workbook uses the official statement line numbers as stable keys.
No data is sent outside the computer.  This module validates and prepares a
mapping preview; it does not submit a tax declaration.
"""

from __future__ import annotations

import math
import re
import sys
from datetime import datetime
from pathlib import Path

# xlrd is pure Python and can be loaded directly from its bundled wheel. This
# keeps the dependency with the app and works with pythonw as well as python.
_XLRD_WHEEL = Path(__file__).resolve().parent / "dependency_wheels" / "xlrd-2.0.2-py2.py3-none-any.whl"
if _XLRD_WHEEL.is_file() and str(_XLRD_WHEEL) not in sys.path:
    sys.path.insert(0, str(_XLRD_WHEEL))


def _number(value):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if math.isfinite(float(value)):
            return float(value)
    return None


def _code(value):
    number = _number(value)
    if number is None:
        return None
    return str(int(number)) if number.is_integer() else str(number)


def _date_from_excel(value, datemode):
    try:
        import xlrd
        return xlrd.xldate_as_datetime(float(value), datemode).date()
    except Exception:
        return None


def _quarter_end(period_text: str):
    match = re.search(r"(20\d{2}).*第([1-4])季度", period_text or "")
    if not match:
        return None
    year, quarter = int(match.group(1)), int(match.group(2))
    return datetime(year, quarter * 3, (31, 30, 30, 31)[quarter - 1]).date()


def _close(a, b, tolerance=0.02):
    return a is not None and b is not None and abs(float(a) - float(b)) <= tolerance


def _line_map(sheet, code_col, value_cols):
    result = {}
    for row in range(sheet.nrows):
        code = _code(sheet.cell_value(row, code_col))
        if not code:
            continue
        result[code] = tuple(_number(sheet.cell_value(row, col)) for col in value_cols)
    return result


def validate_financial_report(path, company, period_text):
    """Return a structured validation and mapping preview for a legacy XLS."""
    report_path = Path(path)
    outcome = {
        "errors": [], "warnings": [], "checks": [], "summary": [],
        "mapping": {}, "tax_id": "", "period_end": "",
    }
    if report_path.suffix.lower() != ".xls":
        outcome["errors"].append("当前深度校验仅支持旧版 .xls；xlsx/csv 映射尚未建立")
        return outcome
    try:
        import xlrd
        book = xlrd.open_workbook(str(report_path), formatting_info=False)
    except ImportError:
        outcome["errors"].append("缺少报表读取组件，请确保 dependency_wheels 文件夹与助手程序在同一目录")
        return outcome
    except Exception as error:
        outcome["errors"].append(f"无法读取报表：{error}")
        return outcome
    if book.nsheets < 3:
        outcome["errors"].append("工作表数量不足，至少应包含资产负债表、利润表和现金流量表")
        return outcome

    balance = book.sheet_by_index(0)
    profit = book.sheet_by_index(1)
    cashflow = book.sheet_by_index(2)
    equity = book.sheet_by_index(3) if book.nsheets > 3 else None

    # Identity and period are stored in fixed official-template header positions.
    tax_id = str(balance.cell_value(2, 3)).strip() if balance.nrows > 2 and balance.ncols > 3 else ""
    outcome["tax_id"] = tax_id
    expected_tax_id = str(company.get("tax_id", "")).strip()
    if tax_id == expected_tax_id:
        outcome["checks"].append("企业税号一致")
    else:
        outcome["errors"].append(f"报表税号 {tax_id or '空'} 与企业档案 {expected_tax_id or '空'} 不一致")

    end_value = balance.cell_value(3, 7) if balance.nrows > 3 and balance.ncols > 7 else None
    period_end = _date_from_excel(end_value, book.datemode)
    expected_end = _quarter_end(period_text)
    outcome["period_end"] = period_end.isoformat() if period_end else ""
    if period_end and expected_end and period_end == expected_end:
        outcome["checks"].append(f"申报期间一致（截止 {period_end.isoformat()}）")
    else:
        outcome["errors"].append(
            f"报表截止日 {period_end.isoformat() if period_end else '无法识别'} 与所选期间"
            f" {expected_end.isoformat() if expected_end else period_text} 不一致"
        )

    bs_left = _line_map(balance, 2, (3, 4))
    bs_right = _line_map(balance, 6, (7, 8))
    pl = _line_map(profit, 2, (3, 4))
    cf = _line_map(cashflow, 2, (3,))
    eq = _line_map(equity, 2, (3, 4)) if equity is not None else {}
    outcome["mapping"] = {
        "资产负债表_资产": bs_left,
        "资产负债表_负债权益": bs_right,
        "利润表": pl,
        "现金流量表": cf,
        "所有者权益变动表": eq,
    }
    outcome["summary"].extend((
        f"资产负债表映射 {len(bs_left) + len(bs_right)} 个行次",
        f"利润表映射 {len(pl)} 个行次",
        f"现金流量表映射 {len(cf)} 个行次",
        f"所有者权益变动表映射 {len(eq)} 个行次",
    ))

    # Balance sheet: line 67 assets must equal line 135 liabilities + equity.
    for index, label in ((0, "年初"), (1, "期末")):
        assets = bs_left.get("67", (None, None))[index]
        liabilities_equity = bs_right.get("135", (None, None))[index]
        if _close(assets, liabilities_equity):
            outcome["checks"].append(f"资产负债表{label}平衡")
        else:
            outcome["errors"].append(
                f"资产负债表{label}不平：资产 {assets}，负债和所有者权益 {liabilities_equity}"
            )

    # Profit statement high-level relationships.
    current = {line: values[0] for line, values in pl.items()}
    cumulative = {line: values[1] for line, values in pl.items()}
    for data, label in ((current, "本期"), (cumulative, "本年累计")):
        if all(line in data for line in ("27", "28", "30")):
            if _close(data["30"], data["27"] - data["28"]):
                outcome["checks"].append(f"利润表{label}净利润勾稽正确")
            else:
                outcome["errors"].append(f"利润表{label}净利润不等于利润总额减所得税")
        else:
            outcome["warnings"].append(f"利润表{label}缺少行次27、28或30，无法校验净利润")

    # Retained earnings ending minus beginning should equal cumulative net profit
    # when there are no other distribution/adjustment movements in the supplied form.
    retained = bs_right.get("121", (None, None))
    cumulative_profit = cumulative.get("30")
    if retained[0] is not None and retained[1] is not None and cumulative_profit is not None:
        change = retained[1] - retained[0]
        if _close(change, cumulative_profit):
            outcome["checks"].append("未分配利润变动与本年累计净利润一致")
        else:
            outcome["warnings"].append(
                f"未分配利润变动 {change:.2f} 与累计净利润 {cumulative_profit:.2f} 不一致；"
                "如存在利润分配或以前年度调整需人工说明"
            )

    # Cash-flow statement relationships.
    cash = {line: values[0] for line, values in cf.items()}
    if all(line in cash for line in ("21", "37", "54", "55", "56")):
        expected = cash["21"] + cash["37"] + cash["54"] + cash["55"]
        if _close(cash["56"], expected):
            outcome["checks"].append("现金及现金等价物净增加额勾稽正确")
        else:
            outcome["errors"].append("现金流量表行次56与经营、投资、筹资及汇率影响合计不一致")
    else:
        outcome["warnings"].append("现金流量表关键行次不完整，无法完成现金净增加额校验")

    if all(line in cash for line in ("79", "80", "81", "82", "83")):
        expected = cash["79"] - cash["80"] + cash["81"] - cash["82"]
        if _close(cash["83"], expected):
            outcome["checks"].append("现金及现金等价物期末期初勾稽正确")
        else:
            outcome["errors"].append("现金流量表补充资料行次83计算不一致")

    if not eq:
        outcome["warnings"].append("所有者权益变动表未识别到有效行次")
    return outcome

