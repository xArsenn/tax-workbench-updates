"""User-controlled update center; all worker results arrive through a UI queue."""
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import ttk, messagebox

from apple_theme import C, apply_typography
from apple_widgets import AppleButton
import update_core as core

class UpdateCenter:
    def __init__(self, app):
        self.app=app;self.window=None;self.payload=None;self.busy=False
        self.events=queue.Queue();self.status=tk.StringVar(value='点击检查更新，查看是否有新版本。')
        self.progress=tk.DoubleVar(value=0)
        app.after(150,self.drain)
        settings=core.read_json(core.HOME/'update_settings.json',{})
        if settings.get('automatic_check') and settings.get('manifest_url') and (core.HOME/'update_public_key.json').is_file():
            app.after(2000,lambda:self.check(silent=True))

    def show(self):
        if self.window and self.window.winfo_exists():
            self.window.lift();return
        win=tk.Toplevel(self.app);self.window=win
        win.title('软件更新');win.geometry('760x540');win.minsize(640,480);win.configure(bg=C('parchment'))
        tk.Label(win,text='软件更新',bg=C('parchment'),fg=C('ink'),font=('Microsoft YaHei UI',22)).pack(anchor='w',padx=32,pady=(28,8))
        tk.Label(win,text=f'当前版本 {core.current_version()} · 开发版 stable',bg=C('parchment'),fg=C('muted')).pack(anchor='w',padx=32)
        tk.Label(win,textvariable=self.status,bg=C('white'),fg=C('ink'),wraplength=660,justify='left',anchor='w',padx=20,pady=20).pack(fill='x',padx=32,pady=24)
        ttk.Progressbar(win,variable=self.progress,maximum=100).pack(fill='x',padx=32)
        self.notes=tk.Text(win,height=6,bg=C('white'),fg=C('ink'),relief='flat',padx=16,pady=12)
        self.notes.pack(fill='both',expand=True,padx=32,pady=16)
        self.notes.insert('1.0','找到新版后，这里会显示更新说明。');self.notes.configure(state='disabled')
        footer=tk.Frame(win,bg=C('parchment'));footer.pack(fill='x',padx=32,pady=(0,24))
        AppleButton(footer,text='检查更新',command=self.check,bg=C('white')).pack(side='left')
        self.download_button=AppleButton(footer,text='下载更新',command=self.fetch,state='disabled')
        self.download_button.pack(side='right')
        self.restart_button=AppleButton(footer,text='重启并更新',command=self.restart,state='disabled')
        self.restart_button.pack(side='right',padx=8)
        self.restart_reason=tk.StringVar()
        tk.Label(win,textvariable=self.restart_reason,bg=C('parchment'),fg=C('muted'),
                 wraplength=680,justify='left').pack(fill='x',padx=32,pady=(0,12))
        self.render_payload()
        if core.state().get('pending'):
            self.restart_button.configure(state='normal')
            self.status.set('更新包已就绪。请完成当前业务操作后重启更新。')
        apply_typography(win)
        self.refresh_restart_state()

    def refresh_restart_state(self):
        if not self.window or not self.window.winfo_exists():return
        refresh=getattr(self.app,'refresh_login_sessions',None)
        if refresh:refresh()
        pending=core.state().get('pending')
        count=len(self.app.active_sessions)
        enabled=bool(pending and not self.busy and not count)
        state='normal' if enabled else 'disabled'
        if self.restart_button.cget('state')!=state:self.restart_button.configure(state=state)
        if pending and count:
            reason=f'版本 {pending} 已下载。暂不可重启：还有 {count} 个登录会话；请完成业务并关闭对应税局浏览器，状态会自动刷新。'
        elif pending:
            reason=f'版本 {pending} 已就绪，重启后生效。'
        else:
            reason='下载并校验更新包后，才可重启更新。'
        if self.restart_reason.get()!=reason:self.restart_reason.set(reason)

    def render_payload(self):
        if not self.window or not self.window.winfo_exists():return
        self.notes.configure(state='normal');self.notes.delete('1.0','end')
        self.notes.insert('1.0',self.payload.get('notes','暂无更新说明') if self.payload else '找到新版后，这里会显示更新说明。')
        self.notes.configure(state='disabled')
        self.download_button.configure(state='normal' if self.payload and not self.busy and not core.state().get('pending') else 'disabled')

    def start(self, work):
        if self.busy:return False
        self.busy=True
        def worker():
            try:work()
            except Exception as error:self.events.put(('error',str(error)))
            finally:self.events.put(('done',None))
        threading.Thread(target=worker,daemon=True).start();return True

    def check(self,silent=False):
        if self.busy:return
        self.status.set('正在检查新版本…')
        def work():
            result=core.check_update();self.events.put(('checked',(result,silent)))
        self.start(work)

    def fetch(self):
        if not self.payload or self.busy:return
        self.download_button.configure(state='disabled')
        self.status.set('正在下载并校验更新包…')
        payload=self.payload
        def work():
            package=core.download(payload,lambda count,total:self.events.put(('progress',100*count/total)))
            core.stage_package(package,payload)
            self.events.put(('staged',payload['version']))
        self.start(work)

    def restart(self):
        if self.busy:return
        refresh=getattr(self.app,'refresh_login_sessions',None)
        if refresh:refresh()
        if self.app.active_sessions:
            message='仍有税务局登录会话。为避免中断业务，请先完成操作并关闭对应税局浏览器。关闭后本窗口会自动恢复重启按钮。'
            self.status.set(message)
            messagebox.showwarning('暂不能重启更新',message,parent=self.window or self.app)
            self.refresh_restart_state();return
        if not core.state().get('pending'):
            self.status.set('尚未准备好更新包，请先下载更新。');return
        env=os.environ.copy();env.pop('TAX_WORKBENCH_PENDING',None);env.pop('TAX_WORKBENCH_CHILD',None)
        command=([sys.executable] if getattr(sys,'frozen',False) else [sys.executable,str(core.HOME/'startup_launcher.pyw')])
        try:
            subprocess.Popen(command,env=env,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        except Exception as error:
            self.status.set('无法启动更新，当前窗口保持打开：'+str(error))
            messagebox.showerror('启动更新失败',str(error),parent=self.window or self.app)
            return
        self.app.destroy()

    def drain(self):
        try:
            while True:
                kind,value=self.events.get_nowait()
                if kind=='checked':
                    self.payload,silent=value
                    self.status.set('当前已是最新版本。' if not self.payload else '发现新版本 '+self.payload['version'])
                    if self.payload:
                        self.app.status_value.set('发现新版本 '+self.payload['version']+'，请打开软件更新')
                    self.render_payload()
                elif kind=='error':
                    self.status.set(value)
                    if self.payload and self.window and self.window.winfo_exists():self.download_button.configure(state='normal')
                elif kind=='progress':self.progress.set(value)
                elif kind=='staged':
                    self.status.set('版本 '+value+' 已准备就绪，重启后生效。')
                    if self.window and self.window.winfo_exists():self.restart_button.configure(state='normal')
                elif kind=='done':
                    self.busy=False
                    self.render_payload()
        except queue.Empty:pass
        self.refresh_restart_state()
        self.app.after(150,self.drain)
